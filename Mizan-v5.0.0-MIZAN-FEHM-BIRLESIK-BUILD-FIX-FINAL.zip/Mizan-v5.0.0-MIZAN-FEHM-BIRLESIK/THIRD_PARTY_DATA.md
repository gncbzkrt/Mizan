# Üçüncü taraf veri ve kaynak politikası

## Kütüb-i Sitte / Hisnü'l-Müslim

Build betiği varsayılan olarak `Jaguar16/open-hadith-data` v1.1.0 yapılandırılmış SQLite verisini kullanır.

- Proje kod lisansı: MIT (kaynak projenin beyanı).
- Yapılandırılmış veri: CC0 1.0 olarak beyan edilmiştir.
- Kaynak proje, İngilizce tercümelerin sunnah.com kaynaklı olduğunu ve kullanım şartlarının ayrıca kontrol edilmesi gerektiğini belirtir.
- **MÎZAN final veritabanı İngilizce tercüme alanlarını kopyalamaz.** Altı ana eserden Arapça metin, hadis numarası, kitap/bab numarası mevcutsa metadata, ravi, derece, referans ve kaynak URL alanları alınır.
- Hisnü'l-Müslim tarafında Arapça metin, Latin transliterasyon ve kaynak metadata alanları kullanılır; İngilizce tercüme alınmaz.
- Veri setinin kendisi otomatik derlenmiş bir açık veri kaynağıdır; kaynak proje de ilmî doğruluk için tahkikli baskı/ehil kaynak kontrolünü tavsiye eder. MÎZAN bu sınırı kullanıcıya “doğrulama” notuyla gösterir.

Kaynak URL (build betiğinde sabitlenmiştir):
`https://github.com/Jaguar16/open-hadith-data/releases/download/v1.1.0/hadiths.db`

## Kur’an metni

Mevcut MÎZAN hattındaki alquran.cloud edition API kullanımı korunmuştur. Günlük tam 6236 ayet seçiminde ve Kur’an çalışma ekranında Arapça, Latin transliterasyon ve mevcut Türkçe edition alanları cihaz önbelleğine alınır. Mevcut kullanıcı cache'i migration sırasında silinmez.

## WEB kaynak onayı

Web aramasından bulunan yeni aday içerikler doğrudan kalıcı kaynak tablosuna eklenmez. Önce `candidates/PENDING`, kullanıcı onayı sonrası `WEB_APPROVED/ACTIVE` akışı korunur. Önceden onaylanmış kayıtlar sürüm yükseltmesinde silinmez.
