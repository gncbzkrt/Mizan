# MÎZAN v5.0.0 — MÎZAN + FEHM Birleşik

**Oku · Anla · Yaşa**

Bu paket, çalışan MÎZAN v4.1.0 hattının üzerine FEHM v1.2.1 öğrenme ve ses motorunun tek Android uygulaması içinde birleştirilmiş sürümüdür.

## Güncelleme güvenliği
- Package name değişmedi: `com.mizan.kisisel.widget`
- Mevcut MÎZAN imza anahtarı aynen korunur.
- `versionCode=60`, `versionName=5.0.0`
- Mevcut MÎZAN uygulamasının üzerine UPDATE olarak kurulur.
- Uygulama verisini temizlemek gerekmez.
- v4.0.4 günlük rotasyon düzeltmeleri ve v4.1.0 Kütüphane/Kütüb-i Sitte katmanı korunur.
- MÎZAN widget receiver ve widget kaynakları korunmuştur.

## Yeni birleşik Kur’an alanı
Kur’an sayfası sade, ayet-merkezli bir okuma akışına geçirilmiştir.

- `☰` düğmesi ile soldan açılan **geçici menü**; sabit değildir.
- Menü tekrar `☰`, geri tuşu veya menü dışına dokunma ile kapanır.
- Aynı ayette yatay kaydırma: **OKUMA ↔ MEAL**.
- Ayet gösterimi üç seçeneklidir:
  - Sadece Arapça
  - Sadece Latin harfli okunuş
  - Arapça + Latin harfli okunuş
- Meal seçimi:
  - Diyanet İşleri
  - Diyanet Vakfı
  - Elmalılı Hamdi Yazır
- Yazı boyutu ayarı.
- İşaretli yere git / ayeti işaretle.
- Sûre ve cüz seçimi.
- Yerel Kur’an paketinde arama.
- Ayet notları.
- Favoriler.
- Mushaf / nüzul sırası korunur.
- Ayetten `MÎZAN’A SOR`, kelime inceleme ve `FEHM İLE ÖĞREN`.

Görsel/kullanım fikri Pratik Meal'deki sade kaydırma ve çekmece menü yaklaşımından esinlenmiştir; kod ve MÎZAN arayüzü bu proje içinde özgün olarak uygulanmıştır.

## FEHM birleşimi
FEHM artık ayrı launcher değildir. MÎZAN içinden açılan öğrenme modülüdür.

- Dinle ve öğren
- Kur’an Laboratuvarı
- Kelime/kök ve morfoloji
- Mini gramer
- Tekrar planı ve karıştırılan kelimeler
- Test/ilerleme kayıtları
- Yerel Kur’an paketi
- Çevrimdışı ses cache'i
- FEHM Drive yedeği/geri yükleme

MÎZAN'ın Gemini anahtarı FEHM tarafından da kullanılabilir. FEHM ayarlarından yapılan anahtar değişikliği MÎZAN ayarına da yansıtılır.

## Sesli Kur’an
- Mahir Al-Muaiqly 64 kbps / 128 kbps ve desteklenen diğer FEHM okuyucuları.
- Ayet ayet sürekli oynatma.
- Ekran kapalıyken foreground service ile devam.
- İki ayet ileri ses önbellekleme.
- MÎZAN sayfaları arasında dolaşırken altta kalıcı mini oynatıcı.
- Okuyucu Kur’an Ayarları'ndan seçilir.

## Zikir düzeltmesi
Zikir kartlarında Arapça ve Latin okunuşa ek olarak **Türkçe anlam** ayrı başlıkla görünür. Eski günlük cache kayıtları da veri temizliği gerektirmeden gösterim sırasında uyarlanır.

## Yedekleme / migration
MÎZAN yedeği `MIZAN_BACKUP_V2` biçimine yükseltilmiştir ve eski `MIZAN_BACKUP_V1` dosyalarını da okuyabilir.

MÎZAN yedeğine eklenenler:
- Kur’an okuma ayarları
- Kur’an notları ve işaret bilgisi
- FEHM öğrenme durumu

Geri yükleme mevcut tabloları topluca silmez; verileri birleştirir. FEHM'in kendi eski `FEHM_BACKUP_V1` yedeği, MÎZAN içindeki **Ayarlar → FEHM / Yedek → Yedekten Geri Yükle** yoluyla içe alınabilir ve mevcut ilerlemeyle birleştirilir.

## Widget
Mevcut MÎZAN widget'ı korunmuştur:
- Günün içerikleri
- Namaz vakitleri
- aktif vakit görünümü
- mevcut widget ileri/yenile akışı

## GitHub Actions ile telefondan APK
1. Bu ZIP'i açıp içindeki klasör/dosyaları GitHub reposuna yükle. ZIP'i repo kökünde bırakmayı tercih ediyorsan mevcut workflow ZIP'i de bulabilir.
2. `.github/workflows/build-apk.yml` repo içinde bulunmalıdır.
3. GitHub → **Actions** → **Mizan APK Olustur**.
4. **Run workflow**.
5. İşlem yeşil tamamlanınca Artifacts bölümünden `Mizan-v5.0.0-MIZAN-FEHM-BIRLESIK-APK` indir.
6. ZIP içindeki APK'yı mevcut MÎZAN'ın üzerine kur. Eski MÎZAN'ı kaldırma.

Build sırasında Kütüb-i Sitte/dua veri hazırlayıcısı çalışır. Android SDK 35 ve Java 17 workflow tarafından kurulur.

## Veri atıfları
- `THIRD_PARTY_DATA.md`: MÎZAN Kütüb-i Sitte / dua veri katmanı.
- `FEHM_ATTRIBUTIONS.txt`: FEHM Kur’an/morfoloji/ses veri kaynakları.
