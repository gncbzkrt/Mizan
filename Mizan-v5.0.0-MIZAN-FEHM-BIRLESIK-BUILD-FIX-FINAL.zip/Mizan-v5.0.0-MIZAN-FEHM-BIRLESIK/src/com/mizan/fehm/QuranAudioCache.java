package com.mizan.fehm;
import android.content.*;
import java.io.*;
import java.net.*;

final class QuranAudioCache {
    interface Progress{void onProgress(int done,int total,String text);}
    static File file(Context c,String reciter,int s,int a){File dir=new File(c.getFilesDir(),"quran_audio/"+reciter);if(!dir.exists())dir.mkdirs();return new File(dir,pad3(s)+pad3(a)+".mp3");}
    static boolean has(Context c,String reciter,int s,int a){File f=file(c,reciter,s,a);return f.isFile()&&f.length()>1000;}
    static String source(Context c,String reciter,int s,int a){File f=file(c,reciter,s,a);return has(c,reciter,s,a)?f.getAbsolutePath():Reciters.url(reciter,s,a);}
    static void downloadSurah(Context c,String reciter,int surah,Progress p)throws Exception{int total=QuranMeta.ayahCount(surah);for(int a=1;a<=total;a++){if(!has(c,reciter,surah,a))download(c,reciter,surah,a);if(p!=null)p.onProgress(a,total,QuranMeta.label(surah,a));}}
    static void download(Context c,String reciter,int s,int a)throws Exception{
        File target=file(c,reciter,s,a);if(target.isFile()&&target.length()>1000)return;
        Exception first=null;
        String[] urls=new String[]{Reciters.url(reciter,s,a),Reciters.fallbackUrl(reciter,s,a)};
        for(String url:urls){try{downloadOne(url,target);return;}catch(Exception e){if(first==null)first=e;}}
        if(first instanceof Exception)throw first;throw new IOException("Ses dosyası indirilemedi.");
    }
    private static void downloadOne(String url,File target)throws Exception{
        File tmp=new File(target.getAbsolutePath()+".part");if(tmp.exists())tmp.delete();
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(15000);h.setReadTimeout(60000);h.setInstanceFollowRedirects(true);h.setRequestProperty("User-Agent","FEHM/1.2.1");h.setRequestProperty("Accept","audio/mpeg,*/*");
        int code=h.getResponseCode();if(code<200||code>=300){h.disconnect();throw new IOException("Ses kaynağı HTTP "+code);}
        InputStream in=h.getInputStream();FileOutputStream out=new FileOutputStream(tmp);byte[] buf=new byte[32768];int n;long total=0;while((n=in.read(buf))>0){out.write(buf,0,n);total+=n;}out.flush();out.close();in.close();h.disconnect();
        if(total<1000){tmp.delete();throw new IOException("Ses dosyası boş geldi.");}
        if(target.exists())target.delete();if(!tmp.renameTo(target))throw new IOException("Ses dosyası kaydedilemedi.");
    }
    static long bytes(Context c){return sum(new File(c.getFilesDir(),"quran_audio"));}
    static long bytes(Context c,String reciter){File dir=new File(c.getFilesDir(),"quran_audio/"+reciter);return sum(dir);}
    static void clearAll(Context c){delete(new File(c.getFilesDir(),"quran_audio"));}
    private static void delete(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] a=f.listFiles();if(a!=null)for(File x:a)delete(x);}f.delete();}
    private static long sum(File f){if(f==null||!f.exists())return 0;if(f.isFile())return f.length();long x=0;File[] arr=f.listFiles();if(arr!=null)for(File k:arr)x+=sum(k);return x;}
    private static String pad3(int n){if(n<10)return "00"+n;if(n<100)return "0"+n;return ""+n;}
    private QuranAudioCache(){}
}
