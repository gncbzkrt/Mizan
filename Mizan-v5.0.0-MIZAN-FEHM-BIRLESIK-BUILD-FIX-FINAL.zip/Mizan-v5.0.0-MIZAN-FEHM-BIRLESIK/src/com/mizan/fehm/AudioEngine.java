package com.mizan.fehm;
import android.media.*;
final class AudioEngine {
    private MediaPlayer player;
    void play(String url, final Runnable ready, final Runnable done, final ErrorHandler err){stop();try{player=new MediaPlayer();player.setAudioStreamType(AudioManager.STREAM_MUSIC);player.setDataSource(url);player.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer p){p.start();if(ready!=null)ready.run();}});player.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){public void onCompletion(MediaPlayer p){if(done!=null)done.run();}});player.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer p,int w,int e){if(err!=null)err.onError("Ses oynatılamadı ("+w+"/"+e+").");return true;}});player.prepareAsync();}catch(Exception e){if(err!=null)err.onError(e.getMessage());}}
    void stop(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    interface ErrorHandler{void onError(String msg);}
}
