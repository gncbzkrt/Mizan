package com.mizan.fehm;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

final class GeminiClient {
    private static final String PREF="fehm_ai"; private static final String KEY="gemini_key"; private static final String MODEL="gemini_model";
    static final class WebRef { final String title,uri; WebRef(String title,String uri){this.title=title;this.uri=uri;} }
    static final class GenerationResult { final String text; final List<WebRef> webRefs; GenerationResult(String text,List<WebRef> webRefs){this.text=text;this.webRefs=webRefs;} }
    static void save(Context c,String key,String model){String k=key==null?"":key.trim();String m=normalizeModel(model);c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,k).putString(MODEL,m).apply();c.getSharedPreferences("mizan_ai",Context.MODE_PRIVATE).edit().putString(KEY,k).putString(MODEL,m).apply();}
    static String key(Context c){String k=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"");if(k==null||k.trim().isEmpty())k=c.getSharedPreferences("mizan_ai",Context.MODE_PRIVATE).getString(KEY,"");return k==null?"":k;}
    static String model(Context c){String stored=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(MODEL,"");if(stored==null||stored.trim().isEmpty())stored=c.getSharedPreferences("mizan_ai",Context.MODE_PRIVATE).getString(MODEL,"gemini-3.7-flash");return normalizeModel(stored);}
    private static String normalizeModel(String model){String m=model==null?"":model.trim();if(m.isEmpty()||m.equals("gemini-2.5-flash")||m.equals("models/gemini-2.5-flash"))return "gemini-3.7-flash";if(m.startsWith("models/"))m=m.substring(7);return m;}
    static boolean configured(Context c){return !key(c).isEmpty();}

    static String generate(Context c,String prompt,boolean webSearch) throws Exception{return generateDetailed(c,prompt,webSearch).text;}
    static GenerationResult generateDetailed(Context c,String prompt,boolean webSearch) throws Exception{
        if(!configured(c))throw new IllegalStateException("Gemini API anahtarı girilmemiş.");
        if(webSearch){
            // Eski Google Search/grounding yardimci modeli artik kullanilmiyor.
            // Bu dal uyumluluk icin ana model/fallback zincirini kullanir.
            return generateWithFallback(c,prompt,false);
        }
        return generateWithFallback(c,prompt,false);
    }

    private static GenerationResult generateWithFallback(Context c,String prompt,boolean ignored) throws Exception{
        String primary=model(c);
        String[] models=uniqueModels(primary,"gemini-3.6-flash","gemini-3.5-flash");
        Exception last=null;
        for(int m=0;m<models.length;m++){
            String requestModel=models[m];
            int tries=(m==0?3:2);
            for(int attempt=0;attempt<tries;attempt++){
                try{return requestOnce(c,prompt,requestModel);}
                catch(GeminiHttpException e){
                    last=e;
                    if(e.code==401||e.code==403||e.code==400)throw e;
                    if(e.code==429||e.code==503||e.code==500||e.code==502||e.code==504){
                        if(attempt+1<tries){try{Thread.sleep(attempt==0?1200L:2600L);}catch(InterruptedException ie){Thread.currentThread().interrupt();}}
                        continue;
                    }
                    if(e.code==404)break;
                    throw e;
                }catch(SocketTimeoutException e){
                    last=e;
                    if(attempt+1<tries){try{Thread.sleep(900L);}catch(InterruptedException ie){Thread.currentThread().interrupt();}}
                    continue;
                }catch(IOException e){
                    last=e;
                    if(attempt+1<tries){try{Thread.sleep(900L);}catch(InterruptedException ie){Thread.currentThread().interrupt();}}
                    continue;
                }
            }
        }
        if(last instanceof GeminiHttpException){
            GeminiHttpException g=(GeminiHttpException)last;
            throw new IllegalStateException("Gemini şu anda yoğun. FEHM 3.7 → 3.6 → 3.5 modellerini otomatik denedi ancak yanıt alamadı. Birkaç dakika sonra tekrar dene. (HTTP "+g.code+")");
        }
        if(last instanceof SocketTimeoutException)throw new IllegalStateException("Gemini yanıtı zaman aşımına uğradı. FEHM isteği yeniden deneyip yedek modellere geçti ancak süre içinde yanıt alamadı. Birkaç saniye sonra tekrar deneyebilirsin.");
        if(last instanceof IOException)throw new IllegalStateException("Gemini bağlantısı geçici olarak kurulamadı. İnternet bağlantısını kontrol edip tekrar dene.");
        throw new IllegalStateException(last==null?"Gemini yanıt vermedi.":last.getMessage());
    }

    private static String[] uniqueModels(String a,String b,String c){
        ArrayList<String> x=new ArrayList<String>();String[] in={a,b,c};
        for(String s:in){if(s==null||s.trim().isEmpty())continue;boolean dup=false;for(String y:x)if(y.equals(s)){dup=true;break;}if(!dup)x.add(s);}
        return x.toArray(new String[x.size()]);
    }

    private static GenerationResult requestOnce(Context c,String prompt,String requestModel) throws Exception{
        String endpoint="https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(requestModel,"UTF-8").replace("%2F","/")+":generateContent?key="+URLEncoder.encode(key(c),"UTF-8");
        JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject content=new JSONObject();JSONArray parts=new JSONArray();parts.put(new JSONObject().put("text",prompt));content.put("role","user").put("parts",parts);contents.put(content);body.put("contents",contents);
        JSONObject cfg=new JSONObject();cfg.put("maxOutputTokens",16384);body.put("generationConfig",cfg);
        HttpURLConnection h=(HttpURLConnection)new URL(endpoint).openConnection();h.setConnectTimeout(12000);h.setReadTimeout(90000);h.setRequestMethod("POST");h.setDoOutput(true);h.setRequestProperty("Content-Type","application/json; charset=utf-8");h.setRequestProperty("Accept","application/json");OutputStream os=h.getOutputStream();os.write(body.toString().getBytes("UTF-8"));os.close();
        int code=h.getResponseCode();InputStream in=code>=200&&code<300?h.getInputStream():h.getErrorStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);r.close();h.disconnect();if(code<200||code>=300)throw new GeminiHttpException(code,friendlyError(code,s.toString()));
        JSONObject root=new JSONObject(s.toString());JSONArray cand=root.optJSONArray("candidates");if(cand==null||cand.length()==0)throw new IllegalStateException("Gemini yanıt üretmedi.");JSONObject candidate=cand.getJSONObject(0);JSONObject co=candidate.optJSONObject("content");JSONArray ps=co==null?null:co.optJSONArray("parts");StringBuilder text=new StringBuilder();if(ps!=null)for(int i=0;i<ps.length();i++){String t=ps.getJSONObject(i).optString("text","");if(!t.isEmpty())text.append(t);}if(text.length()==0)throw new IllegalStateException("Gemini metin yanıtı boş.");
        return new GenerationResult(text.toString(),new ArrayList<WebRef>());
    }

    private static final class GeminiHttpException extends Exception{final int code;GeminiHttpException(int code,String msg){super(msg);this.code=code;}}
    static String cleanJson(String text){String s=text==null?"":text.trim();if(s.startsWith("```")){int nl=s.indexOf('\n');if(nl>=0)s=s.substring(nl+1);int e=s.lastIndexOf("```");if(e>=0)s=s.substring(0,e);}int a=s.indexOf('{'),b=s.lastIndexOf('}');return a>=0&&b>a?s.substring(a,b+1):s;}
    private static String friendlyError(int code,String raw){String s=raw==null?"":raw;if(code==404&&(s.contains("no longer available")||s.contains("NOT_FOUND")))return "Gemini isteğinde kullanılan model bu API anahtarı için erişilebilir değil. Ana sohbet modeli Ayarlar ekranında doğru görünüyorsa bu hata yardımcı bir modelden kaynaklanmış olabilir.";if(code==429)return webQuotaMessage(raw);if(code==503)return "Gemini modeli şu anda yoğun; FEHM otomatik olarak yedek modele geçecek.";if(code==401||code==403)return "Gemini API anahtarı kabul edilmedi. Ayarlar bölümündeki anahtarı kontrol et.";return shorten(s,700);}
    private static String webQuotaMessage(String raw){String s=raw==null?"":raw;if(s.contains("google_search")||s.contains("ground")||s.contains("quota"))return "Gemini/Google Search kotası bu istek için dolu. Kaynak Ara, ücretsiz arama kotası olan gemini-2.5-flash-lite ile çalışır; günlük limit dolmuşsa daha sonra yeniden dene.";return "Gemini kullanım kotası şu anda dolu. Biraz sonra tekrar dene.";}
    private static String shorten(String s,int n){return s.length()<=n?s:s.substring(0,n);}
    private GeminiClient(){}
}
