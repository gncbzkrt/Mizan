package com.mizan.fehm;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import org.json.*;
import java.util.*;

final class FehmStore extends SQLiteOpenHelper {
    private static FehmStore I; private final Context app;
    static synchronized FehmStore get(Context c){if(I==null)I=new FehmStore(c.getApplicationContext());return I;}
    private FehmStore(Context c){super(c,"fehm_personal.db",null,1);app=c;}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY,v TEXT NOT NULL)");
        d.execSQL("CREATE TABLE mastery(skill TEXT NOT NULL,item_id TEXT NOT NULL,level INTEGER NOT NULL DEFAULT 0,ease REAL NOT NULL DEFAULT 2.5,interval_days INTEGER NOT NULL DEFAULT 0,due_at INTEGER NOT NULL DEFAULT 0,lapses INTEGER NOT NULL DEFAULT 0,last_result INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(skill,item_id))");
        d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,ts INTEGER NOT NULL,skill TEXT NOT NULL,correct INTEGER NOT NULL,total INTEGER NOT NULL,seconds INTEGER NOT NULL DEFAULT 0)");
        d.execSQL("CREATE TABLE mistakes(skill TEXT NOT NULL,item_id TEXT NOT NULL,count INTEGER NOT NULL DEFAULT 0,last_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(skill,item_id))");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int a,int b){}
    String get(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM kv WHERE k=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}
    int getInt(String k,int def){try{return Integer.parseInt(get(k,""+def));}catch(Exception e){return def;}}
    void put(String k,String v){ContentValues x=new ContentValues();x.put("k",k);x.put("v",v==null?"":v);getWritableDatabase().insertWithOnConflict("kv",null,x,SQLiteDatabase.CONFLICT_REPLACE);}
    void review(String skill,String item,int quality){SQLiteDatabase d=getWritableDatabase();Cursor c=d.rawQuery("SELECT level,ease,interval_days,lapses FROM mastery WHERE skill=? AND item_id=?",new String[]{skill,item});int level=0,interval=0,lapses=0;double ease=2.5;try{if(c.moveToFirst()){level=c.getInt(0);ease=c.getDouble(1);interval=c.getInt(2);lapses=c.getInt(3);}}finally{c.close();}
        long due;
        if(quality<3){
            level=Math.max(0,level-1);interval=0;lapses++;ease=Math.max(1.3,ease-0.2);
            due=System.currentTimeMillis()+10L*60L*1000L; // Karıştırılan öğe aynı gün yeniden karşılaşsın.
        }else{
            level=Math.min(6,level+1);
            if(quality==3){interval=Math.max(1,interval<=0?1:interval);}
            else if(interval<=0)interval=1;
            else if(interval==1)interval=3;
            else interval=(int)Math.max(interval+1,Math.round(interval*ease));
            ease=Math.max(1.3,ease+(quality==5?0.1:quality==3?-0.05:0));
            due=System.currentTimeMillis()+interval*86400000L;
        }ContentValues x=new ContentValues();x.put("skill",skill);x.put("item_id",item);x.put("level",level);x.put("ease",ease);x.put("interval_days",interval);x.put("due_at",due);x.put("lapses",lapses);x.put("last_result",quality);d.insertWithOnConflict("mastery",null,x,SQLiteDatabase.CONFLICT_REPLACE);if(quality<3)mistake(skill,item);}
    private void mistake(String skill,String item){SQLiteDatabase d=getWritableDatabase();Cursor c=d.rawQuery("SELECT count FROM mistakes WHERE skill=? AND item_id=?",new String[]{skill,item});int n=0;try{if(c.moveToFirst())n=c.getInt(0);}finally{c.close();}ContentValues x=new ContentValues();x.put("skill",skill);x.put("item_id",item);x.put("count",n+1);x.put("last_at",System.currentTimeMillis());d.insertWithOnConflict("mistakes",null,x,SQLiteDatabase.CONFLICT_REPLACE);}
    int level(String skill,String item){Cursor c=getReadableDatabase().rawQuery("SELECT level FROM mastery WHERE skill=? AND item_id=?",new String[]{skill,item});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    int learnedCount(String skill){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM mastery WHERE skill=? AND level>=3",new String[]{skill});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    ArrayList<String> due(String skill,int limit){ArrayList<String> out=new ArrayList<String>();Cursor c=getReadableDatabase().rawQuery("SELECT item_id FROM mastery WHERE skill=? AND due_at<=? ORDER BY due_at ASC LIMIT "+Math.max(1,limit),new String[]{skill,""+System.currentTimeMillis()});try{while(c.moveToNext())out.add(c.getString(0));}finally{c.close();}return out;}
    void session(String skill,int correct,int total,int seconds){ContentValues x=new ContentValues();x.put("ts",System.currentTimeMillis());x.put("skill",skill);x.put("correct",correct);x.put("total",total);x.put("seconds",seconds);getWritableDatabase().insert("sessions",null,x);}
    JSONObject exportState() throws Exception {JSONObject root=new JSONObject();root.put("format","FEHM_BACKUP_V1");root.put("createdAt",System.currentTimeMillis());root.put("kv",table("SELECT k,v FROM kv",new String[]{"k","v"}));root.put("mastery",table("SELECT skill,item_id,level,ease,interval_days,due_at,lapses,last_result FROM mastery",new String[]{"skill","item_id","level","ease","interval_days","due_at","lapses","last_result"}));root.put("sessions",table("SELECT ts,skill,correct,total,seconds FROM sessions",new String[]{"ts","skill","correct","total","seconds"}));root.put("mistakes",table("SELECT skill,item_id,count,last_at FROM mistakes",new String[]{"skill","item_id","count","last_at"}));SharedPreferences p=app.getSharedPreferences("fehm_ai",Context.MODE_PRIVATE);root.put("settings",new JSONObject().put("model",p.getString("gemini_model","gemini-3.7-flash")).put("latinAlways",app.getSharedPreferences("fehm_ui",Context.MODE_PRIVATE).getBoolean("latinAlways",true)));return root;}
    private JSONArray table(String sql,String[] cols)throws Exception{JSONArray a=new JSONArray();Cursor c=getReadableDatabase().rawQuery(sql,null);try{while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<cols.length;i++){int t=c.getType(i);if(t==Cursor.FIELD_TYPE_INTEGER)o.put(cols[i],c.getLong(i));else if(t==Cursor.FIELD_TYPE_FLOAT)o.put(cols[i],c.getDouble(i));else o.put(cols[i],c.getString(i));}a.put(o);}}finally{c.close();}return a;}
    void importState(JSONObject root)throws Exception{if(!"FEHM_BACKUP_V1".equals(root.optString("format")))throw new Exception("Bu dosya FEHM yedeği değil.");SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{insertKv(d,root.optJSONArray("kv"));insertMastery(d,root.optJSONArray("mastery"));insertSessionsMerge(d,root.optJSONArray("sessions"));insertMistakes(d,root.optJSONArray("mistakes"));d.setTransactionSuccessful();}finally{d.endTransaction();}JSONObject s=root.optJSONObject("settings");if(s!=null){app.getSharedPreferences("fehm_ai",Context.MODE_PRIVATE).edit().putString("gemini_model",s.optString("model","gemini-3.7-flash")).apply();app.getSharedPreferences("fehm_ui",Context.MODE_PRIVATE).edit().putBoolean("latinAlways",s.optBoolean("latinAlways",true)).apply();}}
    private void insertKv(SQLiteDatabase d,JSONArray a)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ContentValues x=new ContentValues();x.put("k",o.optString("k"));x.put("v",o.optString("v"));d.insertWithOnConflict("kv",null,x,SQLiteDatabase.CONFLICT_REPLACE);}}
    private void insertMastery(SQLiteDatabase d,JSONArray a)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ContentValues x=new ContentValues();x.put("skill",o.optString("skill"));x.put("item_id",o.optString("item_id"));x.put("level",o.optInt("level"));x.put("ease",o.optDouble("ease",2.5));x.put("interval_days",o.optInt("interval_days"));x.put("due_at",o.optLong("due_at"));x.put("lapses",o.optInt("lapses"));x.put("last_result",o.optInt("last_result"));d.insertWithOnConflict("mastery",null,x,SQLiteDatabase.CONFLICT_REPLACE);}}
    private void insertSessions(SQLiteDatabase d,JSONArray a)throws Exception{insertSessionsMerge(d,a);}
    private void insertSessionsMerge(SQLiteDatabase d,JSONArray a)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);long ts=o.optLong("ts");String skill=o.optString("skill");int correct=o.optInt("correct"),total=o.optInt("total"),seconds=o.optInt("seconds");Cursor c=d.rawQuery("SELECT 1 FROM sessions WHERE ts=? AND skill=? AND correct=? AND total=? AND seconds=? LIMIT 1",new String[]{""+ts,skill,""+correct,""+total,""+seconds});boolean exists;try{exists=c.moveToFirst();}finally{c.close();}if(exists)continue;ContentValues x=new ContentValues();x.put("ts",ts);x.put("skill",skill);x.put("correct",correct);x.put("total",total);x.put("seconds",seconds);d.insert("sessions",null,x);}}
    private void insertMistakes(SQLiteDatabase d,JSONArray a)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ContentValues x=new ContentValues();x.put("skill",o.optString("skill"));x.put("item_id",o.optString("item_id"));x.put("count",o.optInt("count"));x.put("last_at",o.optLong("last_at"));d.insertWithOnConflict("mistakes",null,x,SQLiteDatabase.CONFLICT_REPLACE);}}
}
