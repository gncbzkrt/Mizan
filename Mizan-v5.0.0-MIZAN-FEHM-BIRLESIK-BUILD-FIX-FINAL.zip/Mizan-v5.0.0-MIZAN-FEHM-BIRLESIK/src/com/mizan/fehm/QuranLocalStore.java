package com.mizan.fehm;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

final class QuranLocalStore extends SQLiteOpenHelper {
    private static QuranLocalStore I;
    static synchronized QuranLocalStore get(Context c){if(I==null)I=new QuranLocalStore(c.getApplicationContext());return I;}
    private QuranLocalStore(Context c){super(c,"fehm_quran_local.db",null,1);}

    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE verses(surah INTEGER NOT NULL,ayah INTEGER NOT NULL,global_no INTEGER NOT NULL,arabic TEXT NOT NULL DEFAULT '',latin TEXT NOT NULL DEFAULT '',diyanet TEXT NOT NULL DEFAULT '',elmalili TEXT NOT NULL DEFAULT '',vakif TEXT NOT NULL DEFAULT '',PRIMARY KEY(surah,ayah))");
        d.execSQL("CREATE INDEX idx_verses_global ON verses(global_no)");
        d.execSQL("CREATE TABLE morph(id INTEGER PRIMARY KEY AUTOINCREMENT,surah INTEGER NOT NULL,ayah INTEGER NOT NULL,word_pos INTEGER NOT NULL,segment_pos INTEGER NOT NULL,form_bw TEXT NOT NULL DEFAULT '',form_ar TEXT NOT NULL DEFAULT '',lemma_bw TEXT NOT NULL DEFAULT '',lemma_ar TEXT NOT NULL DEFAULT '',lemma_latin TEXT NOT NULL DEFAULT '',root_bw TEXT NOT NULL DEFAULT '',root_ar TEXT NOT NULL DEFAULT '',root_latin TEXT NOT NULL DEFAULT '',pos TEXT NOT NULL DEFAULT '',features TEXT NOT NULL DEFAULT '')");
        d.execSQL("CREATE INDEX idx_morph_ref ON morph(surah,ayah,word_pos)");
        d.execSQL("CREATE INDEX idx_morph_root_ar ON morph(root_ar)");
        d.execSQL("CREATE INDEX idx_morph_root_latin ON morph(root_latin)");
        d.execSQL("CREATE INDEX idx_morph_lemma_ar ON morph(lemma_ar)");
        d.execSQL("CREATE INDEX idx_morph_lemma_latin ON morph(lemma_latin)");
        d.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int a,int b){}

    int verseCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM verses",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    int morphCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM morph",null);try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}
    int verseCountForSurah(int surah){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM verses WHERE surah=?",new String[]{""+surah});try{return c.moveToFirst()?c.getInt(0):0;}finally{c.close();}}

    QuranClient.Ayah getVerse(int s,int a){
        Cursor c=getReadableDatabase().rawQuery("SELECT global_no,arabic,latin,diyanet,elmalili,vakif FROM verses WHERE surah=? AND ayah=?",new String[]{""+s,""+a});
        try{if(!c.moveToFirst())return null;QuranClient.Ayah x=new QuranClient.Ayah();x.surah=s;x.ayah=a;x.global=c.getInt(0);x.arabic=c.getString(1);x.latin=c.getString(2);x.diyanet=c.getString(3);x.elmalili=c.getString(4);x.vakif=c.getString(5);return x;}finally{c.close();}
    }

    void putVerse(QuranClient.Ayah x){
        if(x==null)return;ContentValues v=new ContentValues();v.put("surah",x.surah);v.put("ayah",x.ayah);v.put("global_no",x.global>0?x.global:QuranMeta.globalNumber(x.surah,x.ayah));v.put("arabic",nz(x.arabic));v.put("latin",nz(x.latin));v.put("diyanet",nz(x.diyanet));v.put("elmalili",nz(x.elmalili));v.put("vakif",nz(x.vakif));getWritableDatabase().insertWithOnConflict("verses",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }

    void putVerses(List<QuranClient.Ayah> list){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{for(QuranClient.Ayah x:list){ContentValues v=new ContentValues();v.put("surah",x.surah);v.put("ayah",x.ayah);v.put("global_no",x.global>0?x.global:QuranMeta.globalNumber(x.surah,x.ayah));v.put("arabic",nz(x.arabic));v.put("latin",nz(x.latin));v.put("diyanet",nz(x.diyanet));v.put("elmalili",nz(x.elmalili));v.put("vakif",nz(x.vakif));d.insertWithOnConflict("verses",null,v,SQLiteDatabase.CONFLICT_REPLACE);}d.setTransactionSuccessful();}finally{d.endTransaction();}
    }

    void clearMorph(){getWritableDatabase().delete("morph",null,null);}
    void beginMorph(SQLiteDatabase d){}
    void putMorph(SQLiteDatabase d,int surah,int ayah,int word,int seg,String formBw,String lemmaBw,String rootBw,String pos,String features){
        ContentValues v=new ContentValues();v.put("surah",surah);v.put("ayah",ayah);v.put("word_pos",word);v.put("segment_pos",seg);v.put("form_bw",nz(formBw));v.put("form_ar",Buckwalter.toArabic(formBw));v.put("lemma_bw",nz(lemmaBw));v.put("lemma_ar",Buckwalter.toArabic(lemmaBw));v.put("lemma_latin",Buckwalter.toReading(lemmaBw));v.put("root_bw",nz(rootBw));v.put("root_ar",Buckwalter.toArabic(rootBw));v.put("root_latin",Buckwalter.toRootLatin(rootBw));v.put("pos",nz(pos));v.put("features",nz(features));d.insert("morph",null,v);
    }

    static final class MorphHit{
        int surah,ayah,word;String formAr="",formLatin="",lemmaAr="",lemmaLatin="",rootAr="",rootLatin="",pos="",features="";
        String ref(){return QuranMeta.label(surah,ayah)+" · kelime "+word;}
    }

    ArrayList<MorphHit> searchMorph(String q,int limit){
        ArrayList<MorphHit> out=new ArrayList<MorphHit>();q=norm(q);if(q.isEmpty())return out;String like="%"+q+"%";
        String sql="SELECT surah,ayah,word_pos,form_bw,form_ar,lemma_bw,lemma_ar,root_bw,root_ar,pos,features FROM morph WHERE root_ar LIKE ? OR lemma_ar LIKE ? OR form_ar LIKE ? OR root_latin LIKE ? OR lemma_latin LIKE ? OR form_bw LIKE ? OR lemma_bw LIKE ? OR root_bw LIKE ? ORDER BY surah,ayah,word_pos LIMIT "+Math.max(1,Math.min(100,limit));
        Cursor c=getReadableDatabase().rawQuery(sql,new String[]{like,like,like,like,like,like,like,like});try{while(c.moveToNext()){MorphHit h=new MorphHit();h.surah=c.getInt(0);h.ayah=c.getInt(1);h.word=c.getInt(2);String formBw=c.getString(3);h.formAr=c.getString(4);String lemmaBw=c.getString(5);h.lemmaAr=c.getString(6);String rootBw=c.getString(7);h.rootAr=c.getString(8);h.pos=c.getString(9);h.features=c.getString(10);h.formLatin=Buckwalter.toReading(formBw);h.lemmaLatin=Buckwalter.toReading(lemmaBw);h.rootLatin=Buckwalter.toRootLatin(rootBw);out.add(h);}}finally{c.close();}return out;
    }

    ArrayList<MorphHit> morphForVerse(int surah,int ayah,int limit){
        ArrayList<MorphHit> out=new ArrayList<MorphHit>();Cursor c=getReadableDatabase().rawQuery("SELECT surah,ayah,word_pos,form_bw,form_ar,lemma_bw,lemma_ar,root_bw,root_ar,pos,features FROM morph WHERE surah=? AND ayah=? ORDER BY word_pos,segment_pos LIMIT "+Math.max(1,Math.min(200,limit)),new String[]{""+surah,""+ayah});try{while(c.moveToNext()){MorphHit h=new MorphHit();h.surah=c.getInt(0);h.ayah=c.getInt(1);h.word=c.getInt(2);String formBw=c.getString(3);h.formAr=c.getString(4);String lemmaBw=c.getString(5);h.lemmaAr=c.getString(6);String rootBw=c.getString(7);h.rootAr=c.getString(8);h.pos=c.getString(9);h.features=c.getString(10);h.formLatin=Buckwalter.toReading(formBw);h.lemmaLatin=Buckwalter.toReading(lemmaBw);h.rootLatin=Buckwalter.toRootLatin(rootBw);out.add(h);}}finally{c.close();}return out;
    }

    ArrayList<QuranClient.Ayah> searchVerses(String q,int limit){
        ArrayList<QuranClient.Ayah> out=new ArrayList<QuranClient.Ayah>();q=q==null?"":q.trim();if(q.isEmpty())return out;String like="%"+q+"%";Cursor c=getReadableDatabase().rawQuery("SELECT surah,ayah,global_no,arabic,latin,diyanet,elmalili,vakif FROM verses WHERE arabic LIKE ? OR latin LIKE ? OR diyanet LIKE ? ORDER BY surah,ayah LIMIT "+Math.max(1,Math.min(100,limit)),new String[]{like,like,like});try{while(c.moveToNext()){QuranClient.Ayah x=new QuranClient.Ayah();x.surah=c.getInt(0);x.ayah=c.getInt(1);x.global=c.getInt(2);x.arabic=c.getString(3);x.latin=c.getString(4);x.diyanet=c.getString(5);x.elmalili=c.getString(6);x.vakif=c.getString(7);out.add(x);}}finally{c.close();}return out;
    }

    void putMeta(String k,String val){ContentValues v=new ContentValues();v.put("k",k);v.put("v",nz(val));getWritableDatabase().insertWithOnConflict("meta",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    String getMeta(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM meta WHERE k=?",new String[]{k});try{return c.moveToFirst()?c.getString(0):def;}finally{c.close();}}

    SQLiteDatabase writable(){return getWritableDatabase();}
    private static String nz(String s){return s==null?"":s;}
    private static String norm(String s){if(s==null)return "";return s.trim().toLowerCase(Locale.US).replace("-","").replace(" ","");}

    static final class Buckwalter{
        static String toArabic(String bw){if(bw==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<bw.length();i++){char c=bw.charAt(i);String x=ar(c);if(x!=null)b.append(x);}return b.toString();}
        static String toRootLatin(String bw){if(bw==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<bw.length();i++){char c=bw.charAt(i);if("aiuoFNK~`^".indexOf(c)>=0)continue;String z;switch(c){case 'E':z="‘";break;case '$':z="ş";break;case 'v':z="s";break;case '*':z="z";break;case 'x':case 'H':case 'h':z="h";break;case 'S':z="s";break;case 'D':z="d";break;case 'T':z="t";break;case 'Z':z="z";break;case 'g':z="ğ";break;case 'q':z="k";break;case 'A':case '{':case '>':case '<':case '&':case '}':case '\'':z="a";break;case 'p':z="t";break;case 'Y':case 'y':z="y";break;default:z=Character.isLetterOrDigit(c)?String.valueOf(Character.toLowerCase(c)):"";}if(z.isEmpty())continue;if(b.length()>0)b.append('-');b.append(z);}return b.toString();}
        static String toReading(String bw){if(bw==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<bw.length();i++){char c=bw.charAt(i);switch(c){case 'a':b.append('a');break;case 'i':b.append('i');break;case 'u':b.append('u');break;case 'F':b.append("an");break;case 'N':b.append("un");break;case 'K':b.append("in");break;case '~':break;case 'o':break;case '`':b.append('â');break;case '$':b.append('ş');break;case 'v':b.append("s");break;case '*':b.append('z');break;case 'x':b.append("h");break;case 'H':b.append('h');break;case 'E':b.append('‘');break;case 'S':b.append('s');break;case 'D':b.append('d');break;case 'T':b.append('t');break;case 'Z':b.append('z');break;case 'g':b.append('ğ');break;case 'q':b.append('k');break;case 'A':b.append('â');break;case '{':case '>':case '<':case '&':case '}':case '\'':b.append('a');break;case 'p':b.append('t');break;case 'Y':b.append('â');break;default:if(Character.isLetter(c))b.append(Character.toLowerCase(c));}}
            return b.toString().replace("aa","â").replace("ii","î").replace("uu","û");
        }
        static String toFriendly(String bw){if(bw==null)return "";StringBuilder b=new StringBuilder();for(int i=0;i<bw.length();i++){char c=bw.charAt(i);if("aiuoFNK~o`^".indexOf(c)>=0)continue;switch(c){case '$':b.append('s');break;case 'v':b.append('s');break;case '*':b.append('z');break;case 'x':case 'H':case 'h':b.append('h');break;case 'E':case 'e':b.append('a');break;case 'S':case 's':b.append('s');break;case 'D':case 'd':b.append('d');break;case 'T':case 't':b.append('t');break;case 'Z':case 'z':b.append('z');break;case 'g':b.append('g');break;case 'q':b.append('q');break;case 'A':case '{':case '>':case '<':case '&':case '}':case '\'':b.append('a');break;case 'p':b.append('t');break;case 'Y':case 'y':b.append('y');break;default:if(Character.isLetterOrDigit(c))b.append(Character.toLowerCase(c));}}
            return b.toString().toLowerCase(Locale.US);
        }
        private static String ar(char c){switch(c){case 'A':case '{':return "ا";case 'b':return "ب";case 't':return "ت";case 'v':return "ث";case 'j':return "ج";case 'H':return "ح";case 'x':return "خ";case 'd':return "د";case '*':return "ذ";case 'r':return "ر";case 'z':return "ز";case 's':return "س";case '$':return "ش";case 'S':return "ص";case 'D':return "ض";case 'T':return "ط";case 'Z':return "ظ";case 'E':return "ع";case 'g':return "غ";case 'f':return "ف";case 'q':return "ق";case 'k':return "ك";case 'l':return "ل";case 'm':return "م";case 'n':return "ن";case 'h':return "ه";case 'w':return "و";case 'y':return "ي";case 'Y':return "ى";case 'p':return "ة";case '>':case '<':case '\'':return "أ";case '&':return "ؤ";case '}':return "ئ";default:return null;}}
    }
}
