package com.mizan.fehm;

import com.mizan.kisisel.widget.R;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,29,27), PANEL=Color.rgb(15,52,47), PANEL2=Color.rgb(22,68,60), GOLD=Color.rgb(220,184,91), TEXT=Color.rgb(242,247,244), MUTED=Color.rgb(166,192,180), GOOD=Color.rgb(61,145,104), BAD=Color.rgb(153,72,72);
    private LinearLayout root,nav;
    private final AudioEngine audio=new AudioEngine();
    private int page=0;
    private long wordShownAt=0L;
    private LinearLayout contemplationHolder;
    private int contemplationSurah=1, contemplationAyah=1;
    private String contemplationReciter=Reciters.MAHER_64;
    private boolean receiverRegistered=false;
    private boolean backgroundPlaying=false;
    private LinearLayout persistentPlayerBar;
    private TextView persistentPlayerLabel;
    private final ArrayDeque<Runnable> screenHistory=new ArrayDeque<Runnable>();
    private Runnable currentScreen;
    private boolean restoringScreen=false;
    private QuranClient.Ayah pendingLessonAyah;
    private boolean pendingLessonReveal=false;
    private Runnable pendingLessonAfter;
    private final BroadcastReceiver playbackReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){
        if(!QuranPlaybackService.ACTION_STATE.equals(i.getAction()))return;
        String state=i.getStringExtra("state");int su=i.getIntExtra("surah",1),ay=i.getIntExtra("ayah",1);String r=i.getStringExtra("reciter");if(r==null)r=Reciters.MAHER_64;
        contemplationSurah=su;contemplationAyah=ay;contemplationReciter=r;
        backgroundPlaying="playing".equals(state)||"loading".equals(state);
        if("complete".equals(state)&&pendingLessonAyah!=null&&pendingLessonAyah.surah==su&&pendingLessonAyah.ayah==ay){
            final QuranClient.Ayah done=pendingLessonAyah;final boolean reveal=pendingLessonReveal;final Runnable after=pendingLessonAfter;pendingLessonAyah=null;pendingLessonReveal=false;pendingLessonAfter=null;
            if(reveal)showListeningReveal(done);if(after!=null)after.run();
        }
        if("error".equals(state)){if(pendingLessonAyah!=null&&pendingLessonAyah.surah==su&&pendingLessonAyah.ayah==ay){pendingLessonAyah=null;pendingLessonReveal=false;pendingLessonAfter=null;Toast.makeText(MainActivity.this,"Ses oynatılamadı. Diğer okuyucuyu deneyebilirsin.",Toast.LENGTH_LONG).show();}}
        if("error".equals(state)||"complete".equals(state)||"stopped".equals(state)){backgroundPlaying=false;getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",false).apply();}
        updatePersistentPlayer();if(contemplationHolder!=null&&backgroundPlaying)loadContemplationVerse(su,ay,r);
    }};

    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        registerPlaybackReceiver();
        backgroundPlaying=getSharedPreferences("fehm_playback",MODE_PRIVATE).getBoolean("active",false);
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},910);
        Intent launch=getIntent();String launchMode=launch==null?"":launch.getStringExtra("mizan_mode");int launchSurah=launch==null?1:launch.getIntExtra("surah",1);int launchAyah=launch==null?1:launch.getIntExtra("ayah",1);
        if("lab".equals(launchMode))showLab(launchSurah,launchAyah,false);
        else if("listen".equals(launchMode)){String rr=FehmStore.get(this).get("pureReciter",Reciters.MAHER_64);startBackgroundPlayback(launchSurah,launchAyah,rr,true);showContemplation(launchSurah,launchAyah,rr);}
        else if("settings".equals(launchMode))showSettings();
        else showHome();
        DriveBackup.maybeAutoBackup(this);
        offerLocalPackOnce();
    }
    private void offerLocalPackOnce(){final FehmStore st=FehmStore.get(this);if("1".equals(st.get("localPackPrompted","0"))||QuranDataManager.quranReady(this)&&QuranDataManager.morphReady(this))return;st.put("localPackPrompted","1");new android.os.Handler().postDelayed(new Runnable(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle("Hızlı Yerel Kur’an Paketi").setMessage("Kur’an metni, Latin okunuş, Türkçe mealler ve kök/morfoloji indeksi bir kez telefona alınsın mı? Böylece ayet, sözlük ve kök aramaları çok daha hızlı çalışır. Ses arşivi zorunlu olarak indirilmez; istediğin sureyi ayrıca çevrimdışı alabilirsin.").setNegativeButton("Sonra",null).setPositiveButton("İndir",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){showHome();final TextView stv=tv(QuranDataManager.status(MainActivity.this),12,MUTED,Typeface.NORMAL);root.addView(stv,cardLp());startLocalDataDownload(stv,null);}}).show();}},450);}
    private void registerPlaybackReceiver(){try{IntentFilter f=new IntentFilter(QuranPlaybackService.ACTION_STATE);if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(playbackReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(playbackReceiver,f);receiverRegistered=true;}catch(Exception ignored){}}
    @Override protected void onDestroy(){audio.stop();if(receiverRegistered){try{unregisterReceiver(playbackReceiver);}catch(Exception ignored){}}super.onDestroy();}

    private void shell(String eyebrow,String title,int active){
        contemplationHolder=null;
        page=active;
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(14),dp(16),dp(14),dp(30));
        sc.addView(body,new ScrollView.LayoutParams(-1,-2));outer.addView(sc,new LinearLayout.LayoutParams(-1,0,1));root=body;
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);ImageView icon=new ImageView(this);icon.setImageResource(R.mipmap.ic_launcher);h.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout tt=new LinearLayout(this);tt.setOrientation(LinearLayout.VERTICAL);tt.addView(tv(eyebrow.toUpperCase(new Locale("tr","TR")),10,GOLD,Typeface.BOLD),full());
        TextView titleV=tv(title,25,TEXT,Typeface.BOLD);titleV.setTypeface(Typeface.create(Typeface.SERIF,Typeface.BOLD));tt.addView(titleV,full());LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=dp(12);h.addView(tt,tp);body.addView(h,full());
        View r=new View(this);r.setBackgroundColor(Color.argb(80,220,184,91));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(1));rp.topMargin=dp(13);rp.bottomMargin=dp(13);body.addView(r,rp);
        nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(9,40,36));nav.setPadding(dp(4),dp(6),dp(4),dp(6));
        addNav("⌂","Bugün",0);addNav("♪","Dinle",1);addNav("ا","Oku",2);addNav("✦","Öğren",3);addNav("↗","İlerleme",4);
        addPersistentPlayer(outer);
        outer.addView(nav,new LinearLayout.LayoutParams(-1,dp(66)));setContentView(outer);
    }
    private void enterScreen(Runnable self){if(restoringScreen){currentScreen=self;return;}if(currentScreen!=null)screenHistory.push(currentScreen);currentScreen=self;}
    @Override public void onBackPressed(){if(!screenHistory.isEmpty()){Runnable prev=screenHistory.pop();restoringScreen=true;try{prev.run();}finally{restoringScreen=false;}return;}if(page!=0){restoringScreen=true;try{showHome();}finally{restoringScreen=false;}return;}moveTaskToBack(true);}
    private void addPersistentPlayer(LinearLayout outer){
        backgroundPlaying=getSharedPreferences("fehm_playback",MODE_PRIVATE).getBoolean("active",backgroundPlaying);
        persistentPlayerBar=new LinearLayout(this);persistentPlayerBar.setGravity(Gravity.CENTER_VERTICAL);persistentPlayerBar.setPadding(dp(10),dp(5),dp(7),dp(5));persistentPlayerBar.setBackgroundColor(Color.rgb(12,49,43));
        persistentPlayerLabel=tv("",11,TEXT,Typeface.BOLD);persistentPlayerBar.addView(persistentPlayerLabel,new LinearLayout.LayoutParams(0,dp(42),1));
        Button go=smallButton("DİNLEMEYE DÖN",PANEL2),stop=smallButton("DURDUR",BAD);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(112),dp(40));gp.leftMargin=dp(5);persistentPlayerBar.addView(go,gp);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(74),dp(40));sp.leftMargin=dp(5);persistentPlayerBar.addView(stop,sp);
        go.setOnClickListener(new View.OnClickListener(){public void onClick(View v){android.content.SharedPreferences p=getSharedPreferences("fehm_playback",MODE_PRIVATE);showContemplation(p.getInt("surah",1),p.getInt("ayah",1),p.getString("reciter",Reciters.MAHER_64));}});stop.setOnClickListener(new View.OnClickListener(){public void onClick(View v){stopBackgroundPlayback();}});
        updatePersistentPlayer();outer.addView(persistentPlayerBar,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    private void updatePersistentPlayer(){if(persistentPlayerBar==null)return;android.content.SharedPreferences p=getSharedPreferences("fehm_playback",MODE_PRIVATE);boolean active=p.getBoolean("active",false);persistentPlayerBar.setVisibility(active?View.VISIBLE:View.GONE);if(active&&persistentPlayerLabel!=null){int s=p.getInt("surah",contemplationSurah),a=p.getInt("ayah",contemplationAyah);String r=p.getString("reciter",contemplationReciter);persistentPlayerLabel.setText("♪ "+QuranMeta.label(s,a)+" · "+Reciters.shortName(r));}}
    private void addNav(String icon,String label,final int id){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.addView(center(tv(icon,18,id==page?GOLD:MUTED,Typeface.NORMAL)),full());x.addView(center(tv(label,10,id==page?GOLD:MUTED,id==page?Typeface.BOLD:Typeface.NORMAL)),full());
        if(id==page)x.setBackground(round(PANEL2,GOLD,1,14));
        x.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(id==0)showHome();else if(id==1)showListen();else if(id==2)showRead();else if(id==3)showLearn();else showProgress();}});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.leftMargin=dp(2);p.rightMargin=dp(2);nav.addView(x,p);
    }

    private void showHome(){
        enterScreen(new Runnable(){public void run(){showHome();}});
        shell("Kur’an’ı duy · oku · çöz · anla","FEHM · Bugünkü Ders",0);
        LinearLayout hero=card();hero.addView(tv("Sıfırdan başlıyoruz",12,GOLD,Typeface.BOLD),full());hero.addView(tv("Her gün 10–15 dakika: biraz harf, biraz kelime, biraz dinleme, biraz gramer ve gerçek ayet. Hiçbir ön bilgi varsayılmaz.",15,TEXT,Typeface.NORMAL),space(8));
        Button start=button("BUGÜNKÜ KARMA DERSE BAŞLA");start.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showDailyLesson();}});hero.addView(start,height(48,12));root.addView(hero,cardLp());
        if(!QuranDataManager.quranReady(this)||!QuranDataManager.morphReady(this)){LinearLayout pack=card();pack.addView(tv("HIZLI YEREL KUR’AN PAKETİ",11,GOLD,Typeface.BOLD),full());pack.addView(tv("Kur’an metni, Latin okunuş, Türkçe mealler ve kök/morfoloji indeksi bir kez telefona alınır. Sonraki açılışlarda ayet ve sözlük sorguları yerelden çok daha hızlı gelir.",13,TEXT,Typeface.NORMAL),space(7));final TextView ps=tv(QuranDataManager.status(this),12,MUTED,Typeface.NORMAL);pack.addView(ps,space(7));Button dl=button("YEREL PAKETİ İNDİR");dl.setOnClickListener(new View.OnClickListener(){public void onClick(View v){startLocalDataDownload(ps,(Button)v);}});pack.addView(dl,height(46,10));root.addView(pack,cardLp());}
        int[] sug=QuranMeta.suggestion();LinearLayout suggested=card();suggested.addView(tv("BUGÜNÜN DİNLEME ÖNERİSİ",11,GOLD,Typeface.BOLD),full());suggested.addView(tv(QuranMeta.label(sug[0],sug[1]),18,TEXT,Typeface.BOLD),space(6));suggested.addView(tv("Önce yalnız dinle; bildiğin sesleri yakala. Sonra laboratuvarda çöz.",13,MUTED,Typeface.NORMAL),space(5));
        final int ss=sug[0],sa=sug[1];Button open=button("DİNLEYEREK BAŞLA");open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){loadAyahAndPlay(ss,sa,true,null);}});suggested.addView(open,height(44,10));root.addView(suggested,cardLp());
        LinearLayout stats=card();stats.addView(tv("BUGÜNKÜ YOL",11,GOLD,Typeface.BOLD),full());stats.addView(tv("1 · Harfi gör ve sesi tanı\n2 · 5 temel kelime\n3 · Bir ayeti yalnız dinle\n4 · Mini gramer\n5 · Ayeti Latin okunuşla takip et\n6 · Anlamı tahmin et ve mealle karşılaştır\n7 · Zorlandıklarını tekrar kuyruğuna gönder",14,TEXT,Typeface.NORMAL),space(8));root.addView(stats,cardLp());
    }

    private void showDailyLesson(){
        enterScreen(new Runnable(){public void run(){showDailyLesson();}});
        final CourseData d=CourseData.get(this);final FehmStore s=FehmStore.get(this);shell("Uyarlanabilir karma eğitim","FEHM · Günlük Ders",0);
        final int li=s.getInt("letterIndex",0)%Math.max(1,d.letters.size());final CourseData.Letter l=d.letters.get(li);LinearLayout c=card();c.addView(tv("1 / OKUMA",10,GOLD,Typeface.BOLD),full());c.addView(center(tv(l.arabic,46,TEXT,Typeface.BOLD)),space(6));c.addView(center(tv(l.name.toUpperCase(new Locale("tr","TR"))+" · "+l.sound,16,TEXT,Typeface.BOLD)),full());c.addView(tv(l.note+"\nÖrnek: "+l.example,14,MUTED,Typeface.NORMAL),space(8));
        Button learned=button("TANIDIM · DEVAM");learned.setOnClickListener(new View.OnClickListener(){public void onClick(View v){s.put("letterIndex",""+(li+1));prepareDailyWords();showDailyWords(0);}});c.addView(learned,height(46,12));root.addView(c,cardLp());
    }
    private void prepareDailyWords(){
        CourseData d=CourseData.get(this);FehmStore s=FehmStore.get(this);ArrayList<String> ids=new ArrayList<String>();ArrayList<String> due=s.due("word",5);for(String id:due)if(findWord(id)!=null&&!ids.contains(id))ids.add(id);
        int cursor=s.getInt("wordCursor",0),guard=0;while(ids.size()<5&&guard<d.words.size()*2){CourseData.Word w=d.words.get((cursor+guard)%d.words.size());if(!ids.contains(w.id))ids.add(w.id);guard++;}
        StringBuilder b=new StringBuilder();for(String id:ids){if(b.length()>0)b.append(',');b.append(id);}s.put("daily_words",b.toString());
    }
    private CourseData.Word findWord(String id){for(CourseData.Word w:CourseData.get(this).words)if(w.id.equals(id))return w;return null;}
    private CourseData.Word dailyWord(int idx){
        FehmStore s=FehmStore.get(this);String raw=s.get("daily_words","");if(raw.isEmpty()){prepareDailyWords();raw=s.get("daily_words","");}String[] ids=raw.split(",");if(idx>=0&&idx<ids.length){CourseData.Word w=findWord(ids[idx]);if(w!=null)return w;}CourseData d=CourseData.get(this);return d.words.get((s.getInt("wordCursor",0)+idx)%d.words.size());
    }
    private void showDailyWords(final int idx){
        enterScreen(new Runnable(){public void run(){showDailyWords(idx);}});
        if(idx>=5){FehmStore.get(this).put("daily_words","");showDailyListen();return;}
        final CourseData.Word w=dailyWord(idx);shell("Geri çağırma + aralıklı tekrar","FEHM · Kelime "+(idx+1)+"/5",0);wordShownAt=System.currentTimeMillis();
        final LinearLayout c=card();c.addView(center(tv(w.arabic,35,TEXT,Typeface.BOLD)),full());c.addView(center(tv(w.latin,18,GOLD,Typeface.BOLD)),space(6));
        final TextView prompt=tv("Önce tahmin et. Hazır olduğunda anlamı aç.",14,MUTED,Typeface.NORMAL);c.addView(prompt,space(10));
        final LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setVisibility(View.GONE);c.addView(details,space(8));
        final Button reveal=button("ANLAMI GÖSTER");c.addView(reveal,height(44,10));
        final LinearLayout row=new LinearLayout(this);final Button hard=smallButton("KARIŞTIRDIM",BAD);final Button ok=smallButton("BİLDİM",GOOD);row.addView(hard,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(46),1);op.leftMargin=dp(8);row.addView(ok,op);row.setVisibility(View.GONE);c.addView(row,space(10));
        reveal.setOnClickListener(new View.OnClickListener(){public void onClick(View v){
            prompt.setText(w.meaning);prompt.setTextColor(TEXT);details.setVisibility(View.VISIBLE);details.removeAllViews();
            details.addView(tv("KÖK / AİLE",10,GOLD,Typeface.BOLD),full());details.addView(tv(formatRoot(w.root)+"\nAile: "+w.family,13,MUTED,Typeface.NORMAL),space(4));
            if(w.exampleArabic!=null&&!w.exampleArabic.isEmpty()){
                details.addView(tv("KUR’AN ÖRNEĞİ",10,GOLD,Typeface.BOLD),space(10));TextView exAr=tv(w.exampleArabic,22,TEXT,Typeface.BOLD);exAr.setGravity(Gravity.RIGHT);details.addView(exAr,space(4));details.addView(tv(w.exampleLatin,14,GOLD,Typeface.BOLD),space(3));details.addView(tv(w.exampleMeaning,13,TEXT,Typeface.NORMAL),space(3));
            }
            if(w.hint!=null&&!w.hint.isEmpty()){details.addView(tv("KISA İPUCU",10,GOLD,Typeface.BOLD),space(10));details.addView(tv(w.hint,13,MUTED,Typeface.NORMAL),space(4));}
            reveal.setVisibility(View.GONE);row.setVisibility(View.VISIBLE);
        }});
        hard.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,2);DriveBackup.maybeAutoBackup(MainActivity.this);showDailyWords(idx+1);}});
        ok.setOnClickListener(new View.OnClickListener(){public void onClick(View v){long sec=(System.currentTimeMillis()-wordShownAt)/1000L;int q=sec<=10?5:(sec<=25?4:3);FehmStore.get(MainActivity.this).review("word",w.id,q);DriveBackup.maybeAutoBackup(MainActivity.this);showDailyWords(idx+1);}});
        root.addView(c,cardLp());
    }
    private void showDailyListen(){enterScreen(new Runnable(){public void run(){showDailyListen();}});shell("Önce kulak · sonra metin","FEHM · Dinleme",0);LinearLayout c=card();c.addView(tv("3 / DİNLE",10,GOLD,Typeface.BOLD),full());c.addView(tv("Fâtiha 1/1’i bir kez yalnız dinle. Kelimeleri çözmeye çalışma; tanıdığın sesleri yakalamaya çalış.",14,TEXT,Typeface.NORMAL),space(8));Button b=button("AYETİ DİNLE");b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){loadAyahAndPlay(1,1,false,new Runnable(){public void run(){showDailyGrammar();}});}});c.addView(b,height(48,12));root.addView(c,cardLp());}
    private void showDailyGrammar(){
        enterScreen(new Runnable(){public void run(){showDailyGrammar();}});
        CourseData d=CourseData.get(this);final int gi=FehmStore.get(this).getInt("grammarIndex",0)%d.grammar.size();final CourseData.Grammar g=d.grammar.get(gi);shell("Kuralı ezberleme · örüntüyü fark et","FEHM · Mini Gramer",0);LinearLayout c=card();c.addView(tv("4 / GRAMER",10,GOLD,Typeface.BOLD),full());c.addView(tv(g.title,22,TEXT,Typeface.BOLD),space(8));c.addView(tv(g.meaning,16,GOLD,Typeface.BOLD),space(4));c.addView(tv(g.body+"\n\nÖrnek: "+g.example,14,TEXT,Typeface.NORMAL),space(8));Button next=button("AYET ÜZERİNDE BİRLEŞTİR");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore s=FehmStore.get(MainActivity.this);s.put("grammarIndex",""+(gi+1));s.put("wordCursor",""+(s.getInt("wordCursor",0)+5));DriveBackup.maybeAutoBackup(MainActivity.this);showLab(1,1,true);}});c.addView(next,height(46,12));root.addView(c,cardLp());
    }

    private void showListen(){
        enterScreen(new Runnable(){public void run(){showListen();}});
        shell("Duyduğunu anla · istersen sadece dinle","FEHM · Dinle",1);
        LinearLayout pure=card();pure.addView(tv("SADECE KUR’AN DİNLE · TEFEKKÜR",11,GOLD,Typeface.BOLD),full());pure.addView(tv("Ders yok, test yok. Sureyi Mahir el-Muaykıli’den kesintisiz dinle; ekranda Arapça, Latin harfli okunuş ve Türkçe meal birlikte aksın. Ekran kapansa da ses devam eder.",14,TEXT,Typeface.NORMAL),space(7));Button pb=button("DİNLE & TEFEKKÜR ET");pb.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showContemplationChooser();}});pure.addView(pb,height(48,10));root.addView(pure,cardLp());
        addVerseChooser(true);
        LinearLayout c=card();c.addView(tv("DİNLEME DERSİ",11,GOLD,Typeface.BOLD),full());c.addView(tv("Bu bölüm eğitim içindir: önce yalnız dinle, sonra Latin okunuşu aç, duyduğun parçaları fark et, en son meali gör ve tekrar dinle.",14,TEXT,Typeface.NORMAL),space(8));root.addView(c,cardLp());
    }
    private void addVerseChooser(final boolean listen){
        final FehmStore st=FehmStore.get(this);LinearLayout c=card();c.addView(tv("AYET SEÇ",11,GOLD,Typeface.BOLD),full());
        int defS=listen?st.getInt("lastListenSurah",1):st.getInt("lastLabSurah",1),defA=listen?st.getInt("lastListenAyah",1):st.getInt("lastLabAyah",1);
        final TextView selected=tv(QuranMeta.label(defS,defA),18,TEXT,Typeface.BOLD);c.addView(selected,space(7));
        LinearLayout labels=new LinearLayout(this);TextView ls=tv("SURE NO",10,GOLD,Typeface.BOLD),la=tv("AYET NO",10,GOLD,Typeface.BOLD);labels.addView(ls,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams lap=new LinearLayout.LayoutParams(0,-2,1);lap.leftMargin=dp(8);labels.addView(la,lap);c.addView(labels,space(10));
        final EditText s=input("Sure",String.valueOf(defS)),a=input("Ayet",String.valueOf(defA));s.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);a.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        LinearLayout row=new LinearLayout(this);row.addView(s,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.leftMargin=dp(8);row.addView(a,ap);c.addView(row,space(5));
        TextWatcher watcher=new TextWatcher(){public void beforeTextChanged(CharSequence cs,int st,int c,int a){}public void onTextChanged(CharSequence cs,int st,int b,int c){int su=Math.max(1,Math.min(114,parse(s.getText().toString(),1))),ay=Math.max(1,parse(a.getText().toString(),1));selected.setText(QuranMeta.label(su,ay));}public void afterTextChanged(Editable e){}};s.addTextChangedListener(watcher);a.addTextChangedListener(watcher);
        Button picker=outlineButton("SURE ADINDAN SEÇ");picker.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSurahPicker(s,selected,a);}});c.addView(picker,height(42,9));
        if(listen){
            LinearLayout quick=new LinearLayout(this);Button last=outlineButton("SON DİNLENEN");Button sug=outlineButton("BUGÜNÜN ÖNERİSİ");quick.addView(last,new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(42),1);qp.leftMargin=dp(8);quick.addView(sug,qp);c.addView(quick,space(8));
            last.setOnClickListener(new View.OnClickListener(){public void onClick(View v){s.setText(""+st.getInt("lastListenSurah",1));a.setText(""+st.getInt("lastListenAyah",1));}});
            sug.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int[] p=QuranMeta.suggestion();s.setText(""+p[0]);a.setText(""+p[1]);}});
        }
        Button go=button(listen?"ÖNCE SADECE DİNLE":"AYETİ AÇ");go.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int su=Math.max(1,Math.min(114,parse(s.getText().toString(),1))),ay=Math.max(1,parse(a.getText().toString(),1));if(listen)loadAyahAndPlay(su,ay,true,null);else showLab(su,ay,false);}});c.addView(go,height(48,10));root.addView(c,cardLp());
    }
    private void showSurahPicker(final EditText surahField,final TextView selected,final EditText ayahField){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(8));final EditText search=new EditText(this);search.setHint("Sure adı veya numara ara");search.setSingleLine(true);box.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));final ListView list=new ListView(this);final ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<String>(Arrays.asList(QuranMeta.labels())));list.setAdapter(ad);box.addView(list,new LinearLayout.LayoutParams(-1,dp(360)));
        final AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Sure seç").setView(box).setNegativeButton("Kapat",null).create();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){ad.getFilter().filter(s);}public void afterTextChanged(Editable e){}});
        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){public void onItemClick(AdapterView<?> p,View v,int pos,long id){String value=(String)p.getItemAtPosition(pos);int dot=value.indexOf('·');int su=parse(dot>0?value.substring(0,dot).trim():value,1);surahField.setText(""+su);ayahField.setText("1");selected.setText(QuranMeta.label(su,1));dlg.dismiss();}});dlg.show();
    }
    private void loadAyahAndPlay(final int surah,final int ayah,final boolean revealAfter,final Runnable after){
        Toast.makeText(this,"Ayet hazırlanıyor…",Toast.LENGTH_SHORT).show();
        new Thread(new Runnable(){public void run(){try{
            final QuranClient.Ayah x=QuranClient.fetch(MainActivity.this,surah,ayah);
            runOnUiThread(new Runnable(){public void run(){
                FehmStore st=FehmStore.get(MainActivity.this);st.put("lastListenSurah",""+surah);st.put("lastListenAyah",""+ayah);
                pendingLessonAyah=x;pendingLessonReveal=revealAfter;pendingLessonAfter=after;
                startBackgroundPlayback(surah,ayah,Reciters.ALAFASY_64,false);
                Toast.makeText(MainActivity.this,QuranMeta.label(surah,ayah)+" · yalnız dinle",Toast.LENGTH_SHORT).show();
            }});
        }catch(final Exception e){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}});}}}).start();
    }
    private void showListeningReveal(final QuranClient.Ayah x){
        enterScreen(new Runnable(){public void run(){showListeningReveal(x);}});
        FehmStore s=FehmStore.get(this);s.put("listenScore",""+Math.min(100,s.getInt("listenScore",0)+2));s.session("listen",1,1,0);DriveBackup.maybeAutoBackup(this);
        shell("Duy → tahmin et → gör → anla","FEHM · "+QuranMeta.label(x.surah,x.ayah),1);
        final LinearLayout c=card();c.addView(tv("1 / DUYDUĞUNU YAKALA",10,GOLD,Typeface.BOLD),full());c.addView(tv("Az önce ayeti yalnız dinledin. Duyduğun 1–2 parçayı zihninden tekrar et. Hazır olduğunda Latin okunuşu aç.",14,TEXT,Typeface.NORMAL),space(7));
        final TextView ar=tv("",28,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);final TextView latin=tv("",17,TEXT,Typeface.NORMAL);final TextView pieces=tv("",14,GOLD,Typeface.BOLD);final TextView meal=tv("",15,TEXT,Typeface.NORMAL);c.addView(ar,space(9));c.addView(latin,space(5));c.addView(pieces,space(8));c.addView(meal,space(8));
        final Button step1=button("2 · LATİN OKUNUŞU AÇ");final Button step2=outlineButton("3 · DUYDUĞUN PARÇALARI GÖR");final Button step3=outlineButton("4 · TÜRKÇE MEALİ GÖR");step2.setVisibility(View.GONE);step3.setVisibility(View.GONE);c.addView(step1,height(44,10));c.addView(step2,height(44,8));c.addView(step3,height(44,8));
        step1.setOnClickListener(new View.OnClickListener(){public void onClick(View v){ar.setText(x.arabic);latin.setText(x.latin);v.setVisibility(View.GONE);step2.setVisibility(View.VISIBLE);}});
        step2.setOnClickListener(new View.OnClickListener(){public void onClick(View v){String[] w=x.latin.trim().split("\\s+");StringBuilder b=new StringBuilder("Duyunca yakala: ");for(int i=0;i<Math.min(5,w.length);i++){if(i>0)b.append(" · ");b.append(w[i]);}pieces.setText(b.toString());v.setVisibility(View.GONE);step3.setVisibility(View.VISIBLE);}});
        step3.setOnClickListener(new View.OnClickListener(){public void onClick(View v){meal.setText("Diyanet meali:\n"+x.diyanet);v.setVisibility(View.GONE);}});
        Button again=outlineButton("5 · TEKRAR DİNLE");again.setOnClickListener(new View.OnClickListener(){public void onClick(View v){startBackgroundPlayback(x.surah,x.ayah,Reciters.ALAFASY_64,false);}});c.addView(again,height(44,10));Button lab=button("AYETİ LABORATUVARDA AÇ");lab.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLab(x.surah,x.ayah,false);}});c.addView(lab,height(46,8));root.addView(c,cardLp());
    }

    private void showContemplationChooser(){
        enterScreen(new Runnable(){public void run(){showContemplationChooser();}});
        shell("Dinle · takip et · tefekkür et","FEHM · Kur’an Dinle",1);final FehmStore st=FehmStore.get(this);final int defS=st.getInt("pureListenSurah",36),defA=st.getInt("pureListenAyah",1);LinearLayout c=card();c.addView(tv("TEFEKKÜR MODU",11,GOLD,Typeface.BOLD),full());c.addView(tv("Eğitim sorusu çıkmaz. Seçtiğin yerden sure sonuna kadar kesintisiz devam eder. Arapça + Latin okunuş + Diyanet meali aynı ekranda görünür.",13,TEXT,Typeface.NORMAL),space(7));final TextView selected=tv(QuranMeta.label(defS,defA),18,TEXT,Typeface.BOLD);c.addView(selected,space(8));LinearLayout row=new LinearLayout(this);final EditText su=input("Sure",String.valueOf(defS)),ay=input("Ayet",String.valueOf(defA));su.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);ay.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);row.addView(su,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.leftMargin=dp(8);row.addView(ay,ap);c.addView(row,space(8));TextWatcher w=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence cs,int st,int b,int c){int ss=Math.max(1,Math.min(114,parse(su.getText().toString(),defS))),aa=QuranMeta.clampAyah(ss,parse(ay.getText().toString(),1));selected.setText(QuranMeta.label(ss,aa));}public void afterTextChanged(Editable e){}};su.addTextChangedListener(w);ay.addTextChangedListener(w);Button pick=outlineButton("SURE ADINDAN SEÇ");pick.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSurahPicker(su,selected,ay);}});c.addView(pick,height(42,8));
        final Spinner rec=new Spinner(this);ArrayAdapter<String> ra=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,Arrays.asList(Reciters.names()));rec.setAdapter(ra);String saved=st.get("pureReciter",Reciters.MAHER_64);String[] ids=Reciters.ids();int sel=0;for(int i=0;i<ids.length;i++)if(ids[i].equals(saved))sel=i;rec.setSelection(sel);c.addView(tv("SES",10,GOLD,Typeface.BOLD),space(10));c.addView(rec,height(50,5));
        Button start=button("KESİNTİSİZ DİNLEMEYİ BAŞLAT");start.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int ss=Math.max(1,Math.min(114,parse(su.getText().toString(),defS))),aa=QuranMeta.clampAyah(ss,parse(ay.getText().toString(),1));String rr=Reciters.ids()[Math.max(0,rec.getSelectedItemPosition())];st.put("pureListenSurah",""+ss);st.put("pureListenAyah",""+aa);st.put("pureReciter",rr);startBackgroundPlayback(ss,aa,rr,true);showContemplation(ss,aa,rr);}});c.addView(start,height(48,10));
        final TextView dlStatus=tv("İstersen bu sureyi çevrimdışı dinlemek için sesini telefona alabilirsin.",12,MUTED,Typeface.NORMAL);c.addView(dlStatus,space(9));Button offline=outlineButton("BU SUREYİ ÇEVRİMDIŞI İNDİR");offline.setOnClickListener(new View.OnClickListener(){public void onClick(final View v){final int ss=Math.max(1,Math.min(114,parse(su.getText().toString(),defS)));final String rr=Reciters.ids()[Math.max(0,rec.getSelectedItemPosition())];v.setEnabled(false);new Thread(new Runnable(){public void run(){try{QuranAudioCache.downloadSurah(MainActivity.this,rr,ss,new QuranAudioCache.Progress(){public void onProgress(final int done,final int total,final String text){runOnUiThread(new Runnable(){public void run(){dlStatus.setText("İndiriliyor: "+done+" / "+total+" · "+text);}});}});runOnUiThread(new Runnable(){public void run(){dlStatus.setText(QuranMeta.name(ss)+" çevrimdışı ses paketi hazır.");v.setEnabled(true);}});}catch(final Exception e){runOnUiThread(new Runnable(){public void run(){dlStatus.setText("İndirme hatası: "+e.getMessage());v.setEnabled(true);}});}}}).start();}});c.addView(offline,height(44,8));root.addView(c,cardLp());
    }

    private void showContemplation(final int surah,final int ayah,final String reciter){
        enterScreen(new Runnable(){public void run(){showContemplation(surah,ayah,reciter);}});
        contemplationSurah=surah;contemplationAyah=ayah;contemplationReciter=reciter;shell("Ders yok · sadece dinle ve takip et","FEHM · Tefekkür Dinleme",1);LinearLayout top=card();top.addView(tv(Reciters.name(reciter),12,GOLD,Typeface.BOLD),full());top.addView(tv("Ekranı kapatabilirsin; ses arka planda sürer. Uygulamaya döndüğünde o an okunan ayet tekrar ekrana gelir.",13,MUTED,Typeface.NORMAL),space(6));LinearLayout row=new LinearLayout(this);Button stop=smallButton("DURDUR",BAD),back=smallButton("SEÇİM",PANEL2);row.addView(stop,new LinearLayout.LayoutParams(0,dp(44),1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(44),1);bp.leftMargin=dp(8);row.addView(back,bp);stop.setOnClickListener(new View.OnClickListener(){public void onClick(View v){stopBackgroundPlayback();}});back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showContemplationChooser();}});top.addView(row,space(9));root.addView(top,cardLp());contemplationHolder=new LinearLayout(this);contemplationHolder.setOrientation(LinearLayout.VERTICAL);root.addView(contemplationHolder,cardLp());loadContemplationVerse(surah,ayah,reciter);
    }

    private void loadContemplationVerse(final int surah,final int ayah,final String reciter){
        if(contemplationHolder==null)return;
        contemplationHolder.removeAllViews();
        contemplationHolder.addView(tv(QuranMeta.label(surah,ayah)+" hazırlanıyor…",14,MUTED,Typeface.NORMAL),full());
        new Thread(new Runnable(){public void run(){
            try{
                final QuranClient.Ayah x=QuranClient.fetch(MainActivity.this,surah,ayah);
                runOnUiThread(new Runnable(){public void run(){
                    if(contemplationHolder==null)return;
                    contemplationHolder.removeAllViews();
                    LinearLayout c=card();
                    c.addView(tv(QuranMeta.label(x.surah,x.ayah),18,GOLD,Typeface.BOLD),full());
                    TextView ar=tv(x.arabic,29,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,space(9));
                    c.addView(tv("LATİN HARFLİ OKUNUŞ",10,GOLD,Typeface.BOLD),space(13));
                    c.addView(tv(x.latin,17,TEXT,Typeface.NORMAL),space(5));
                    c.addView(tv("DİYANET MEALİ",10,GOLD,Typeface.BOLD),space(13));
                    c.addView(tv(x.diyanet,16,TEXT,Typeface.NORMAL),space(5));
                    Button lab=outlineButton("AYETİ LABORATUVARDA AÇ");
                    lab.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLab(x.surah,x.ayah,false);}});
                    c.addView(lab,height(42,12));
                    contemplationHolder.addView(c,full());
                }});
            }catch(final Exception e){
                runOnUiThread(new Runnable(){public void run(){
                    if(contemplationHolder!=null){contemplationHolder.removeAllViews();contemplationHolder.addView(tv(e.getMessage(),14,BAD,Typeface.NORMAL),full());}
                }});
            }
        }}).start();
    }

    private void startBackgroundPlayback(int surah,int ayah,String reciter,boolean continuous){backgroundPlaying=true;getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",true).putInt("surah",surah).putInt("ayah",ayah).putString("reciter",reciter).putBoolean("continuous",continuous).apply();Intent i=new Intent(this,QuranPlaybackService.class);i.setAction(QuranPlaybackService.ACTION_START);i.putExtra(QuranPlaybackService.EXTRA_SURAH,surah);i.putExtra(QuranPlaybackService.EXTRA_AYAH,ayah);i.putExtra(QuranPlaybackService.EXTRA_RECITER,reciter);i.putExtra(QuranPlaybackService.EXTRA_CONT,continuous);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);updatePersistentPlayer();}
    private void stopBackgroundPlayback(){pendingLessonAyah=null;pendingLessonReveal=false;pendingLessonAfter=null;backgroundPlaying=false;getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",false).apply();Intent i=new Intent(this,QuranPlaybackService.class);i.setAction(QuranPlaybackService.ACTION_STOP);startService(i);updatePersistentPlayer();Toast.makeText(this,"Kur’an dinleme durduruldu.",Toast.LENGTH_SHORT).show();}

    private void startLocalDataDownload(final TextView status,final Button button){
        if(button!=null){button.setEnabled(false);button.setText("HAZIRLANIYOR…");}
        if(status!=null)status.setText("Yerel Kur’an paketi hazırlanıyor…");
        new Thread(new Runnable(){public void run(){try{
            QuranDataManager.downloadEverything(MainActivity.this,new QuranDataManager.Progress(){public void onProgress(final int done,final int total,final String text){runOnUiThread(new Runnable(){public void run(){if(status!=null)status.setText(text+" · "+done+" / "+total);}});}});
            runOnUiThread(new Runnable(){public void run(){if(status!=null)status.setText(QuranDataManager.status(MainActivity.this)+"\nHazır · ayet ve sözlük aramaları artık yerelden çalışır.");if(button!=null){button.setText("YEREL PAKET HAZIR");button.setEnabled(false);}Toast.makeText(MainActivity.this,"Yerel Kur’an ve dil paketi hazır.",Toast.LENGTH_LONG).show();}});
        }catch(final Exception e){runOnUiThread(new Runnable(){public void run(){if(status!=null)status.setText("İndirme yarıda kaldı: "+e.getMessage()+"\nTekrar bastığında kaldığı veriler korunarak devam eder.");if(button!=null){button.setText("TEKRAR DENE");button.setEnabled(true);}Toast.makeText(MainActivity.this,"Yerel paket: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}}}).start();
    }

    private void showRead(){
        enterScreen(new Runnable(){public void run(){showRead();}});
        shell("Gördüğünü oku","FEHM · Elif-Bâ ve Okuma",2);final CourseData d=CourseData.get(this);final int idx=FehmStore.get(this).getInt("letterIndex",0)%Math.max(1,d.letters.size());LinearLayout intro=card();intro.addView(tv("ELİF-BÂ · ZORUNLU KAPI DEĞİL",11,GOLD,Typeface.BOLD),full());intro.addView(tv("Latin okunuş desteği her zaman açık kalabilir. Amaç Arap harflerini yavaş yavaş tanımak; Kur’an dinleme ve anlam çalışmasını durdurmak değil.",14,TEXT,Typeface.NORMAL),space(8));root.addView(intro,cardLp());
        for(int i=0;i<Math.min(6,d.letters.size());i++){int p=(idx+i)%d.letters.size();final CourseData.Letter l=d.letters.get(p);LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.addView(center(tv(l.arabic,36,TEXT,Typeface.BOLD)),new LinearLayout.LayoutParams(dp(64),dp(58)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(tv(l.name.toUpperCase(new Locale("tr","TR"))+" · "+l.sound,15,GOLD,Typeface.BOLD),full());tx.addView(tv(l.note+" · Örnek: "+l.example,13,MUTED,Typeface.NORMAL),space(4));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));c.addView(row,full());root.addView(c,cardLp());}
        if(!d.marks.isEmpty()){LinearLayout marks=card();marks.addView(tv("HAREKELER · SESİ DEĞİŞTİREN İŞARETLER",11,GOLD,Typeface.BOLD),full());for(int i=0;i<Math.min(4,d.marks.size());i++){CourseData.Letter m=d.marks.get(i);marks.addView(tv(m.arabic+"   "+m.name+" · "+m.sound+"\n"+m.note,14,TEXT,Typeface.NORMAL),space(7));}root.addView(marks,cardLp());}
        Button more=button("SONRAKİ HARFLER");more.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("letterIndex",""+(idx+6));DriveBackup.maybeAutoBackup(MainActivity.this);showRead();}});root.addView(more,height(48,12));
    }

    private void showLearn(){
        enterScreen(new Runnable(){public void run(){showLearn();}});
        shell("Kelime · kök · gramer · ayet","FEHM · Öğren",3);
        addLearnCard("KELİME & KÖK","En sık karşılaşılan Kur’an kelimelerini kök aileleri, ayet örnekleri ve aralıklı tekrar ile öğren.",new View.OnClickListener(){public void onClick(View v){showWords();}});
        addLearnCard("KUR’AN SÖZLÜĞÜ · KÖK ARAMA","Latin okunuş, Türkçe, Arapça, lemma veya kök yazarak ara. Bir kökten Kur’an’daki kullanım yerlerine ve gramer bilgisine git.",new View.OnClickListener(){public void onClick(View v){showDictionary();}});
        addLearnCard("GRAMER","Kuralları küçük parçalarda, önce örnek sonra kural yöntemiyle fark et.",new View.OnClickListener(){public void onClick(View v){showGrammar();}});
        addLearnCard("AYET ÇÖZÜMLEME · KUR’AN LABORATUVARI","Bir ayeti aç; Arapça, Latin okunuş, mealler, ses ve seviyene göre FEHM AI öğretimiyle incele.",new View.OnClickListener(){public void onClick(View v){showLabChooser();}});
        addLearnCard("TEKRAR & MİNİ SINAV","Önce zamanı gelen ve karıştırdığın kelimelerden başlayarak aktif hatırlama testi yap.",new View.OnClickListener(){public void onClick(View v){showQuiz();}});
    }
    private void addLearnCard(String title,String body,View.OnClickListener l){LinearLayout c=card();c.addView(tv(title,18,GOLD,Typeface.BOLD),full());c.addView(tv(body,14,TEXT,Typeface.NORMAL),space(7));Button b=button("AÇ");b.setOnClickListener(l);c.addView(b,height(44,10));root.addView(c,cardLp());}
    private void showWords(){
        enterScreen(new Runnable(){public void run(){showWords();}});
        shell("Aktif hatırlama + kök ailesi","FEHM · Kelimeler",3);final CourseData d=CourseData.get(this);final int cursor=FehmStore.get(this).getInt("freeWordCursor",0)%Math.max(1,d.words.size());
        for(int i=0;i<8;i++){final CourseData.Word w=d.words.get((cursor+i)%d.words.size());LinearLayout c=card();c.addView(tv(w.arabic+"   "+w.latin,22,TEXT,Typeface.BOLD),full());c.addView(tv(w.meaning,15,GOLD,Typeface.BOLD),space(6));c.addView(tv("Kök: "+formatRoot(w.root)+"\nAile: "+w.family+"\nSeviye: "+FehmStore.get(this).level("word",w.id)+"/6",13,MUTED,Typeface.NORMAL),space(5));
            if(w.exampleArabic!=null&&!w.exampleArabic.isEmpty()){final TextView ex=tv("",13,TEXT,Typeface.NORMAL);Button eb=outlineButton("AYET ÖRNEĞİNİ GÖR");eb.setOnClickListener(new View.OnClickListener(){public void onClick(View v){ex.setText(w.exampleArabic+"\n"+w.exampleLatin+"\n"+w.exampleMeaning);v.setVisibility(View.GONE);}});c.addView(eb,height(40,8));c.addView(ex,space(5));}
            LinearLayout row=new LinearLayout(this);Button h=smallButton("ZOR",BAD),o=smallButton("KOLAY",GOOD);row.addView(h,new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.leftMargin=dp(8);row.addView(o,p);h.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,2);Toast.makeText(MainActivity.this,"Bugünkü tekrar kuyruğuna alındı",Toast.LENGTH_SHORT).show();}});o.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,4);Toast.makeText(MainActivity.this,"İlerleme kaydedildi",Toast.LENGTH_SHORT).show();}});c.addView(row,space(9));root.addView(c,cardLp());
        }
        Button next=button("SONRAKİ KELİMELER");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("freeWordCursor",""+(cursor+8));showWords();}});root.addView(next,height(48,12));
    }
    private void showDictionary(){showDictionary("");}
    private void showDictionary(final String initial){
        enterScreen(new Runnable(){public void run(){showDictionary(initial);}});
        shell("Kelimeyi, kökü ve Kur’an’daki izini bul","FEHM · Kur’an Sözlüğü",3);LinearLayout intro=card();intro.addView(tv("LATİN · TÜRKÇE · ARAPÇA · KÖK",11,GOLD,Typeface.BOLD),full());intro.addView(tv("Örnek: rahmân, merhamet, رحمة veya r-h-m. Kökler başlangıç seviyesinde üçlü gösterilir: ي س ر · y-s-r · kolaylık. Böylece Arap alfabesini henüz öğrenmeden de sözlüğü kullanabilirsin.",13,TEXT,Typeface.NORMAL),space(7));intro.addView(tv(QuranDataManager.status(this),12,MUTED,Typeface.NORMAL),space(7));root.addView(intro,cardLp());final EditText q=input("Kelime, anlam veya kök yaz",initial==null?"":initial);root.addView(q,height(52,10));final LinearLayout out=new LinearLayout(this);out.setOrientation(LinearLayout.VERTICAL);Button search=button("SÖZLÜKTE ARA");search.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runDictionarySearch(q.getText().toString(),out);}});root.addView(search,height(48,8));root.addView(out,space(6));if(initial!=null&&!initial.trim().isEmpty())runDictionarySearch(initial,out);
    }

    private void runDictionarySearch(final String query,final LinearLayout out){
        final String q=query==null?"":query.trim();out.removeAllViews();if(q.length()<1){out.addView(tv("Aramak istediğin kelimeyi veya kökü yaz.",13,MUTED,Typeface.NORMAL),full());return;}out.addView(tv("Aranıyor…",13,MUTED,Typeface.NORMAL),full());
        new Thread(new Runnable(){public void run(){
            final ArrayList<CourseData.Word> curated=new ArrayList<CourseData.Word>();String ql=normalizeSearch(q);for(CourseData.Word w:CourseData.get(MainActivity.this).words){String hay=normalizeSearch(w.arabic+" "+w.latin+" "+w.meaning+" "+w.root+" "+w.family);if(hay.contains(ql))curated.add(w);}
            final QuranLocalStore db=QuranLocalStore.get(MainActivity.this);String rootAlias=findRootAlias(q);final ArrayList<QuranLocalStore.MorphHit> morph=db.searchMorph(rootAlias.isEmpty()?q:rootAlias,60);final ArrayList<QuranClient.Ayah> verses=db.searchVerses(q,15);
            runOnUiThread(new Runnable(){public void run(){out.removeAllViews();
                if(curated.isEmpty()&&morph.isEmpty()&&verses.isEmpty()){out.addView(tv(QuranDataManager.morphReady(MainActivity.this)?"Sonuç bulunamadı. Türkçe anlam, Arapça kelime veya Latin kökü (ör. y-s-r / r-h-m) deneyebilirsin.":"Sonuç bulunamadı. Tam kök araması için önce yerel Kur’an + dil paketini indir.",13,MUTED,Typeface.NORMAL),full());return;}
                if(!curated.isEmpty()){out.addView(tv("TÜRKÇE SÖZLÜK",11,GOLD,Typeface.BOLD),space(8));for(CourseData.Word w:curated){LinearLayout c=card();TextView ar=tv(w.arabic,25,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,full());c.addView(tv(w.latin+" · "+w.meaning,15,GOLD,Typeface.BOLD),space(4));c.addView(tv("Kök: "+formatRoot(w.root)+"\nAile: "+w.family,13,MUTED,Typeface.NORMAL),space(5));out.addView(c,cardLp());}}
                if(!morph.isEmpty()){out.addView(tv("KELİME · KÖK · LEMMA · GRAMER · AYETLER",11,GOLD,Typeface.BOLD),space(14));for(final QuranLocalStore.MorphHit h:morph){LinearLayout c=card();TextView ar=tv(h.formAr,25,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,full());if(h.formLatin!=null&&!h.formLatin.isEmpty())c.addView(tv(h.formLatin,15,GOLD,Typeface.BOLD),space(3));String lemma=h.lemmaAr==null||h.lemmaAr.isEmpty()?"—":h.lemmaAr+(h.lemmaLatin==null||h.lemmaLatin.isEmpty()?"":" · "+h.lemmaLatin);c.addView(tv("Kök: "+formatRoot(h.rootAr,h.rootLatin)+"\nLemma: "+lemma+"\nGramer: "+posTr(h.pos)+"\nYer: "+h.ref(),13,TEXT,Typeface.NORMAL),space(5));QuranClient.Ayah vx=db.getVerse(h.surah,h.ayah);if(vx!=null&&!vx.diyanet.isEmpty())c.addView(tv(shortText(vx.diyanet,180),12,MUTED,Typeface.NORMAL),space(6));Button explain=outlineButton("TÜRKÇE ANLAM ALANINI DERİNLEŞTİR");final TextView explainOut=tv("",12,MUTED,Typeface.NORMAL);explain.setOnClickListener(new View.OnClickListener(){public void onClick(View v){explainMorph(h,explainOut,(Button)v);}});c.addView(explain,height(40,8));c.addView(explainOut,space(4));Button open=outlineButton("AYETİ LABORATUVARDA AÇ");open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLab(h.surah,h.ayah,false);}});c.addView(open,height(40,8));out.addView(c,cardLp());}}
                if(!verses.isEmpty()){out.addView(tv("METİN / MEAL EŞLEŞMELERİ",11,GOLD,Typeface.BOLD),space(14));for(final QuranClient.Ayah x:verses){LinearLayout c=card();c.addView(tv(QuranMeta.label(x.surah,x.ayah),14,GOLD,Typeface.BOLD),full());TextView ar=tv(x.arabic,20,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,space(5));c.addView(tv(x.latin,13,MUTED,Typeface.NORMAL),space(4));c.addView(tv(shortText(x.diyanet,220),13,TEXT,Typeface.NORMAL),space(5));Button open=outlineButton("AYETİ AÇ");open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLab(x.surah,x.ayah,false);}});c.addView(open,height(40,7));out.addView(c,cardLp());}}
            }});
        }}).start();
    }
    private void explainMorph(final QuranLocalStore.MorphHit h,final TextView out,final Button button){
        final String key=(h.rootAr+"|"+h.lemmaAr+"|"+h.pos).replace(" ","");final android.content.SharedPreferences cache=getSharedPreferences("fehm_dictionary_ai",MODE_PRIVATE);String cached=cache.getString(key,"");if(!cached.isEmpty()){out.setText(cached);button.setVisibility(View.GONE);return;}if(!GeminiClient.configured(this)){out.setText("Türkçe anlam alanı açıklaması için Gemini anahtarını Ayarlar’dan gir. Kök, lemma ve ayet yerleri yine çevrimdışı çalışır.");return;}button.setEnabled(false);out.setText("FEHM kısa sözlük açıklaması hazırlıyor…");new Thread(new Runnable(){public void run(){try{QuranClient.Ayah x=QuranLocalStore.get(MainActivity.this).getVerse(h.surah,h.ayah);String context=x==null?"":("Ayet: "+QuranMeta.label(x.surah,x.ayah)+"\nArapça: "+x.arabic+"\nLatin: "+x.latin+"\nDiyanet: "+x.diyanet);String prompt="Kur’an Arapçası için kısa Türkçe sözlük açıklaması yaz. Kelime/biçim: "+h.formAr+" ("+h.formLatin+"); lemma: "+h.lemmaAr+" ("+h.lemmaLatin+"); kök: "+h.rootAr+" ("+h.rootLatin+"); gramer türü: "+posTr(h.pos)+". "+context+"\nEn fazla 5 kısa satır: temel Türkçe anlam, anlam alanı, bu ayetteki muhtemel karşılık, varsa önemli bağlam notu. Kullanıcı Arap alfabesini henüz öğreniyor; yazdığın her Arapça kelime/kök/lemma yanında Latin okunuşu da olsun. Tefsir hükmü verme, kök uydurma, Markdown kullanma.";final String ans=TextClean.plain(GeminiClient.generate(MainActivity.this,prompt,false));cache.edit().putString(key,ans).apply();runOnUiThread(new Runnable(){public void run(){out.setText(ans);button.setVisibility(View.GONE);}});}catch(final Exception e){runOnUiThread(new Runnable(){public void run(){out.setText(e.getMessage());button.setEnabled(true);}});}}}).start();
    }
    private String posTr(String p){if(p==null)return "—";if("N".equals(p))return "İsim";if("V".equals(p))return "Fiil";if("ADJ".equals(p))return "Sıfat";if("PN".equals(p))return "Özel isim";if("P".equals(p))return "Edat / harf";if("PRON".equals(p))return "Zamir";if("REL".equals(p))return "İlgi zamiri";if("CONJ".equals(p))return "Bağlaç";if("NEG".equals(p))return "Olumsuzluk edatı";return p;}
    private String shortText(String x,int n){if(x==null)return "";x=TextClean.plain(x);return x.length()<=n?x:x.substring(0,n)+"…";}

    private long localQuranBytes(){long n=0;try{java.io.File f=getDatabasePath("fehm_quran_local.db");if(f!=null&&f.exists())n+=f.length();java.io.File wal=new java.io.File(f.getAbsolutePath()+"-wal"),shm=new java.io.File(f.getAbsolutePath()+"-shm");if(wal.exists())n+=wal.length();if(shm.exists())n+=shm.length();}catch(Exception ignored){}return n;}
    private String formatBytes(long b){if(b<1024)return b+" B";double kb=b/1024.0;if(kb<1024)return String.format(Locale.US,"%.1f KB",kb);double mb=kb/1024.0;if(mb<1024)return String.format(Locale.US,"%.1f MB",mb);return String.format(Locale.US,"%.2f GB",mb/1024.0);}

    private String normalizeSearch(String x){if(x==null)return "";return x.toLowerCase(new Locale("tr","TR")).replace("-","").replace(" ","").replace("â","a").replace("î","i").replace("û","u");}
    private String rootKey(String x){if(x==null)return "";return x.replace(" ","").replace("ـ","").trim();}
    private String spacedRoot(String x){String k=rootKey(x);if(k.isEmpty())return "—";StringBuilder b=new StringBuilder();for(int i=0;i<k.length();i++){if(i>0)b.append(' ');b.append(k.charAt(i));}return b.toString();}
    private String rootLatinFromArabic(String ar){String k=rootKey(ar);StringBuilder b=new StringBuilder();for(int i=0;i<k.length();i++){String z=latinLetter(k.charAt(i));if(z.isEmpty())continue;if(b.length()>0)b.append('-');b.append(z);}return b.length()==0?"—":b.toString();}
    private String latinLetter(char c){switch(c){case 'ا':case 'أ':case 'إ':return "a";case 'ب':return "b";case 'ت':return "t";case 'ث':return "s";case 'ج':return "c";case 'ح':return "h";case 'خ':return "h";case 'د':return "d";case 'ذ':return "z";case 'ر':return "r";case 'ز':return "z";case 'س':return "s";case 'ش':return "ş";case 'ص':return "s";case 'ض':return "d";case 'ط':return "t";case 'ظ':return "z";case 'ع':return "‘";case 'غ':return "ğ";case 'ف':return "f";case 'ق':return "k";case 'ك':return "k";case 'ل':return "l";case 'م':return "m";case 'ن':return "n";case 'ه':return "h";case 'و':return "v";case 'ي':case 'ى':return "y";default:return "";}}
    private String rootTurkish(String rootAr){String key=rootKey(rootAr);if(key.isEmpty())return "—";if("يسر".equals(key))return "kolaylık · kolay olmak/kolaylaştırmak";if("عسر".equals(key))return "zorluk · güçlük";if("قرأ".equals(key))return "okumak · tilavet etmek";if("سمع".equals(key))return "işitmek · duymak";if("قول".equals(key))return "söylemek · söz";if("عمل".equals(key))return "yapmak · amel";if("فهم".equals(key))return "anlamak · kavramak";LinkedHashSet<String> meanings=new LinkedHashSet<String>();for(CourseData.Word w:CourseData.get(this).words){if(key.equals(rootKey(w.root))&&w.meaning!=null&&!w.meaning.trim().isEmpty())meanings.add(w.meaning.trim());if(meanings.size()>=2)break;}if(meanings.isEmpty())return "Türkçe anlam alanı için aşağıdaki açıklamayı aç";StringBuilder b=new StringBuilder();for(String m:meanings){if(b.length()>0)b.append(" / ");b.append(m);}return b.toString();}
    private String formatRoot(String rootAr){return formatRoot(rootAr,rootLatinFromArabic(rootAr));}
    private String formatRoot(String rootAr,String rootLatin){if(rootAr==null||rootAr.trim().isEmpty())return "—";String lat=(rootLatin==null||rootLatin.trim().isEmpty())?rootLatinFromArabic(rootAr):rootLatin;if(lat.indexOf('-')<0&&lat.length()>1){StringBuilder b=new StringBuilder();for(int i=0;i<lat.length();i++){if(i>0)b.append('-');b.append(lat.charAt(i));}lat=b.toString();}return spacedRoot(rootAr)+" · "+lat+" · "+rootTurkish(rootAr);}
    private String findRootAlias(String q){String nq=normalizeSearch(q);if(nq.isEmpty())return "";if(nq.contains("kolay"))return "يسر";if(nq.contains("zorluk")||nq.contains("güçlük"))return "عسر";for(CourseData.Word w:CourseData.get(this).words){String h=normalizeSearch(w.meaning+" "+w.family+" "+w.latin+" "+w.arabic);if(h.contains(nq)&&w.root!=null&&!w.root.isEmpty())return rootKey(w.root);}return "";}

    private void showGrammar(){
        enterScreen(new Runnable(){public void run(){showGrammar();}});
        shell("Sarf-nahiv, ama sıfırdan","FEHM · Gramer",3);final CourseData d=CourseData.get(this);final int cursor=FehmStore.get(this).getInt("freeGrammarCursor",0)%Math.max(1,d.grammar.size());
        LinearLayout intro=card();intro.addView(tv("ÖNCE ÖRNEK · SONRA KURAL",11,GOLD,Typeface.BOLD),full());intro.addView(tv("Başlangıçta teknik isimleri ezberlemek zorunda değilsin. Aynı yapıyı ayetlerde tekrar gördükçe FEHM kuralın adını ve ayrıntısını kademeli olarak açar.",13,MUTED,Typeface.NORMAL),space(6));root.addView(intro,cardLp());
        for(int i=0;i<5;i++){CourseData.Grammar g=d.grammar.get((cursor+i)%d.grammar.size());LinearLayout c=card();c.addView(tv(g.title,19,GOLD,Typeface.BOLD),full());c.addView(tv(g.meaning,15,TEXT,Typeface.BOLD),space(5));c.addView(tv(g.body+"\n\nÖrnek: "+g.example,14,TEXT,Typeface.NORMAL),space(7));root.addView(c,cardLp());}
        Button next=button("SONRAKİ GRAMER DERSLERİ");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("freeGrammarCursor",""+(cursor+5));showGrammar();}});root.addView(next,height(48,12));
    }

    private void showQuiz(){
        CourseData d=CourseData.get(this);FehmStore st=FehmStore.get(this);final ArrayList<CourseData.Word> deck=new ArrayList<CourseData.Word>();ArrayList<String> due=st.due("word",5);for(String id:due){CourseData.Word w=findWord(id);if(w!=null&&!deck.contains(w))deck.add(w);}int cursor=st.getInt("quizCursor",0),g=0;while(deck.size()<5&&g<d.words.size()*2){CourseData.Word w=d.words.get((cursor+g)%d.words.size());if(!deck.contains(w))deck.add(w);g++;}showQuizQuestion(deck,0,0);
    }
    private void showQuizQuestion(final ArrayList<CourseData.Word> deck,final int idx,final int score){
        enterScreen(new Runnable(){public void run(){showQuizQuestion(deck,idx,score);}});
        if(idx>=deck.size()){FehmStore st=FehmStore.get(this);st.session("word_quiz",score,deck.size(),0);st.put("quizCursor",""+(st.getInt("quizCursor",0)+deck.size()));DriveBackup.maybeAutoBackup(this);shell("Aktif hatırlama tamamlandı","FEHM · Mini Sınav",3);LinearLayout done=card();done.addView(tv("SONUÇ",11,GOLD,Typeface.BOLD),full());done.addView(center(tv(score+" / "+deck.size(),34,TEXT,Typeface.BOLD)),space(8));done.addView(tv(score==deck.size()?"Harika. Hepsini aktif olarak hatırladın.":"Yanlışların ve karıştırdıkların tekrar kuyruğuna alındı.",14,MUTED,Typeface.NORMAL),space(8));Button back=button("ÖĞREN MENÜSÜNE DÖN");back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLearn();}});done.addView(back,height(44,12));root.addView(done,cardLp());return;}
        final CourseData.Word target=deck.get(idx);shell("Cevabı zihninden geri çağır","FEHM · Sınav "+(idx+1)+"/"+deck.size(),3);LinearLayout c=card();c.addView(center(tv(target.arabic,36,TEXT,Typeface.BOLD)),full());c.addView(center(tv(target.latin,17,GOLD,Typeface.BOLD)),space(5));c.addView(tv("Bu kelimenin temel anlamını seç.",14,MUTED,Typeface.NORMAL),space(10));
        final ArrayList<CourseData.Word> opts=new ArrayList<CourseData.Word>();opts.add(target);CourseData d=CourseData.get(this);int seed=(target.id.hashCode() & 0x7fffffff)+idx*31;int k=0;while(opts.size()<4&&k<d.words.size()*2){CourseData.Word w=d.words.get((seed+k)%d.words.size());if(!opts.contains(w)&&!w.meaning.equals(target.meaning))opts.add(w);k++;}Collections.shuffle(opts,new Random(seed));
        for(final CourseData.Word o:opts){Button b=outlineButton(o.meaning);b.setTextSize(11);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){boolean ok=o.id.equals(target.id);FehmStore.get(MainActivity.this).review("word",target.id,ok?5:2);Toast.makeText(MainActivity.this,ok?"Doğru":"Doğru cevap: "+target.meaning,Toast.LENGTH_SHORT).show();showQuizQuestion(deck,idx+1,score+(ok?1:0));}});c.addView(b,height(48,8));}root.addView(c,cardLp());
    }

    private void showLabChooser(){enterScreen(new Runnable(){public void run(){showLabChooser();}});shell("Kelime kelime düşün","FEHM · Kur’an Laboratuvarı",3);addVerseChooser(false);}
    private void showLab(final int surah,final int ayah,final boolean fromDaily){
        enterScreen(new Runnable(){public void run(){showLab(surah,ayah,fromDaily);}});
        FehmStore.get(this).put("lastLabSurah",""+surah);FehmStore.get(this).put("lastLabAyah",""+ayah);shell("Oku · çöz · karşılaştır · yorumla","FEHM · Ayet Laboratuvarı",3);final LinearLayout wait=card();wait.addView(tv(QuranMeta.label(surah,ayah)+" yükleniyor…",15,MUTED,Typeface.NORMAL),full());root.addView(wait,cardLp());
        new Thread(new Runnable(){public void run(){try{final QuranClient.Ayah x=QuranClient.fetch(MainActivity.this,surah,ayah);runOnUiThread(new Runnable(){public void run(){renderLab(x);}});}catch(final Exception e){runOnUiThread(new Runnable(){public void run(){wait.removeAllViews();wait.addView(tv(e.getMessage(),14,BAD,Typeface.NORMAL),full());}});}}}).start();
    }
    private void renderLab(final QuranClient.Ayah x){
        shell("Oku · çöz · karşılaştır · yorumla","FEHM · "+QuranMeta.label(x.surah,x.ayah),3);
        LinearLayout c=card();c.addView(tv("ARAPÇA",10,GOLD,Typeface.BOLD),full());TextView ar=tv(x.arabic,28,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,space(7));c.addView(tv("LATİN HARFLİ OKUNUŞ",10,GOLD,Typeface.BOLD),space(12));c.addView(tv(x.latin,17,TEXT,Typeface.NORMAL),space(5));c.addView(tv("DİYANET MEALİ",10,GOLD,Typeface.BOLD),space(12));c.addView(tv(x.diyanet,15,TEXT,Typeface.NORMAL),space(5));c.addView(tv("KARŞILAŞTIR",10,GOLD,Typeface.BOLD),space(12));c.addView(tv("Elmalılı: "+x.elmalili+"\n\nDiyanet Vakfı: "+x.vakif,13,MUTED,Typeface.NORMAL),space(5));Button listen=button("AYETİ DİNLE");listen.setOnClickListener(new View.OnClickListener(){public void onClick(View v){startBackgroundPlayback(x.surah,x.ayah,Reciters.ALAFASY_64,false);}});c.addView(listen,height(44,12));Button words=outlineButton("AYETİN KELİME · KÖK HARİTASI");words.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showVerseWords(x);}});c.addView(words,height(44,8));Button dict=outlineButton("KUR’AN SÖZLÜĞÜNÜ AÇ");dict.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showDictionary();}});c.addView(dict,height(44,8));root.addView(c,cardLp());
        final LinearLayout ai=card();int stage=learningStage();ai.addView(tv("FEHM AI · SEVİYENE GÖRE ÖĞRET",11,GOLD,Typeface.BOLD),full());ai.addView(tv("Öğretim seviyesi: "+stageName(stage)+". Önce az ve gerekli bilgiyi öğren; istersen sonra derine in.",13,MUTED,Typeface.NORMAL),space(7));
        final LinearLayout output=new LinearLayout(this);output.setOrientation(LinearLayout.VERTICAL);
        Button teach=button("BANA ŞİMDİ ÖĞRET");Button deep=outlineButton("DERİNLEŞTİR · KÖK + GRAMER + BAĞLAM");teach.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runAiLesson(x,false,output);}});deep.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runAiLesson(x,true,output);}});ai.addView(teach,height(46,10));ai.addView(deep,height(44,8));ai.addView(output,space(10));root.addView(ai,cardLp());
    }

    private void showVerseWords(final QuranClient.Ayah x){
        enterScreen(new Runnable(){public void run(){showVerseWords(x);}});
        shell("Kelimeye dokun · kökü ve geçtiği yerleri bul","FEHM · "+QuranMeta.label(x.surah,x.ayah)+" Kelimeleri",3);
        ArrayList<QuranLocalStore.MorphHit> hits=QuranLocalStore.get(this).morphForVerse(x.surah,x.ayah,120);
        if(hits.isEmpty()){LinearLayout c=card();c.addView(tv("Bu ayetin tam kök/morfoloji haritası için Hızlı Yerel Kur’an Paketi gerekli.",14,TEXT,Typeface.NORMAL),full());final TextView st=tv(QuranDataManager.status(this),12,MUTED,Typeface.NORMAL);c.addView(st,space(7));Button dl=button("YEREL PAKETİ İNDİR");dl.setOnClickListener(new View.OnClickListener(){public void onClick(View v){startLocalDataDownload(st,(Button)v);}});c.addView(dl,height(44,9));root.addView(c,cardLp());return;}
        LinkedHashMap<Integer,QuranLocalStore.MorphHit> unique=new LinkedHashMap<Integer,QuranLocalStore.MorphHit>();for(QuranLocalStore.MorphHit h:hits)if(!unique.containsKey(h.word))unique.put(h.word,h);
        for(final QuranLocalStore.MorphHit h:unique.values()){LinearLayout c=card();TextView ar=tv(h.formAr,25,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,full());if(h.formLatin!=null&&!h.formLatin.isEmpty())c.addView(tv(h.formLatin,15,GOLD,Typeface.BOLD),space(3));String lemma=h.lemmaAr==null||h.lemmaAr.isEmpty()?"—":h.lemmaAr+(h.lemmaLatin==null||h.lemmaLatin.isEmpty()?"":" · "+h.lemmaLatin);c.addView(tv("Kelime "+h.word+" · "+posTr(h.pos)+"\nKök: "+formatRoot(h.rootAr,h.rootLatin)+"\nLemma: "+lemma,13,TEXT,Typeface.NORMAL),space(5));if(h.rootAr!=null&&!h.rootAr.isEmpty()){Button rb=outlineButton("BU KÖKÜ KUR’AN’DA ARA");rb.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showDictionaryWithQuery(h.rootAr);}});c.addView(rb,height(40,8));}root.addView(c,cardLp());}
    }
    private void showDictionaryWithQuery(final String initial){showDictionary(initial);}

    private int learningStage(){
        FehmStore s=FehmStore.get(this);CourseData d=CourseData.get(this);int letters=(int)(100.0*s.getInt("letterIndex",0)/Math.max(1,d.letters.size()));int words=(int)(100.0*s.learnedCount("word")/Math.max(1,d.words.size()));int grammar=(int)(100.0*s.getInt("grammarIndex",0)/Math.max(1,d.grammar.size()));int avg=(letters+words+grammar)/3;if(avg<20)return 0;if(avg<45)return 1;if(avg<70)return 2;return 3;
    }
    private String stageName(int s){return s==0?"Sıfır / Başlangıç":s==1?"Temel":s==2?"Orta":"İleri";}
    private String trustedFoundation(QuranClient.Ayah x){
        StringBuilder b=new StringBuilder();
        ArrayList<QuranLocalStore.MorphHit> mh=QuranLocalStore.get(this).morphForVerse(x.surah,x.ayah,80);
        if(!mh.isEmpty()){
            b.append("Quranic Arabic Corpus yerel kök/morfoloji verisi:\n");
            for(QuranLocalStore.MorphHit h:mh){
                b.append("- kelime ").append(h.word).append(" | biçim ").append(h.formAr)
                 .append(" | lemma ").append(h.lemmaAr).append(" | kök ").append(h.rootAr)
                 .append(" (").append(h.rootLatin).append(") | POS ").append(h.pos).append("\n");
            }
        }
        String verse=normalizeArabic(x.arabic);int count=0;
        for(CourseData.Word w:CourseData.get(this).words){
            String nw=normalizeArabic(w.arabic);if(nw.length()<1)continue;
            if(verse.contains(nw)){
                if(count++>=12)break;
                b.append("- Türkçe sözlük: ").append(w.arabic).append(" | ").append(w.latin)
                 .append(" | ").append(w.meaning).append(" | Kök/veri: ").append(w.root)
                 .append(" | Aile: ").append(w.family).append('\n');
            }
        }
        if(b.length()==0)b.append("Yerel sözlük ve morfoloji indeksinde bu ayet için doğrulanmış eşleşme bulunamadı. Kök tahmini yapma.\n");
        return b.toString();
    }
    private String normalizeArabic(String s){if(s==null)return "";return s.replace("ـ","").replaceAll("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]","").replace("ٱ","ا").replace("أ","ا").replace("إ","ا").replace("آ","ا");}
    private void runAiLesson(final QuranClient.Ayah x,final boolean deep,final LinearLayout output){
        if(!GeminiClient.configured(this)){Toast.makeText(this,"İlerleme > Ayarlar’dan Gemini anahtarını gir.",Toast.LENGTH_LONG).show();return;}
        output.removeAllViews();output.addView(tv("FEHM öğretmeni hazırlanıyor…",14,MUTED,Typeface.NORMAL),full());final int stage=learningStage();final String foundation=trustedFoundation(x);
        new Thread(new Runnable(){public void run(){try{
            String prompt=deep?deepPrompt(x,stage,foundation):beginnerPrompt(x,stage,foundation);final String ans=GeminiClient.generate(MainActivity.this,prompt,false);
            runOnUiThread(new Runnable(){public void run(){renderAiAnswer(output,ans,deep);FehmStore s=FehmStore.get(MainActivity.this);s.put("analysisScore",""+Math.min(100,s.getInt("analysisScore",0)+2));s.session("analysis",1,1,0);DriveBackup.maybeAutoBackup(MainActivity.this);}});
        }catch(final Exception e){runOnUiThread(new Runnable(){public void run(){output.removeAllViews();output.addView(tv(e.getMessage(),14,BAD,Typeface.NORMAL),full());}});}}}).start();
    }
    private String beginnerPrompt(QuranClient.Ayah x,int stage,String foundation){
        return "Sen FEHM adlı Kur’an Arapçası öğretmenisin. Öğrenci Türkçe konuşuyor ve seviye="+stageName(stage)+". Amaç: ayeti duyduğunda ana parçaları yakalaması. Bu BANA ŞİMDİ ÖĞRET modudur: kısa, sade ve öğretici ol. Sıfır/Başlangıç seviyesinde EN FAZLA 3 kelime/parça öğret; sarf-nahiv terimlerini adlandırma, yalnız günlük Türkçeyle tek küçük örüntüyü göster. Temel seviyede en fazla 4, daha ileri seviyede en fazla 5 parça ver. Meal karşılaştırması ve ayrıntılı yorum bu modda YOK. Kök/morfoloji tahmin etme; yalnız YEREL DOĞRULANMIŞ VERİ içinde açıkça verilen kökü kullan. Kök yoksa kök bölümünü boş bırak. Kullanıcı Arap alfabesini henüz öğreniyor: yazdığın HER Arapça kelime, kök veya lemma yanında mutlaka Latin harfli okunuşunu da ver; Arapçayı tek başına bırakma. Dil analizi ile yorum/tefsiri ayır. Markdown kullanma. SADECE geçerli JSON döndür.\n\nAYET: "+QuranMeta.label(x.surah,x.ayah)+"\nARAPÇA: "+x.arabic+"\nLATİN: "+x.latin+"\nDİYANET: "+x.diyanet+"\nYEREL DOĞRULANMIŞ VERİ:\n"+foundation+"\nJSON ŞEMASI: {\"intro\":\"tek kısa cümle\",\"words\":[{\"arabic\":\"\",\"latin\":\"\",\"meaning\":\"1-4 kelimelik Türkçe anlam\",\"note\":\"gerekirse tek kısa ipucu\"}],\"rootTitle\":\"Bugünün kökü\",\"rootText\":\"yalnız gerçekten yararlı ve doğrulanmışsa tek kök; değilse boş\",\"grammarTitle\":\"Bugünün tek küçük kuralı\",\"grammarText\":\"tek cümle, teknik terimsiz\",\"catchText\":\"Duyunca yakalanacak 1-2 parça + ayetin tek cümlelik ana fikri\",\"question\":\"tek mini hatırlama sorusu\",\"answer\":\"çok kısa cevap\"}.";
    }
    private String deepPrompt(QuranClient.Ayah x,int stage,String foundation){
        return "Sen FEHM adlı Kur’an Arapçası öğretmenisin. Öğrenci Türkçe konuşuyor. Seviye="+stageName(stage)+". Bu istek DERİNLEŞTİR modudur. Kök/morfoloji tahmin etme; yalnız YEREL DOĞRULANMIŞ VERİ içindeki bilgileri kesin dil verisi gibi kullan. Verilmeyen yerde açıkça 'doğrulanmış yerel veri yok' yaz. Etimolojik ihtilaf varsa tek görüşü kesinleştirme. Kullanıcı Arap alfabesini henüz öğreniyor: yazdığın HER Arapça kelime, kök veya lemma yanında Latin harfli okunuşunu da ver; Arapçayı tek başına bırakma. Dil analizi, meal tercihi ve yorum/tefsiri ayrı tut. Markdown kullanma. SADECE geçerli JSON döndür.\nAYET: "+QuranMeta.label(x.surah,x.ayah)+"\nARAPÇA: "+x.arabic+"\nLATİN: "+x.latin+"\nDİYANET: "+x.diyanet+"\nELMALILI: "+x.elmalili+"\nVAKIF: "+x.vakif+"\nYEREL DOĞRULANMIŞ VERİ:\n"+foundation+"\nJSON ŞEMASI: {\"intro\":\"kısa giriş\",\"sections\":[{\"title\":\"Kelime ve ses\",\"body\":\"...\"},{\"title\":\"Kök ve anlam ailesi\",\"body\":\"...\"},{\"title\":\"Gramer örüntüsü\",\"body\":\"...\"},{\"title\":\"Meal farkları ve bağlam\",\"body\":\"...\"},{\"title\":\"Kendi cümlenle anlam\",\"body\":\"...\"}],\"boundary\":\"Kesin dil verisi ile yorumun sınırını bir cümlede belirt\"}.";
    }
    private void renderAiAnswer(LinearLayout output,String ans,boolean deep){
        output.removeAllViews();try{JSONObject o=new JSONObject(GeminiClient.cleanJson(ans));String intro=TextClean.plain(o.optString("intro"));if(!intro.isEmpty())output.addView(tv(intro,14,TEXT,Typeface.NORMAL),full());
            if(!deep){JSONArray words=o.optJSONArray("words");if(words!=null&&words.length()>0){addAiHeading(output,"KELİME KELİME YAKALA");for(int i=0;i<words.length();i++){JSONObject w=words.optJSONObject(i);if(w==null)continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);TextView ar=tv(TextClean.plain(w.optString("arabic")),22,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);row.addView(ar,full());row.addView(tv(TextClean.plain(w.optString("latin"))+" · "+TextClean.plain(w.optString("meaning")),14,GOLD,Typeface.BOLD),space(2));String note=TextClean.plain(w.optString("note"));if(!note.isEmpty())row.addView(tv(note,12,MUTED,Typeface.NORMAL),space(2));output.addView(row,space(8));}}
                addAiSection(output,o.optString("rootTitle","BUGÜNÜN KÖKÜ"),o.optString("rootText"));addAiSection(output,o.optString("grammarTitle","BUGÜNÜN TEK GRAMERİ"),o.optString("grammarText"));addAiSection(output,"ŞİMDİ DUYUNCA YAKALA",o.optString("catchText"));addAiQuiz(output,o.optString("question"),o.optString("answer"));
            }else{JSONArray sec=o.optJSONArray("sections");if(sec!=null)for(int i=0;i<sec.length();i++){JSONObject s=sec.optJSONObject(i);if(s!=null)addAiSection(output,s.optString("title","BÖLÜM"),s.optString("body"));}addAiSection(output,"SINIR",o.optString("boundary"));}
        }catch(Exception e){output.addView(tv(TextClean.plain(ans),14,TEXT,Typeface.NORMAL),full());}
    }
    private void addAiHeading(LinearLayout p,String title){p.addView(tv(title,11,GOLD,Typeface.BOLD),space(12));}
    private void addAiSection(LinearLayout p,String title,String body){body=TextClean.plain(body);if(body.isEmpty())return;p.addView(tv(TextClean.plain(title).toUpperCase(new Locale("tr","TR")),11,GOLD,Typeface.BOLD),space(12));p.addView(tv(body,14,TEXT,Typeface.NORMAL),space(4));}
    private void addAiQuiz(LinearLayout p,String question,String answer){question=TextClean.plain(question);answer=TextClean.plain(answer);if(question.isEmpty())return;p.addView(tv("MİNİ HATIRLAMA",11,GOLD,Typeface.BOLD),space(12));p.addView(tv(question,14,TEXT,Typeface.NORMAL),space(4));if(!answer.isEmpty()){final TextView a=tv("",13,GOLD,Typeface.BOLD);final Button b=outlineButton("CEVABI GÖSTER");final String finalAnswer=answer;b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){a.setText(finalAnswer);v.setVisibility(View.GONE);}});p.addView(b,height(40,7));p.addView(a,space(4));}}

    private void showProgress(){
        enterScreen(new Runnable(){public void run(){showProgress();}});
        shell("Kendi hızında ilerle","FEHM · İlerleme",4);FehmStore s=FehmStore.get(this);CourseData d=CourseData.get(this);LinearLayout c=card();c.addView(tv("BECERİ HARİTASI",11,GOLD,Typeface.BOLD),full());int letters=Math.min(100,(int)(100.0*s.getInt("letterIndex",0)/Math.max(1,d.letters.size())));int words=(int)(100.0*s.learnedCount("word")/Math.max(1,d.words.size()));c.addView(progressLine("Okuma / Elif-Bâ",letters),space(9));c.addView(progressLine("Kelime",words),space(7));c.addView(progressLine("Dinleme",Math.min(100,s.getInt("listenScore",0))),space(7));c.addView(progressLine("Gramer",Math.min(100,(int)(100.0*s.getInt("grammarIndex",0)/Math.max(1,d.grammar.size())))),space(7));c.addView(progressLine("Ayet Çözümleme",Math.min(100,s.getInt("analysisScore",0))),space(7));root.addView(c,cardLp());
        LinearLayout philosophy=card();philosophy.addView(tv("SEVİYE MANTIĞI",11,GOLD,Typeface.BOLD),full());philosophy.addView(tv("0 · İlk kez görüyorum\n1 · Tanıyorum\n2 · Duyunca/seçenek içinde buluyorum\n3 · Anlamını hatırlıyorum\n4 · Ayette tanıyorum\n5 · Başka bağlamda ayırt ediyorum\n6 · Güçlü",13,TEXT,Typeface.NORMAL),space(7));root.addView(philosophy,cardLp());Button settings=button("AYARLAR · AI · DRIVE YEDEĞİ");settings.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSettings();}});root.addView(settings,height(50,12));
    }
    private LinearLayout progressLine(String name,int pct){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.addView(tv(name+" · %"+Math.max(0,Math.min(100,pct)),13,TEXT,Typeface.BOLD),full());ProgressBar b=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);b.setMax(100);b.setProgress(Math.max(0,Math.min(100,pct)));x.addView(b,height(12,5));return x;}
    private void showSettings(){
        enterScreen(new Runnable(){public void run(){showSettings();}});
        shell("Cihazda çalışır · Drive yalnız yedek","FEHM · Ayarlar",4);LinearLayout ai=card();ai.addView(tv("GEMINI ÖĞRETMEN",11,GOLD,Typeface.BOLD),full());final EditText key=input("Gemini API anahtarı",GeminiClient.key(this));key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);final EditText model=input("Model",GeminiClient.model(this));ai.addView(key,height(48,10));ai.addView(model,height(48,8));Button save=button("AI AYARLARINI KAYDET");save.setOnClickListener(new View.OnClickListener(){public void onClick(View v){GeminiClient.save(MainActivity.this,key.getText().toString(),model.getText().toString());Toast.makeText(MainActivity.this,"Kaydedildi",Toast.LENGTH_SHORT).show();}});ai.addView(save,height(46,10));root.addView(ai,cardLp());
        LinearLayout local=card();local.addView(tv("YEREL KUR’AN VERİSİ",11,GOLD,Typeface.BOLD),full());local.addView(tv("Metin, Latin okunuş, mealler ve kök/morfoloji indeksi cihazda tutulur. Sesler ise seçtiğin sure bazında çevrimdışı indirilebilir; böylece telefon depolaması gereksiz yere dolmaz.",13,TEXT,Typeface.NORMAL),space(7));final TextView localStatus=tv(QuranDataManager.status(this),12,MUTED,Typeface.NORMAL);local.addView(localStatus,space(7));if(!QuranDataManager.quranReady(this)||!QuranDataManager.morphReady(this)){Button localDl=outlineButton("YEREL VERİ PAKETİNİ TAMAMLA");localDl.setOnClickListener(new View.OnClickListener(){public void onClick(View v){startLocalDataDownload(localStatus,(Button)v);}});local.addView(localDl,height(44,9));}root.addView(local,cardLp());
        LinearLayout storage=card();storage.addView(tv("DEPOLAMA KULLANIMI",11,GOLD,Typeface.BOLD),full());long qBytes=localQuranBytes(),audioBytes=QuranAudioCache.bytes(this);storage.addView(tv("Kur’an + kök verisi: "+formatBytes(qBytes)+"\nİndirilen sesler: "+formatBytes(audioBytes)+"\nToplam yerel içerik: "+formatBytes(qBytes+audioBytes),13,TEXT,Typeface.NORMAL),space(7));storage.addView(tv("Mahir 64: "+formatBytes(QuranAudioCache.bytes(this,Reciters.MAHER_64))+" · Mahir 128: "+formatBytes(QuranAudioCache.bytes(this,Reciters.MAHER_128))+" · Mişârî: "+formatBytes(QuranAudioCache.bytes(this,Reciters.ALAFASY_64)),12,MUTED,Typeface.NORMAL),space(6));if(audioBytes>0){Button clearAudio=outlineButton("İNDİRİLEN SESLERİ TEMİZLE");clearAudio.setOnClickListener(new View.OnClickListener(){public void onClick(View v){new AlertDialog.Builder(MainActivity.this).setTitle("Çevrimdışı sesleri temizle").setMessage("Yalnız indirilen kıraat sesleri silinecek. Kur’an metni, sözlük ve öğrenme ilerlemesi korunacak.").setNegativeButton("Vazgeç",null).setPositiveButton("Sesleri Sil",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){QuranAudioCache.clearAll(MainActivity.this);Toast.makeText(MainActivity.this,"İndirilen sesler temizlendi.",Toast.LENGTH_LONG).show();showSettings();}}).show();}});storage.addView(clearAudio,height(42,9));}root.addView(storage,cardLp());

        LinearLayout backup=card();backup.addView(tv("DRIVE YEDEĞİ / GERİ YÜKLEME",11,GOLD,Typeface.BOLD),full());backup.addView(tv("FEHM günlük kullanımda Drive’a bağımlı değildir. Öğrenme verisi cihazdadır. Drive yalnız yedek ve geri yükleme için kullanılır. API anahtarı yedeğe yazılmaz.",13,TEXT,Typeface.NORMAL),space(7));final TextView status=tv(DriveBackup.autoStatus(this),12,MUTED,Typeface.NORMAL);backup.addView(status,space(7));Button auto=outlineButton(DriveBackup.autoConfigured(this)?"OTOMATİK YEDEK DOSYASINI DEĞİŞTİR":"OTOMATİK YEDEĞİ KUR");auto.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseAuto(MainActivity.this);}});backup.addView(auto,height(44,10));if(DriveBackup.autoConfigured(this)){Button now=outlineButton("OTOMATİK YEDEĞİ ŞİMDİ GÜNCELLE");now.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{DriveBackup.backupNowAuto(MainActivity.this);Toast.makeText(MainActivity.this,"Otomatik Drive yedeği güncellendi.",Toast.LENGTH_LONG).show();showSettings();}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}}});backup.addView(now,height(44,8));}
        Button ex=button("TARİHLİ YEDEK OLUŞTUR");ex.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseExport(MainActivity.this);}});backup.addView(ex,height(46,10));Button im=outlineButton("YEDEKTEN GERİ YÜKLE");im.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseImport(MainActivity.this);}});backup.addView(im,height(46,8));root.addView(backup,cardLp());
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;final Uri u=data.getData();
        if(request==DriveBackup.EXPORT){try{DriveBackup.exportTo(this,u);Toast.makeText(this,"FEHM yedeği kaydedildi.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
        else if(request==DriveBackup.AUTO_SETUP){try{DriveBackup.rememberAuto(this,u);DriveBackup.backupNowAuto(this);Toast.makeText(this,"Otomatik Drive yedeği kuruldu.",Toast.LENGTH_LONG).show();showSettings();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
        else if(request==DriveBackup.IMPORT){new AlertDialog.Builder(this).setTitle("Yedeği geri yükle").setMessage("Seçilen FEHM yedeği mevcut öğrenme ilerlemesiyle birleştirilecek; mevcut kayıtlar topluca silinmeyecek. Devam edilsin mi?").setNegativeButton("Vazgeç",null).setPositiveButton("Geri Yükle",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){try{DriveBackup.importFrom(MainActivity.this,u);Toast.makeText(MainActivity.this,"Yedek geri yüklendi.",Toast.LENGTH_LONG).show();showProgress();}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}}}).show();}
    }

    private TextView tv(String s,float size,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,style);t.setLineSpacing(dp(2),1.08f);return t;}
    private TextView center(TextView t){t.setGravity(Gravity.CENTER);return t;}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(17),dp(16),dp(17),dp(16));c.setBackground(round(PANEL,Color.argb(80,220,184,91),1,18));return c;}
    private LinearLayout.LayoutParams full(){return new LinearLayout.LayoutParams(-1,-2);}private LinearLayout.LayoutParams cardLp(){LinearLayout.LayoutParams p=full();p.topMargin=dp(10);return p;}private LinearLayout.LayoutParams space(int top){LinearLayout.LayoutParams p=full();p.topMargin=dp(top);return p;}private LinearLayout.LayoutParams height(int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(h));p.topMargin=dp(top);return p;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setTextColor(BG);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(GOLD,GOLD,1,12));return b;}
    private Button outlineButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(GOLD);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(PANEL2,GOLD,1,11));return b;}
    private Button smallButton(String s,int fill){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(TEXT);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(fill,fill,1,11));return b;}
    private EditText input(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setSingleLine(true);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(16);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(PANEL2,Color.argb(80,220,184,91),1,12));return e;}
    private GradientDrawable round(int fill,int stroke,int sw,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(sw>0)g.setStroke(dp(sw),stroke);return g;}
    private int parse(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
}
