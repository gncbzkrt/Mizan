package com.mizan.kisisel.widget;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Kaynak Ara icin Google Search grounding kullanmadan calisan dogrulamali tarayici.
 * Gemini yalniz olasi kurumsal URL adaylarini onerir. Bir URL, cihaz tarafinda
 * gercekten HTTP 200 ile acilip icerigi okunmadan aday kaynaga donusemez.
 */
final class VerifiedWebResearch {
    static final class Page {
        final String title,url,text;
        Page(String title,String url,String text){this.title=title;this.url=url;this.text=text;}
    }

    static int research(Context c, LocalStore db, String question) throws Exception {
        LinkedHashSet<String> urls=new LinkedHashSet<String>();
        addDeterministicUrls(urls,question);
        addGeminiProposals(c,urls,question);

        List<Page> pages=new ArrayList<Page>();
        for(String u:urls){
            if(pages.size()>=12)break;
            try{
                Page p=fetch(u,question);
                if(p!=null)pages.add(p);
            }catch(Exception ignored){}
        }
        if(pages.isEmpty())return 0;

        StringBuilder verified=new StringBuilder();
        for(int i=0;i<pages.size();i++){
            Page p=pages.get(i);
            verified.append("SOURCE_").append(i+1).append("\nTITLE: ").append(p.title)
                    .append("\nURL: ").append(p.url).append("\nCONTENT:\n")
                    .append(shorten(p.text,6000)).append("\n---\n");
        }
        String prompt="Mizan icin kullanici tarafindan onaylanmadan kalici olmayacak yeni kaynak adaylarini siniflandiriyorsun. " +
                "Asagidaki sayfalar cihaz tarafinda gercekten acilmis ve icerigi okunmus kurumsal sayfalardir. " +
                "YALNIZ verilen SOURCE numaralarindaki icerige dayan. Ayet/hadis numarasi, ravi, eser veya hukum uydurma. " +
                "Konu ile gercekten ilgili en fazla 7 kaynagi sec. Kaynagin kurumsal sinifini ve guven seviyesini dikkate al. Her ozet 3-6 cumle olsun ve sayfanin konuya ne kattigini anlatsin. " +
                "YALNIZ JSON dondur: {\"candidates\":[{\"sourceIndex\":1,\"type\":\"AYET|HADIS|KISSA|ZIKIR|TEFSIR|ARASTIRMA\",\"summary\":\"\",\"reference\":\"\",\"reason\":\"\",\"confidence\":\"YUKSEK|ORTA|DUSUK\"}]}\n\nKONU: "+question+"\n\nDOGRULANMIS SAYFALAR:\n"+verified;
        String raw=GeminiClient.generate(c,prompt,false);
        int added=parseClassified(db,pages,raw);
        if(added==0){
            // AI JSON'u bozuk gelse bile gercekten dogrulanmis sayfayi kaybetme.
            Page p=pages.get(0);
            String summary=shorten(cleanForSummary(p.text),1200);
            if(!summary.isEmpty()){
                String domain=hostOf(p.url);
                long id=db.addCandidateIfNew(p.title,"ARASTIRMA",summary,p.title,p.url,
                        "Konu ile ilgili kurumsal web sayfasi cihaz tarafinda dogrulandi: "+domain+" · "+trustLabel(p.url),
                        trustConfidence(p.url));
                if(id>0)added=1;
            }
        }
        return added;
    }

    private static void addGeminiProposals(Context c, Set<String> out, String question){
        try{
            String prompt="Web aramasi yapma. Mizan uygulamasinin daha sonra GERCEKTEN HTTP ile acip dogrulayacagi olasi kurumsal kaynak URL'lerini oner. " +
                    "Konu: "+question+". Kaynak havuzu oncelik sirasiyla: " +
                    "1) islamansiklopedisi.org.tr (TDV Islam Ansiklopedisi), diyanet.gov.tr ve alt alanlari, isam.org.tr; " +
                    "2) dergipark.org.tr akademik makaleleri, tez.yok.gov.tr lisansustu tezleri; " +
                    "3) universite ilahiyat/islami ilimler sayfalari (*.edu.tr, yalniz ilahiyat veya islami ilimler baglaminda); " +
                    "4) kuramer.org (Kur'an Arastirmalari Merkezi), yazmalar.gov.tr, kulturportali.gov.tr, vakiflar.gov.tr ve ktb.gov.tr gibi kurumsal kultur/arsiv kaynaklari. " +
                    "Blog, forum, sosyal medya, haber, video, ticari icerik ve kisisel siteleri verme. URL'den emin degilsen verme. " +
                    "En fazla 14 sonuc. YALNIZ JSON: {\"urls\":[\"https://...\"]}";
            String raw=GeminiClient.generate(c,prompt,false);
            JSONObject root=new JSONObject(GeminiClient.cleanJson(raw));
            JSONArray a=root.optJSONArray("urls");
            if(a!=null)for(int i=0;i<a.length();i++){String u=a.optString(i,"").trim();if(isTrusted(u))out.add(u);}
        }catch(Exception ignored){}
    }

    private static void addDeterministicUrls(Set<String> out,String q){
        String slug=slug(q);
        if(!slug.isEmpty())out.add("https://islamansiklopedisi.org.tr/"+slug);
        String[] toks=norm(q).split("\\s+");
        for(String t:toks){if(t.length()>=4)out.add("https://islamansiklopedisi.org.tr/"+t);}
    }

    private static Page fetch(String input,String question) throws Exception {
        if(!isTrusted(input))return null;
        HttpURLConnection h=(HttpURLConnection)new URL(input).openConnection();
        h.setInstanceFollowRedirects(true);h.setConnectTimeout(12000);h.setReadTimeout(20000);
        h.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) Mizan/3.3.0");
        h.setRequestProperty("Accept","text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.2");
        h.setRequestProperty("Accept-Language","tr-TR,tr;q=0.9,en;q=0.5");
        h.setRequestProperty("Accept-Encoding","identity");
        int code=h.getResponseCode();
        if(code<200||code>=300){h.disconnect();return null;}
        String finalUrl=h.getURL().toString();if(!isTrusted(finalUrl)){h.disconnect();return null;}
        String ct=h.getContentType();if(ct!=null&&!(ct.contains("text")||ct.contains("html")||ct.contains("xml"))){h.disconnect();return null;}
        InputStream in=h.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));
        StringBuilder raw=new StringBuilder();String line;int n=0;while((line=r.readLine())!=null&&n<900000){raw.append(line).append('\n');n+=line.length();}r.close();h.disconnect();
        if(raw.length()<80)return null;
        String html=raw.toString();String title=extractTitle(html);String text=htmlToText(html);
        if(text.length()<120||!relevant(text+" "+title,question))return null;
        return new Page(title.isEmpty()?hostOf(finalUrl):title,finalUrl,text);
    }

    private static int parseClassified(LocalStore db,List<Page> pages,String raw){
        int added=0;
        try{
            JSONObject root=new JSONObject(GeminiClient.cleanJson(raw));JSONArray a=root.optJSONArray("candidates");if(a==null)return 0;
            for(int i=0;i<a.length()&&added<7;i++){
                JSONObject o=a.optJSONObject(i);if(o==null)continue;int idx=o.optInt("sourceIndex",0)-1;if(idx<0||idx>=pages.size())continue;
                Page p=pages.get(idx);String summary=o.optString("summary","").trim();if(summary.isEmpty())continue;
                String conf=o.optString("confidence",trustConfidence(p.url));
                long id=db.addCandidateIfNew(p.title,o.optString("type","ARASTIRMA"),summary,o.optString("reference",p.title),p.url,o.optString("reason","Dogrulanmis kurumsal web kaynagi")+" · "+trustLabel(p.url),conf);
                if(id>0)added++;
            }
        }catch(Exception ignored){}
        return added;
    }

    private static boolean relevant(String text,String q){
        String hay=norm(text),nq=norm(q);if(nq.length()>=3&&hay.contains(nq))return true;
        int hits=0,total=0;for(String t:nq.split("\\s+")){if(t.length()<3)continue;total++;if(hay.contains(t))hits++;}
        return hits>0&&(total<=2||hits>=2);
    }
    private static boolean isTrusted(String u){
        try{
            URL x=new URL(u);String h=x.getHost().toLowerCase(Locale.US);String path=(x.getPath()==null?"":x.getPath()).toLowerCase(Locale.US);
            if(host(h,"islamansiklopedisi.org.tr")||host(h,"diyanet.gov.tr")||host(h,"isam.org.tr"))return true;
            if(host(h,"dergipark.org.tr")||h.equals("tez.yok.gov.tr"))return true;
            if(host(h,"kuramer.org")||host(h,"yazmalar.gov.tr")||host(h,"kulturportali.gov.tr")||host(h,"vakiflar.gov.tr")||host(h,"ktb.gov.tr"))return true;
            if(h.endsWith(".edu.tr")&&(h.contains("ilahiyat")||h.contains("islami")||path.contains("ilahiyat")||path.contains("islami-ilimler")||path.contains("islamibilimler")||path.contains("islam-bilim")))return true;
            return false;
        }catch(Exception e){return false;}
    }
    private static boolean host(String h,String root){return h.equals(root)||h.endsWith("."+root);}
    private static boolean isPrimaryTrusted(String u){
        try{String h=new URL(u).getHost().toLowerCase(Locale.US);return host(h,"islamansiklopedisi.org.tr")||host(h,"diyanet.gov.tr")||host(h,"isam.org.tr");}catch(Exception e){return false;}
    }
    private static String trustConfidence(String u){
        if(isPrimaryTrusted(u))return "YUKSEK";
        try{String h=new URL(u).getHost().toLowerCase(Locale.US);if(host(h,"dergipark.org.tr")||h.equals("tez.yok.gov.tr")||h.endsWith(".edu.tr")||host(h,"kuramer.org"))return "ORTA";}catch(Exception ignored){}
        return "ORTA";
    }
    private static String trustLabel(String u){
        try{String h=new URL(u).getHost().toLowerCase(Locale.US);
            if(host(h,"islamansiklopedisi.org.tr"))return "TDV Islam Ansiklopedisi";
            if(host(h,"diyanet.gov.tr"))return "Diyanet kurumsal kaynagi";
            if(host(h,"isam.org.tr"))return "ISAM akademik kaynagi";
            if(host(h,"dergipark.org.tr"))return "DergiPark akademik makalesi";
            if(h.equals("tez.yok.gov.tr"))return "YOK Tez akademik kaynagi";
            if(h.endsWith(".edu.tr"))return "Universite ilahiyat/islami ilimler kaynagi";
            if(host(h,"kuramer.org"))return "KURAMER arastirma kaynagi";
            if(host(h,"yazmalar.gov.tr"))return "Yazma eser/arsiv kaynagi";
            if(host(h,"kulturportali.gov.tr")||host(h,"vakiflar.gov.tr")||host(h,"ktb.gov.tr"))return "Resmi kultur/arsiv kaynagi";
        }catch(Exception ignored){}return "Dogrulanmis kurumsal kaynak";
    }
    private static String hostOf(String u){try{return new URL(u).getHost();}catch(Exception e){return "web";}}
    private static String extractTitle(String html){
        Matcher m=Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);if(m.find())return decode(stripTags(m.group(1))).trim();
        m=Pattern.compile("(?is)<meta[^>]+(?:property|name)=[\\\"'](?:og:title|twitter:title)[\\\"'][^>]+content=[\\\"'](.*?)[\\\"']").matcher(html);if(m.find())return decode(stripTags(m.group(1))).trim();return "";
    }
    private static String htmlToText(String html){
        String s=html.replaceAll("(?is)<script[^>]*>.*?</script>"," ").replaceAll("(?is)<style[^>]*>.*?</style>"," ").replaceAll("(?is)<!--.*?-->"," ");
        s=s.replaceAll("(?is)<(br|p|div|li|h1|h2|h3|h4|tr)[^>]*>","\n");s=stripTags(s);s=decode(s);s=s.replace('\u00A0',' ');s=s.replaceAll("[ \\t\\x0B\\f\\r]+"," ").replaceAll("\\n\\s*\\n+","\n");return s.trim();
    }
    private static String stripTags(String s){return s==null?"":s.replaceAll("(?is)<[^>]+>"," ");}
    private static String decode(String s){if(s==null)return "";return s.replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">");}
    private static String cleanForSummary(String s){String x=s==null?"":s.trim();return x.replaceAll("\\s+"," ");}
    private static String shorten(String s,int n){return s==null?"":(s.length()<=n?s:s.substring(0,n));}
    private static String slug(String q){String n=norm(q).trim().replaceAll("[^a-z0-9 ]+"," ").replaceAll("\\s+","-");return n.replaceAll("^-|-$","");}
    private static String norm(String x){return (x==null?"":x).toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');}
    private VerifiedWebResearch(){}
}
