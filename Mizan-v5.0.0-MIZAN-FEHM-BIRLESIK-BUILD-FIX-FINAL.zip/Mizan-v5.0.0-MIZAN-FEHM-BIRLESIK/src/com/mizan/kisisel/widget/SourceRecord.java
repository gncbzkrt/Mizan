package com.mizan.kisisel.widget;

final class SourceRecord {
    long rowId;
    String id, type, title, body, reference, grade, keywords, url, note, status, origin, arabic, reading;
    SourceRecord() { }
    SourceRecord(String id,String type,String title,String body,String reference,String grade,String keywords,String url,String note,String status,String origin){
        this.id=id;this.type=type;this.title=title;this.body=body;this.reference=reference;this.grade=grade;this.keywords=keywords;this.url=url;this.note=note;this.status=status;this.origin=origin;this.arabic="";this.reading="";
    }
    String compact(){
        StringBuilder s=new StringBuilder();
        s.append('[').append(id).append("] ").append(type).append(" · ").append(title);
        if(reference!=null&&!reference.isEmpty()) s.append(" · ").append(reference);
        s.append("\n").append(body==null?"":body);
        if(arabic!=null&&!arabic.isEmpty()) s.append("\nArapça: ").append(arabic);
        if(reading!=null&&!reading.isEmpty()) s.append("\nLatin okunuş: ").append(reading);
        if(note!=null&&!note.isEmpty()) s.append("\nNot: ").append(note);
        return s.toString();
    }
}
