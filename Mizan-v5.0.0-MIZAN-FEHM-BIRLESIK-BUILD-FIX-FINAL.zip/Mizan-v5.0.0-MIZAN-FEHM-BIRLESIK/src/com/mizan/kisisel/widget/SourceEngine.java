package com.mizan.kisisel.widget;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class SourceEngine {
    static final class ResearchResult {final int added;final String error;ResearchResult(int added,String error){this.added=added;this.error=error;}}
    static String contextFor(Context c,String question,int limit){LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);List<SourceRecord> rows=db.search(question,limit);StringBuilder s=new StringBuilder();for(SourceRecord r:rows)s.append(r.compact()).append("\n---\n");return s.toString();}
    static MizanApi.ChatResult chat(Context c,String q){
        try{LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);List<SourceRecord> local=db.search(q,14);StringBuilder ctx=new StringBuilder();for(SourceRecord r:local)ctx.append(r.compact()).append("\n---\n");String prompt="Sen Mîzan kişisel ilim rehberisin. Kullanıcının sorusunu ÖNCE ve ESASEN aşağıdaki yerel kaynaklara dayanarak Türkçe cevapla. Kaynakta olmayan kesin dinî hüküm, ayet, hadis, ravi, numara veya olay uydurma. Kullanılan her yerel kaynağı [A001] gibi kimliğiyle ilgili cümlenin sonunda göster. Fetva verme; gerektiğinde Diyanet/alan uzmanına yönlendir. Cevabı iki-üç cümlelik özetle bitirme: soru uygunsa 6-10 kısa paragrafla önce doğrudan cevap ver, sonra kaynakların çizdiği çerçeveyi açıkla, önemli nüansı/yanlış anlaşılma sınırını belirt, gündelik hayattan somut örnekler ver ve sonunda kısa bir sonuç/muhasebe önerisi ekle. Kullanıcının dili doğal olsun; gereksiz akademik üslup kullanma. Yerel kaynak gerçekten yetersizse bunu açıkça söyle ve Kaynak Ara seçeneğini öner.\n\nSORU:\n"+q+"\n\nYEREL KAYNAKLAR:\n"+ctx;String answer=GeminiClient.generate(c,prompt,false);boolean weak=local.size()<4||bestRelevance(local,q)<2;if(weak) answer += "\n\n🔎 Yerel kütüphane bu konu için sınırlı görünüyor. İstersen ‘Kaynak Ara’ ile webde yeni kaynak adayları tarayabilirsin; hiçbir kaynak onayın olmadan kütüphaneye eklenmez.";answer=CitationFormatter.humanize(c,answer);return new MizanApi.ChatResult(true,answer,"");}catch(Exception e){return new MizanApi.ChatResult(false,"",e.getMessage()==null?"Sohbet üretilemedi.":e.getMessage());}}
    private static int bestRelevance(List<SourceRecord> rows,String q){if(rows.isEmpty())return 0;String l=(rows.get(0).title+" "+rows.get(0).keywords+" "+rows.get(0).body).toLowerCase();int n=0;for(String t:q.toLowerCase().split("\\s+"))if(t.length()>2&&l.contains(t))n++;return n;}

    static ResearchResult research(Context c,String question){
        LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);
        try{
            int added=VerifiedWebResearch.research(c,db,question);
            if(added==0)return new ResearchResult(0,"Güvenilir kurumsal sayfalarda doğrulanabilir yeni bir kaynak bulunamadı. Daha açık bir konu adıyla tekrar deneyebilirsin.");
            return new ResearchResult(added,"");
        }catch(Exception e){return new ResearchResult(0,e.getMessage()==null?"Kaynak araştırması tamamlanamadı.":e.getMessage());}
    }
    private static int parseDirectCandidates(LocalStore db,String raw){int added=0;try{JSONObject root=new JSONObject(GeminiClient.cleanJson(raw));JSONArray a=root.optJSONArray("candidates");if(a==null)return 0;for(int i=0;i<a.length()&&added<5;i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String url=o.optString("url","").trim();if(!url.startsWith("https://")&&!url.startsWith("http://"))continue;String title=o.optString("title","").trim();String summary=o.optString("summary","").trim();if(title.isEmpty()||summary.isEmpty())continue;if(db.addCandidateIfNew(title,o.optString("type","ARASTIRMA"),summary,o.optString("reference"),url,o.optString("reason"),o.optString("confidence","ORTA"))>0)added++;}}catch(Exception ignored){}return added;}
    private static int parseGroundedCandidates(Context c,LocalStore db,String question,GeminiClient.GenerationResult g){
        try{StringBuilder refs=new StringBuilder();for(int i=0;i<g.webRefs.size()&&i<8;i++){GeminiClient.WebRef r=g.webRefs.get(i);refs.append("REF_").append(i+1).append(" | ").append(r.title).append(" | ").append(r.uri).append("\n");}
            String prompt="Aşağıda Google Search ile elde edilmiş araştırma metni ve gerçek grounding kaynakları var. Sadece bu REF listesindeki kaynakları kullanarak en fazla 5 aday sınıflandır. URL üretme; her aday için yalnız refIndex ver. Kaynak içeriği araştırma metninde desteklenmiyorsa kesin dini iddia kurma. YALNIZ JSON: {\"candidates\":[{\"refIndex\":1,\"type\":\"AYET|HADIS|KISSA|ZIKIR|TEFSIR|ARASTIRMA\",\"summary\":\"\",\"reference\":\"\",\"reason\":\"\",\"confidence\":\"YUKSEK|ORTA|DUSUK\"}]}\n\nKONU: "+question+"\n\nARAŞTIRMA METNİ:\n"+g.text+"\n\nKAYNAKLAR:\n"+refs;
            String raw=GeminiClient.generate(c,prompt,false);JSONObject root=new JSONObject(GeminiClient.cleanJson(raw));JSONArray a=root.optJSONArray("candidates");if(a==null)return 0;int added=0;for(int i=0;i<a.length()&&added<5;i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;int idx=o.optInt("refIndex",0)-1;if(idx<0||idx>=g.webRefs.size())continue;GeminiClient.WebRef r=g.webRefs.get(idx);String summary=o.optString("summary","").trim();if(summary.isEmpty())continue;String title=r.title==null||r.title.trim().isEmpty()?"Web kaynağı":r.title.trim();if(db.addCandidateIfNew(title,o.optString("type","ARASTIRMA"),summary,o.optString("reference"),r.uri,o.optString("reason"),o.optString("confidence","ORTA"))>0)added++;}return added;
        }catch(Exception ignored){return 0;}
    }
    private SourceEngine(){}
}
