package com.mizan.kisisel.widget;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

final class TodaySync {
    static final TimeZone ISTANBUL=TimeZone.getTimeZone("Europe/Istanbul");
    static final class Item {final String type,title,body,source,arabic,reading;Item(String type,String title,String body,String source,String arabic,String reading){this.type=type;this.title=title;this.body=body;this.source=source;this.arabic=arabic;this.reading=reading;}String scrollText(){StringBuilder t=new StringBuilder();if(arabic!=null&&!arabic.isEmpty())t.append("Arapça\n").append(arabic).append("\n\n");if(reading!=null&&!reading.isEmpty())t.append("Latin harfli okunuş\n").append(reading).append("\n\n");if(body!=null&&!body.isEmpty())t.append(body.trim());if(source!=null&&!source.isEmpty())t.append("\n\n📚 ").append(source);return t.toString().trim();}String scrollText(Context c){StringBuilder t=new StringBuilder();if(arabic!=null&&!arabic.isEmpty())t.append("Arapça\n").append(arabic).append("\n\n");if(reading!=null&&!reading.isEmpty())t.append("Latin harfli okunuş\n").append(reading).append("\n\n");if(body!=null&&!body.isEmpty()){String shown=CitationFormatter.humanize(c,body.trim());if("ZİKİR".equalsIgnoreCase(type)&&!shown.toLowerCase(new java.util.Locale("tr","TR")).contains("türkçe anlam")){shown=shown.replaceFirst("(?i)^Anlam\\s*:\\s*","");shown="Türkçe anlam\n"+shown;}t.append(shown);}String hs=CitationFormatter.humanSource(c,source);if(!hs.isEmpty())t.append("\n\n📚 ").append(hs);return t.toString().trim();}}
    static final class PackageData {final boolean ok;final String dateKey,dateLabel,error;final List<Item> items;PackageData(boolean ok,String dateKey,String dateLabel,String error,List<Item> items){this.ok=ok;this.dateKey=dateKey;this.dateLabel=dateLabel;this.error=error;this.items=items;}}
    static boolean configured(Context c){return true;}
    static PackageData cached(Context c){LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);String json=db.dailyJson(todayKey());if(json.isEmpty())return DailyEngine.localPreview(c);try{JSONObject root=new JSONObject(json);if(root.optInt("formatVersion",0)<9)return DailyEngine.localPreview(c);return parse(json);}catch(Exception e){return empty("Bugünün yerel paketi okunamadı.");}}
    static PackageData refresh(Context c){return DailyEngine.ensureToday(c,false);}
    static PackageData parse(String json)throws Exception{JSONObject root=new JSONObject(json);return new PackageData(root.optBoolean("ok",false),root.optString("dateKey",""),root.optString("dateLabel",""),root.optString("error",""),parseItems(root.optJSONArray("items")));}
    static List<Item> parseItems(JSONArray a){List<Item> out=new ArrayList<Item>();if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(new Item(o.optString("type"),o.optString("title"),o.optString("body"),o.optString("source"),o.optString("arabic"),o.optString("reading")));}return out;}
    static PackageData empty(String e){return new PackageData(false,todayKey(),todayLabel(),e,new ArrayList<Item>());}
    static String todayKey(){return date("yyyyMMdd");}static String todayLabel(){return date("dd.MM.yyyy");}private static String date(String p){SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(ISTANBUL);return f.format(new Date());}
    private TodaySync(){}
}
