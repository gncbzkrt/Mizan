package com.mizan.kisisel.widget;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Locale;

final class HadithCorpus {
    static final String ALL="all";
    static final int EXPECTED_SIX=29660, EXPECTED_DUAS=268;
    static final class Hadith {
        String collectionId="",number="",bookId="",chapterNumber="",reference="",arabic="",matn="",narrator="",grade="",url="";
        String book(){return bookName(collectionId);}
        String title(){String n=number==null||number.isEmpty()?"":(" "+number);return book()+n;}
    }
    static final class Dua {
        String number="",chapterNumber="",reference="",arabic="",reading="",hisnReference="",url="";
        String title(){return "Hisnü’l-Müslim"+(number==null||number.isEmpty()?"":(" · "+number));}
    }
    private static File file(Context c){return new File(c.getFilesDir(),"mizan_kutub_sitte_v2.db");}
    private static synchronized File ensure(Context c)throws Exception{
        File f=file(c);if(f.exists()&&f.length()>1024*1024)return f;
        InputStream in=c.getAssets().open("kutub_sitte.db");File tmp=new File(c.getFilesDir(),"mizan_kutub_sitte_v2.tmp");FileOutputStream out=new FileOutputStream(tmp);byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();out.close();in.close();if(f.exists())f.delete();if(!tmp.renameTo(f))throw new Exception("Kütüb-i Sitte verisi cihaza hazırlanamadı.");return f;
    }
    static boolean ready(Context c){try{SQLiteDatabase db=open(c);Cursor x=db.rawQuery("SELECT COUNT(*) FROM hadiths",null);boolean ok=x.moveToFirst()&&x.getInt(0)>29000;x.close();db.close();return ok;}catch(Exception e){return false;}}
    static int hadithCount(Context c){return count(c,"hadiths");}
    static int duaCount(Context c){return count(c,"duas");}
    private static int count(Context c,String table){try{SQLiteDatabase db=open(c);Cursor x=db.rawQuery("SELECT COUNT(*) FROM "+table,null);int n=x.moveToFirst()?x.getInt(0):0;x.close();db.close();return n;}catch(Exception e){return 0;}}
    private static SQLiteDatabase open(Context c)throws Exception{return SQLiteDatabase.openDatabase(ensure(c).getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);}

    static List<Hadith> search(Context c,String collection,String q,int limit){List<Hadith> out=new ArrayList<Hadith>();SQLiteDatabase db=null;try{
        db=open(c);String s=q==null?"":q.trim();String inferred=inferCollection(s);if((collection==null||ALL.equals(collection))&&!inferred.isEmpty())collection=inferred;String where="";List<String> args=new ArrayList<String>();
        if(collection!=null&&!ALL.equals(collection)){where="collection_id=?";args.add(collection);}
        String number=extractNumber(s);
        if(!s.isEmpty()){
            String cond;if(!number.isEmpty()){cond="(hadith_number=? OR reference LIKE ?)";args.add(number);args.add("%"+number+"%");}
            else{cond="(text_ar LIKE ? OR matn_ar LIKE ? OR reference LIKE ?)";args.add("%"+s+"%");args.add("%"+s+"%");args.add("%"+s+"%");}
            where=where.isEmpty()?cond:(where+" AND "+cond);
        }
        String sql="SELECT collection_id,hadith_number,book_id,chapter_number,reference,text_ar,matn_ar,narrator,COALESCE(NULLIF(grade_ar,''),source_grade),url_source FROM hadiths"+(where.isEmpty()?"":" WHERE "+where)+" ORDER BY _id LIMIT "+Math.max(1,Math.min(50,limit));
        Cursor x=db.rawQuery(sql,args.toArray(new String[args.size()]));while(x.moveToNext()){Hadith h=new Hadith();h.collectionId=x.getString(0);h.number=nz(x.getString(1));h.bookId=nz(x.getString(2));h.chapterNumber=nz(x.getString(3));h.reference=nz(x.getString(4));h.arabic=nz(x.getString(5));h.matn=nz(x.getString(6));h.narrator=nz(x.getString(7));h.grade=nz(x.getString(8));h.url=nz(x.getString(9));out.add(h);}x.close();
    }catch(Exception ignored){}finally{if(db!=null)db.close();}return out;}

    static List<Dua> searchDuas(Context c,String q,int limit){List<Dua> out=new ArrayList<Dua>();SQLiteDatabase db=null;try{
        db=open(c);String s=q==null?"":q.trim();String sql="SELECT dua_number,chapter_number,reference,text_ar,transliteration,hisn_reference,url_source FROM duas";String[] args=null;if(!s.isEmpty()){if(s.matches("[0-9]+")){sql+=" WHERE dua_number=? OR reference LIKE ? OR hisn_reference LIKE ?";args=new String[]{s,"%"+s+"%","%"+s+"%"};}else{sql+=" WHERE text_ar LIKE ? OR transliteration LIKE ? OR reference LIKE ?";args=new String[]{"%"+s+"%","%"+s+"%","%"+s+"%"};}}sql+=" ORDER BY _id LIMIT "+Math.max(1,Math.min(50,limit));Cursor x=db.rawQuery(sql,args);while(x.moveToNext()){Dua d=new Dua();d.number=nz(x.getString(0));d.chapterNumber=nz(x.getString(1));d.reference=nz(x.getString(2));d.arabic=nz(x.getString(3));d.reading=nz(x.getString(4));d.hisnReference=nz(x.getString(5));d.url=nz(x.getString(6));out.add(d);}x.close();
    }catch(Exception ignored){}finally{if(db!=null)db.close();}return out;}

    static SourceRecord dailySource(Context c,String dayKey,Set<String> recent){
        SQLiteDatabase db=null;try{
            db=open(c);
            Cursor count=db.rawQuery("SELECT COUNT(*) FROM hadiths WHERE collection_id IN ('bukhari','muslim') OR source_grade IN ('sahih','hasan') OR grade_ar LIKE '%صحيح%' OR grade_ar LIKE '%حسن%'",null);
            int total=count.moveToFirst()?count.getInt(0):0;count.close();if(total<=0)return null;
            int seed=(dayKey+"|KUTUBISITTE").hashCode();if(seed==Integer.MIN_VALUE)seed=0;int start=Math.abs(seed)%total;
            for(int attempt=0;attempt<40;attempt++){
                int off=(start+attempt*131)%total;
                Cursor x=db.rawQuery("SELECT collection_id,hadith_number,book_id,chapter_number,reference,text_ar,matn_ar,narrator,COALESCE(NULLIF(grade_ar,''),source_grade),url_source FROM hadiths WHERE collection_id IN ('bukhari','muslim') OR source_grade IN ('sahih','hasan') OR grade_ar LIKE '%صحيح%' OR grade_ar LIKE '%حسن%' ORDER BY _id LIMIT 1 OFFSET "+off,null);
                if(!x.moveToFirst()){x.close();continue;}
                Hadith h=new Hadith();h.collectionId=nz(x.getString(0));h.number=nz(x.getString(1));h.bookId=nz(x.getString(2));h.chapterNumber=nz(x.getString(3));h.reference=nz(x.getString(4));h.arabic=nz(x.getString(5));h.matn=nz(x.getString(6));h.narrator=nz(x.getString(7));h.grade=nz(x.getString(8));h.url=nz(x.getString(9));x.close();
                int hh=(h.collectionId+"|"+h.number).hashCode();if(hh==Integer.MIN_VALUE)hh=0;String hid="KS"+Math.abs(hh);if(recent!=null&&recent.contains(hid))continue;
                String ar=h.matn.trim().isEmpty()?h.arabic:h.matn; if(ar.trim().isEmpty())continue;
                String ref=h.title()+(h.reference.trim().isEmpty()?"":" · "+h.reference.trim());
                SourceRecord r=new SourceRecord(hid,"HADIS",h.title(),"",ref,h.grade,"Kütüb-i Sitte sahih hasan",h.url,"Arapça asıl yerel Kütüb-i Sitte arşivinden gelir. Türkçe anlam gösterilirse bu, Arapça asıldan AI destekli erişim anlamıdır; modern bir kaynak tercümesi değildir.","ACTIVE","KUTUB_SITTE");
                r.arabic=ar;return r;
            }
        }catch(Exception ignored){}finally{if(db!=null)db.close();}
        return null;
    }

    static String cachedTurkishMeaning(Context c,Hadith h){return LocalStore.get(c).cacheGet("hadith_tr:"+h.collectionId+":"+h.number);}
    static String cachedInsight(Context c,Hadith h){return LocalStore.get(c).cacheGet("hadith_insight:"+h.collectionId+":"+h.number);}
    static String insight(Context c,Hadith h)throws Exception{
        String key="hadith_insight:"+h.collectionId+":"+h.number;LocalStore ls=LocalStore.get(c);String cached=ls.cacheGet(key);if(!cached.isEmpty())return cached;if(!GeminiClient.configured(c))throw new Exception("Açıklama için Gemini API anahtarı gerekli.");String ar=h.matn==null||h.matn.trim().isEmpty()?h.arabic:h.matn;
        String prompt="Bu hadisi yalnız verilen Arapça metin, kaynak ve derece bilgisi sınırında açıkla. Türkçe, doğal ve ihtiyatlı yaz. Başlıklar: Açıklama; Günlük hayat bağlantısı; Tefekkür; Doğrulama sınırı. Yeni rivayet, ravi, fazilet, sayı, fetva veya kaynak uydurma. Teknik kod ve kaynak parantezi kullanma. Kaynak satırı yazma.\n\nARAPÇA:\n"+ar+"\n\nKAYNAK: "+h.book()+" "+h.number+" · "+h.reference+"\nDERECE: "+h.grade;String out=CitationFormatter.humanize(c,GeminiClient.generate(c,prompt,false)).trim();if(out.length()<80)throw new Exception("Açıklama üretilemedi.");ls.cachePut(key,out);return out;
    }
    static String cachedTurkishMeaning(Context c,Dua d){return LocalStore.get(c).cacheGet("dua_tr:"+d.number);}
    static String turkishMeaning(Context c,Hadith h)throws Exception{
        String key="hadith_tr:"+h.collectionId+":"+h.number;LocalStore ls=LocalStore.get(c);String cached=ls.cacheGet(key);if(!cached.isEmpty())return cached;if(!GeminiClient.configured(c))throw new Exception("Türkçe anlam için Gemini API anahtarı gerekli.");String ar=h.matn==null||h.matn.trim().isEmpty()?h.arabic:h.matn;
        String prompt="Aşağıdaki hadis Arapça aslından Türkçeye erişim amacıyla gösterilecek. Metne sadık, doğal ve ihtiyatlı bir Türkçe anlam ver. Yeni hüküm, ravi, olay veya açıklama ekleme. Arapçada kapalı/çok anlamlı bir ifade varsa kısa parantezle 'yaklaşık anlam' diye belirt. Kaynak satırı ekleme; kaynak uygulamada ayrı gösterilir. Teknik kod kullanma.\n\nARAPÇA:\n"+ar+"\n\nKAYNAK BİLGİSİ: "+h.reference+"\nDERECE: "+h.grade;String out=CitationFormatter.humanize(c,GeminiClient.generate(c,prompt,false)).trim();if(out.length()<20)throw new Exception("Türkçe anlam üretilemedi.");ls.cachePut(key,out);return out;
    }
    static String turkishMeaning(Context c,Dua d)throws Exception{
        String key="dua_tr:"+d.number;LocalStore ls=LocalStore.get(c);String cached=ls.cacheGet(key);if(!cached.isEmpty())return cached;if(!GeminiClient.configured(c))throw new Exception("Türkçe anlam için Gemini API anahtarı gerekli.");String prompt="Aşağıdaki dua/zikir metnini Arapça aslına sadık biçimde Türkçeye aktar. Önce kısa anlamı ver; ardından varsa kullanım bağlamını yalnız kaynak bilgisinden çıkarılabildiği ölçüde belirt. Kaynakta olmayan sayı, vakit, fazilet veya garanti ekleme. Teknik kod kullanma.\n\nARAPÇA:\n"+d.arabic+"\nLATİN OKUNUŞ:\n"+d.reading+"\nKAYNAK: "+d.reference+" "+d.hisnReference;String out=GeminiClient.generate(c,prompt,false).trim();if(out.length()<10)throw new Exception("Türkçe anlam üretilemedi.");ls.cachePut(key,out);return out;
    }
    private static String inferCollection(String raw){String s=(raw==null?"":raw).toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');if(s.contains("buhari")||s.contains("bukhari"))return "bukhari";if(s.contains("muslim")||s.contains("muslim"))return "muslim";if(s.contains("nesai")||s.contains("nasai"))return "nasai";if(s.contains("ebu davud")||s.contains("abu dawud")||s.contains("abudawud"))return "abudawud";if(s.contains("tirmizi")||s.contains("tirmidhi"))return "tirmidhi";if(s.contains("ibn mace")||s.contains("ibn majah")||s.contains("ibnmajah"))return "ibnmajah";return "";}
    private static String extractNumber(String s){if(s==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:^|\\D)(\\d{1,6})(?:\\D|$)").matcher(s);String last="";while(m.find())last=m.group(1);return last;}

    static String[] collectionIds(){return new String[]{ALL,"bukhari","muslim","nasai","abudawud","tirmidhi","ibnmajah"};}
    static String[] collectionNames(){return new String[]{"Tümü","Sahih Buhârî","Sahih Müslim","Sünen Nesâî","Sünen Ebû Dâvûd","Câmi‘ Tirmizî","Sünen İbn Mâce"};}
    static String bookName(String id){if("bukhari".equals(id))return "Sahih Buhârî";if("muslim".equals(id))return "Sahih Müslim";if("nasai".equals(id))return "Sünen Nesâî";if("abudawud".equals(id))return "Sünen Ebû Dâvûd";if("tirmidhi".equals(id))return "Câmi‘ Tirmizî";if("ibnmajah".equals(id))return "Sünen İbn Mâce";return "Kütüb-i Sitte";}
    private static String nz(String s){return s==null?"":s;}
    private HadithCorpus(){}
}
