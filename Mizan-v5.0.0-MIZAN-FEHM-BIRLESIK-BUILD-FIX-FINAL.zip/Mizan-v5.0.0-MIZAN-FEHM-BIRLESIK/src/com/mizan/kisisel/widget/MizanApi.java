package com.mizan.kisisel.widget;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

final class MizanApi {
    static final class ChatResult {final boolean ok;final String answer,error;ChatResult(boolean ok,String answer,String error){this.ok=ok;this.answer=answer;this.error=error;}}
    static final class ArchiveDay {final String dateKey,dateLabel;final List<TodaySync.Item> items;ArchiveDay(String dateKey,String dateLabel,List<TodaySync.Item> items){this.dateKey=dateKey;this.dateLabel=dateLabel;this.items=items;}}
    static final class ArchiveResult {final boolean ok;final String error;final List<ArchiveDay> days;ArchiveResult(boolean ok,String error,List<ArchiveDay> days){this.ok=ok;this.error=error;this.days=days;}}
    static ChatResult chat(Context c,String q){if(q==null||q.trim().isEmpty())return new ChatResult(false,"","Sorunu yazmalısın.");return SourceEngine.chat(c,q.trim());}
    static ArchiveResult library(Context c){try{return new ArchiveResult(true,"",LocalStore.get(c).archive(365));}catch(Exception e){return new ArchiveResult(false,"Kütüphane okunamadı.",new ArrayList<ArchiveDay>());}}
    private MizanApi(){}
}
