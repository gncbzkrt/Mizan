package com.mizan.kisisel.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.widget.RemoteViews;

import java.util.Locale;

public class MizanWidgetProvider extends AppWidgetProvider {
    static final String ACTION_NEXT = "com.mizan.kisisel.widget.NEXT";
    static final String ACTION_REFRESH_PRAYERS = "com.mizan.kisisel.widget.REFRESH_PRAYERS";
    static final String ACTION_REFRESH_TODAY = "com.mizan.kisisel.widget.REFRESH_TODAY";
    static final String MIZAN_URL = "https://mizan-kisisel.magic-boot-2498.chatgpt.site";
    private static final String PREFS = "mizan_widget";
    private static final String STEP = "manual_step";
    private static final String DATE = "last_date";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        normalizeDay(context);
        for (int id : ids) updateWidget(context, manager, id);
        refreshAll(context);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, android.os.Bundle options) {
        updateWidget(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        if (ACTION_NEXT.equals(action)) {
            TodaySync.PackageData data = TodaySync.cached(context);
            int count = data.items.size() > 0 ? data.items.size() : 5;
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int next = (currentStep(context, count) + 1) % count;
            prefs.edit().putInt(STEP, next).putString(DATE, TodaySync.todayKey()).apply();
            updateAll(context);
        } else if (ACTION_REFRESH_PRAYERS.equals(action) || ACTION_REFRESH_TODAY.equals(action)) {
            refreshAll(context);
        }
    }

    static int currentStep(Context context, int count) {
        if (count <= 0) return 0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int value = prefs.getInt(STEP, 0);
        return ((value % count) + count) % count;
    }

    private static void normalizeDay(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = TodaySync.todayKey();
        if (!today.equals(prefs.getString(DATE, ""))) prefs.edit().putString(DATE, today).putInt(STEP, 0).apply();
    }

    static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        normalizeDay(context);
        TodaySync.PackageData data = TodaySync.cached(context);
        int count = data.items.size();
        int step = currentStep(context, count > 0 ? count : 5);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_mizan);
        if (data.ok && count > 0) {
            TodaySync.Item item = data.items.get(Math.min(step, count - 1));
            views.setTextViewText(R.id.widget_type, item.type.toUpperCase(new Locale("tr", "TR")));
            views.setTextViewText(R.id.widget_date, data.dateLabel);
            views.setTextViewText(R.id.widget_title, item.title);
            views.setTextViewText(R.id.widget_sync_status, "Yerel kaynak + Mîzan AI");
            views.setTextViewText(R.id.widget_next, step == count - 1 ? "BAŞA DÖN" : "SONRAKİ");
        } else {
            views.setTextViewText(R.id.widget_type, "MÎZAN · BUGÜN");
            views.setTextViewText(R.id.widget_date, TodaySync.todayLabel());
            views.setTextViewText(R.id.widget_title, "Bugünün Mîzan paketi hazırlanıyor");
            views.setTextViewText(R.id.widget_sync_status, data.error);
            views.setTextViewText(R.id.widget_next, "YENİLE");
        }

        PrayerTimes.Times prayers = PrayerTimes.cached(context);
        views.setTextViewText(R.id.widget_prayer_summary, prayers.summary());
        views.setTextViewText(R.id.widget_imsak, prayers.imsak);
        views.setTextViewText(R.id.widget_gunes, prayers.gunes);
        views.setTextViewText(R.id.widget_ogle, prayers.ogle);
        views.setTextViewText(R.id.widget_ikindi, prayers.ikindi);
        views.setTextViewText(R.id.widget_aksam, prayers.aksam);
        views.setTextViewText(R.id.widget_yatsi, prayers.yatsi);
        markActivePrayer(views, prayers.nextPrayerSlot());

        Intent serviceIntent = new Intent(context, WidgetContentService.class);
        serviceIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        serviceIntent.setData(Uri.parse(serviceIntent.toUri(Intent.URI_INTENT_SCHEME)));
        views.setRemoteAdapter(R.id.widget_scroll, serviceIntent);

        Intent openIntent = new Intent(context, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(context, 10000 + appWidgetId, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_open, openPending);

        Intent nextIntent = new Intent(context, MizanWidgetProvider.class);
        nextIntent.setAction(data.ok ? ACTION_NEXT : ACTION_REFRESH_TODAY);
        nextIntent.setPackage(context.getPackageName());
        PendingIntent nextPending = PendingIntent.getBroadcast(context, 20000 + appWidgetId, nextIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_next, nextPending);

        manager.updateAppWidget(appWidgetId, views);
        manager.notifyAppWidgetViewDataChanged(appWidgetId, R.id.widget_scroll);
    }

    private void refreshAll(final Context context) {
        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    PrayerTimes.refresh(context.getApplicationContext());
                    TodaySync.refresh(context.getApplicationContext());
                    updateAll(context);
                } finally { pending.finish(); }
            }
        }, "mizan-today-refresh").start();
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, MizanWidgetProvider.class));
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void markActivePrayer(RemoteViews views, int activeSlot) {
        int[] boxes = {R.id.prayer_box_imsak,R.id.prayer_box_gunes,R.id.prayer_box_ogle,R.id.prayer_box_ikindi,R.id.prayer_box_aksam,R.id.prayer_box_yatsi};
        int[] times = {R.id.widget_imsak,R.id.widget_gunes,R.id.widget_ogle,R.id.widget_ikindi,R.id.widget_aksam,R.id.widget_yatsi};
        for (int i=0;i<boxes.length;i++) { views.setInt(boxes[i], "setBackgroundResource", R.drawable.prayer_time_box); views.setTextColor(times[i], Color.parseColor("#EFF8F3")); }
        if (activeSlot >= 0 && activeSlot < boxes.length) { views.setInt(boxes[activeSlot], "setBackgroundResource", R.drawable.prayer_time_box_active); views.setTextColor(times[activeSlot], Color.parseColor("#F4D77F")); }
    }
}
