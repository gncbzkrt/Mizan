package com.mizan.kisisel.widget;

import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.List;

public class WidgetContentService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) { return new Factory(); }

    private class Factory implements RemoteViewsFactory {
        private final List<String> rows = new ArrayList<String>();
        @Override public void onCreate() { loadRows(); }
        @Override public void onDataSetChanged() { loadRows(); }
        private void loadRows(){
            rows.clear();
            TodaySync.PackageData data = TodaySync.cached(WidgetContentService.this);
            int step = MizanWidgetProvider.currentStep(WidgetContentService.this, data.items.size());
            String text;
            if (data.ok && !data.items.isEmpty()) text = data.items.get(step).scrollText(getApplicationContext());
            else text = data.error + "\n\nMîzan uygulamasını açıp Gemini ayarlarını kontrol et.";
            String[] parts=text.split("\n\n+");
            for(String part:parts){String x=part.trim();if(!x.isEmpty())rows.add(x);}
            if(rows.isEmpty())rows.add(text);
        }
        @Override public void onDestroy() { }
        @Override public int getCount() { return rows.size(); }
        @Override public RemoteViews getViewAt(int position) {
            RemoteViews row = new RemoteViews(getPackageName(), R.layout.widget_content_row);
            String text=(position>=0&&position<rows.size())?rows.get(position):"";
            row.setTextViewText(R.id.widget_scroll_text, text);
            return row;
        }
        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int position) { return position; }
        @Override public boolean hasStableIds() { return true; }
    }
}
