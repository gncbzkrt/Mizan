package com.mizan.kisisel.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

final class PrayerTimes {
    private static final String PREFS = "mizan_prayer_times";
    private static final String DATE = "date";
    private static final String[] KEYS = {"imsak", "gunes", "ogle", "ikindi", "aksam", "yatsi"};
    private static final TimeZone ISTANBUL = TimeZone.getTimeZone("Europe/Istanbul");
    private static final Locale TR = new Locale("tr", "TR");
    private static final String API = "https://api.aladhan.com/v1/timings/";

    static final class Times {
        final String date;
        final String imsak;
        final String gunes;
        final String ogle;
        final String ikindi;
        final String aksam;
        final String yatsi;
        final boolean available;

        Times(String date, String imsak, String gunes, String ogle, String ikindi, String aksam, String yatsi) {
            this.date = date;
            this.imsak = imsak;
            this.gunes = gunes;
            this.ogle = ogle;
            this.ikindi = ikindi;
            this.aksam = aksam;
            this.yatsi = yatsi;
            this.available = !"--:--".equals(imsak);
        }

        String summary() {
            if (!available) return "MANİSA · Vakitler getiriliyor…";
            String[] labels = {"İMSAK", "ÖĞLE", "İKİNDİ", "AKŞAM", "YATSI"};
            String[] values = {imsak, ogle, ikindi, aksam, yatsi};
            Calendar now = Calendar.getInstance(ISTANBUL, TR);
            int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            for (int i = 0; i < values.length; i++) {
                int target = toMinutes(values[i]);
                if (target > nowMinutes) {
                    return "MANİSA · Sıradaki " + labels[i] + " " + values[i] + " · " + remaining(target - nowMinutes);
                }
            }
            int tomorrowImsak = 24 * 60 + toMinutes(imsak);
            return "MANİSA · Sıradaki İMSAK " + imsak + " · " + remaining(tomorrowImsak - nowMinutes);
        }

        int nextPrayerSlot() {
            if (!available) return -1;
            String[] values = {imsak, ogle, ikindi, aksam, yatsi};
            int[] slots = {0, 2, 3, 4, 5};
            Calendar now = Calendar.getInstance(ISTANBUL, TR);
            int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            for (int i = 0; i < values.length; i++) {
                if (toMinutes(values[i]) > nowMinutes) return slots[i];
            }
            return 0;
        }

        String timetable() {
            return "İmsak " + imsak + "  •  Güneş " + gunes + "  •  Öğle " + ogle +
                "\nİkindi " + ikindi + "  •  Akşam " + aksam + "  •  Yatsı " + yatsi;
        }
    }

    static Times cached(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return new Times(
            prefs.getString(DATE, ""),
            prefs.getString(KEYS[0], "--:--"),
            prefs.getString(KEYS[1], "--:--"),
            prefs.getString(KEYS[2], "--:--"),
            prefs.getString(KEYS[3], "--:--"),
            prefs.getString(KEYS[4], "--:--"),
            prefs.getString(KEYS[5], "--:--")
        );
    }

    static void refresh(Context context) {
        HttpURLConnection connection = null;
        try {
            String date = date("dd-MM-yyyy");
            URL url = new URL(API + date + "?latitude=38.6191&longitude=27.4289&method=13&school=0");
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(4500);
            connection.setReadTimeout(4500);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            if (connection.getResponseCode() != 200) return;

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            reader.close();

            JSONObject root = new JSONObject(json.toString());
            if (root.optInt("code", 0) != 200) return;
            JSONObject timings = root.getJSONObject("data").getJSONObject("timings");
            String[] values = {
                clean(timings.optString("Fajr")),
                clean(timings.optString("Sunrise")),
                clean(timings.optString("Dhuhr")),
                clean(timings.optString("Asr")),
                addMinute(clean(timings.optString("Maghrib"))),
                addMinute(clean(timings.optString("Isha")))
            };
            for (String value : values) if ("--:--".equals(value)) return;

            SharedPreferences.Editor editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
            editor.putString(DATE, date);
            for (int i = 0; i < KEYS.length; i++) editor.putString(KEYS[i], values[i]);
            editor.putLong("updated_at", System.currentTimeMillis());
            editor.apply();
        } catch (Exception ignored) {
            // Son başarılı kayıt korunur; çevrimdışı durumda widget boş bırakılmaz.
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String clean(String value) {
        if (value == null) return "--:--";
        String trimmed = value.trim();
        return trimmed.matches("[0-2][0-9]:[0-5][0-9].*") ? trimmed.substring(0, 5) : "--:--";
    }

    private static String addMinute(String value) {
        int minutes = toMinutes(value);
        if (minutes < 0) return "--:--";
        minutes = (minutes + 1) % (24 * 60);
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    private static int toMinutes(String value) {
        try {
            String[] parts = value.split(":");
            return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
        } catch (Exception ignored) {
            return -1;
        }
    }

    private static String remaining(int minutes) {
        int hours = Math.max(0, minutes) / 60;
        int rest = Math.max(0, minutes) % 60;
        return hours > 0 ? hours + " sa " + rest + " dk" : rest + " dk";
    }

    private static String date(String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
        format.setTimeZone(ISTANBUL);
        return format.format(new Date());
    }

    private PrayerTimes() { }
}
