package com.mizan.kisisel.widget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Locale;

final class LocalStore extends SQLiteOpenHelper {
    private static final String DB="mizan_personal.db";
    private static final int VERSION=4;
    private static LocalStore instance;
    static synchronized LocalStore get(Context c){ if(instance==null) instance=new LocalStore(c.getApplicationContext()); return instance; }
    private LocalStore(Context c){ super(c,DB,null,VERSION); }
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE sources(_id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT UNIQUE, type TEXT, title TEXT, body TEXT, reference TEXT, grade TEXT, keywords TEXT, url TEXT, note TEXT, status TEXT, origin TEXT, arabic TEXT DEFAULT '', reading TEXT DEFAULT '', created_at INTEGER, updated_at INTEGER)");
        db.execSQL("CREATE TABLE daily(day_key TEXT PRIMARY KEY, day_label TEXT, json TEXT, theme TEXT, created_at INTEGER)");
        db.execSQL("CREATE TABLE candidates(_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, type TEXT, body TEXT, reference TEXT, url TEXT, reason TEXT, confidence TEXT, status TEXT, created_at INTEGER)");
        db.execSQL("CREATE TABLE chat(_id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, created_at INTEGER)");
        db.execSQL("CREATE TABLE favorites(fav_key TEXT PRIMARY KEY, type TEXT, title TEXT, body TEXT, source TEXT, arabic TEXT, reading TEXT, created_at INTEGER)");
        db.execSQL("CREATE TABLE ai_cache(cache_key TEXT PRIMARY KEY, text TEXT, updated_at INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
        if(oldVersion<2){try{db.execSQL("ALTER TABLE sources ADD COLUMN arabic TEXT DEFAULT ''");}catch(Exception ignored){} try{db.execSQL("ALTER TABLE sources ADD COLUMN reading TEXT DEFAULT ''");}catch(Exception ignored){}}
        if(oldVersion<3){try{db.execSQL("CREATE TABLE IF NOT EXISTS favorites(fav_key TEXT PRIMARY KEY, type TEXT, title TEXT, body TEXT, source TEXT, arabic TEXT, reading TEXT, created_at INTEGER)");}catch(Exception ignored){}}
        if(oldVersion<4){try{db.execSQL("CREATE TABLE IF NOT EXISTS ai_cache(cache_key TEXT PRIMARY KEY, text TEXT, updated_at INTEGER)");}catch(Exception ignored){}}
    }

    synchronized void seedIfNeeded(Context c){
        SQLiteDatabase db=getWritableDatabase();
        syncCoreSeed(c,db);
    }
    private synchronized void syncCoreSeed(Context c,SQLiteDatabase db){
        db.beginTransaction();
        try{
            BufferedReader r=new BufferedReader(new InputStreamReader(c.getAssets().open("source_seed.json"),"UTF-8"));StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null)sb.append(line);r.close();
            JSONArray a=new JSONArray(sb.toString());long now=System.currentTimeMillis();
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);String id=o.optString("id");if(id.isEmpty())continue;
                SourceRecord sr=new SourceRecord(id,o.optString("type"),o.optString("title"),o.optString("body"),o.optString("reference"),o.optString("grade"),o.optString("keywords"),o.optString("url"),o.optString("note"),"ACTIVE","CORE");sr.arabic=o.optString("arabic","");sr.reading=o.optString("reading","");
                ContentValues v=values(sr);v.put("updated_at",now);long ins=db.insertWithOnConflict("sources",null,v,SQLiteDatabase.CONFLICT_IGNORE);
                if(ins<0){db.update("sources",v,"source_id=? AND origin='CORE'",new String[]{id});}
            }
            db.setTransactionSuccessful();
        }catch(Exception ignored){} finally{db.endTransaction();}
    }

    private void insertSource(SQLiteDatabase db,SourceRecord s){
        ContentValues v=values(s); long now=System.currentTimeMillis();v.put("created_at",now);v.put("updated_at",now);db.insertWithOnConflict("sources",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    synchronized long addSource(SourceRecord s){ ContentValues v=values(s);long now=System.currentTimeMillis();v.put("created_at",now);v.put("updated_at",now);return getWritableDatabase().insertWithOnConflict("sources",null,v,SQLiteDatabase.CONFLICT_IGNORE); }
    private ContentValues values(SourceRecord s){ContentValues v=new ContentValues();v.put("source_id",s.id);v.put("type",s.type);v.put("title",s.title);v.put("body",s.body);v.put("reference",s.reference);v.put("grade",s.grade);v.put("keywords",s.keywords);v.put("url",s.url);v.put("note",s.note);v.put("status",s.status);v.put("origin",s.origin);v.put("arabic",s.arabic==null?"":s.arabic);v.put("reading",s.reading==null?"":s.reading);return v;}
    synchronized int sourceCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sources WHERE status='ACTIVE'",null);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    synchronized int countType(String type){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sources WHERE status='ACTIVE' AND type=?",new String[]{type});int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    synchronized List<SourceRecord> allType(String type){return query("SELECT * FROM sources WHERE status='ACTIVE' AND type=? ORDER BY source_id",new String[]{type});}
    synchronized SourceRecord sourceById(String id){List<SourceRecord> a=query("SELECT * FROM sources WHERE source_id=? LIMIT 1",new String[]{id});return a.isEmpty()?null:a.get(0);}
    synchronized String citationLabel(String id){SourceRecord s=sourceById(id);if(s==null)return "yerel kaynak";String ref=s.reference==null?"":s.reference.trim();String title=s.title==null?"":s.title.trim();if("AYET".equals(s.type)||"HADIS".equals(s.type)||"ZIKIR".equals(s.type))return ref.isEmpty()?title:ref;if("WEB_APPROVED".equals(s.origin))return title.isEmpty()?ref:(ref.isEmpty()?title:title+" · "+ref);return title.isEmpty()?ref:(ref.isEmpty()?title:title+" · "+ref);}
    synchronized List<SourceRecord> search(String q,int limit){
        List<SourceRecord> all=query("SELECT * FROM sources WHERE status='ACTIVE'",null); String nq=norm(q); String[] toks=nq.split("\\s+");
        java.util.Collections.sort(all,new java.util.Comparator<SourceRecord>(){public int compare(SourceRecord a,SourceRecord b){return score(b,toks)-score(a,toks);}});
        List<SourceRecord> out=new ArrayList<SourceRecord>();for(SourceRecord s:all){if(score(s,toks)>0||out.isEmpty()){out.add(s);if(out.size()>=limit)break;}}return out;
    }
    private int score(SourceRecord s,String[] toks){String hay=norm((s.title+" "+s.body+" "+s.reference+" "+s.keywords+" "+s.note));int n=0;for(String t:toks){if(t.length()<2)continue;if(hay.contains(t))n+=(s.keywords!=null&&norm(s.keywords).contains(t))?5:2;}return n;}
    private static String norm(String x){return (x==null?"":x).toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c');}
    private List<SourceRecord> query(String sql,String[] args){List<SourceRecord> out=new ArrayList<SourceRecord>();Cursor c=getReadableDatabase().rawQuery(sql,args);while(c.moveToNext())out.add(from(c));c.close();return out;}
    private SourceRecord from(Cursor c){SourceRecord s=new SourceRecord();s.rowId=c.getLong(c.getColumnIndexOrThrow("_id"));s.id=c.getString(c.getColumnIndexOrThrow("source_id"));s.type=c.getString(c.getColumnIndexOrThrow("type"));s.title=c.getString(c.getColumnIndexOrThrow("title"));s.body=c.getString(c.getColumnIndexOrThrow("body"));s.reference=c.getString(c.getColumnIndexOrThrow("reference"));s.grade=c.getString(c.getColumnIndexOrThrow("grade"));s.keywords=c.getString(c.getColumnIndexOrThrow("keywords"));s.url=c.getString(c.getColumnIndexOrThrow("url"));s.note=c.getString(c.getColumnIndexOrThrow("note"));s.status=c.getString(c.getColumnIndexOrThrow("status"));s.origin=c.getString(c.getColumnIndexOrThrow("origin"));int ai=c.getColumnIndex("arabic"),ri=c.getColumnIndex("reading");s.arabic=ai>=0?c.getString(ai):"";s.reading=ri>=0?c.getString(ri):"";return s;}

    synchronized void saveDaily(String key,String label,String json,String theme){ContentValues v=new ContentValues();v.put("day_key",key);v.put("day_label",label);v.put("json",json);v.put("theme",theme);v.put("created_at",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("daily",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    synchronized String dailyJson(String key){Cursor c=getReadableDatabase().rawQuery("SELECT json FROM daily WHERE day_key=?",new String[]{key});String s=c.moveToFirst()?c.getString(0):"";c.close();return s;}
    synchronized Set<String> recentSourceIds(String type,String excludeDayKey,int limit){
        Set<String> out=new HashSet<String>();
        Cursor c=getReadableDatabase().rawQuery("SELECT json FROM daily WHERE day_key<>? ORDER BY day_key DESC LIMIT "+Math.max(1,Math.min(90,limit)),new String[]{excludeDayKey==null?"":excludeDayKey});
        while(c.moveToNext()){
            try{
                JSONObject root=new JSONObject(c.getString(0));JSONArray items=root.optJSONArray("items");if(items==null)continue;
                for(int i=0;i<items.length();i++){JSONObject o=items.optJSONObject(i);if(o==null||!dailyTypeEquals(type,o.optString("type","")))continue;String src=o.optString("source","").trim();if(src.isEmpty())continue;int cut=src.indexOf(" · ");String id=(cut>0?src.substring(0,cut):src).trim();if(id.startsWith("[")&&id.endsWith("]"))id=id.substring(1,id.length()-1).trim();if(!id.isEmpty())out.add(id);}
            }catch(Exception ignored){}
        }
        c.close();return out;
    }
    private static boolean dailyTypeEquals(String wanted,String shown){String a=dailyTypeNorm(wanted),b=dailyTypeNorm(shown);return a.equals(b);}
    private static String dailyTypeNorm(String s){return (s==null?"":s).toUpperCase(new Locale("tr","TR")).replace('İ','I').replace('Ş','S').replace('Ğ','G').replace('Ü','U').replace('Ö','O').replace('Ç','C');}
    synchronized List<MizanApi.ArchiveDay> archive(int limit){List<MizanApi.ArchiveDay> out=new ArrayList<MizanApi.ArchiveDay>();Cursor c=getReadableDatabase().rawQuery("SELECT day_key,day_label,json FROM daily ORDER BY day_key DESC LIMIT "+Math.max(1,Math.min(365,limit)),null);while(c.moveToNext()){try{TodaySync.PackageData p=TodaySync.parse(c.getString(2));out.add(new MizanApi.ArchiveDay(c.getString(0),c.getString(1),p.items));}catch(Exception ignored){}}c.close();return out;}

    synchronized long addCandidate(String title,String type,String body,String reference,String url,String reason,String confidence){ContentValues v=new ContentValues();v.put("title",title);v.put("type",type);v.put("body",body);v.put("reference",reference);v.put("url",url);v.put("reason",reason);v.put("confidence",confidence);v.put("status","PENDING");v.put("created_at",System.currentTimeMillis());return getWritableDatabase().insert("candidates",null,v);}
    synchronized long addCandidateIfNew(String title,String type,String body,String reference,String url,String reason,String confidence){
        String u=url==null?"":url.trim();String r=reference==null?"":reference.trim();String t=title==null?"":title.trim();
        Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM sources WHERE (url<>'' AND url=?) OR (reference<>'' AND reference=? AND title=?) LIMIT 1",new String[]{u,r,t});boolean exists=c.moveToFirst();c.close();if(exists)return -1;
        c=getReadableDatabase().rawQuery("SELECT 1 FROM candidates WHERE status='PENDING' AND ((url<>'' AND url=?) OR (reference<>'' AND reference=? AND title=?)) LIMIT 1",new String[]{u,r,t});exists=c.moveToFirst();c.close();if(exists)return -1;
        return addCandidate(t,type,body,r,u,reason,confidence);
    }
    synchronized List<ResearchCandidate> pendingCandidates(){List<ResearchCandidate> out=new ArrayList<ResearchCandidate>();Cursor c=getReadableDatabase().rawQuery("SELECT * FROM candidates WHERE status='PENDING' ORDER BY _id DESC",null);while(c.moveToNext()){ResearchCandidate r=new ResearchCandidate();r.id=c.getLong(c.getColumnIndexOrThrow("_id"));r.title=c.getString(c.getColumnIndexOrThrow("title"));r.type=c.getString(c.getColumnIndexOrThrow("type"));r.body=c.getString(c.getColumnIndexOrThrow("body"));r.reference=c.getString(c.getColumnIndexOrThrow("reference"));r.url=c.getString(c.getColumnIndexOrThrow("url"));r.reason=c.getString(c.getColumnIndexOrThrow("reason"));r.confidence=c.getString(c.getColumnIndexOrThrow("confidence"));out.add(r);}c.close();return out;}
    synchronized String decideCandidate(long id,boolean approve){
        SQLiteDatabase db=getWritableDatabase();Cursor c=db.rawQuery("SELECT * FROM candidates WHERE _id=?",new String[]{String.valueOf(id)});if(!c.moveToFirst()){c.close();return "";}String sid="";
        if(approve){
            String type=c.getString(c.getColumnIndexOrThrow("type"));String title=c.getString(c.getColumnIndexOrThrow("title"));String body=c.getString(c.getColumnIndexOrThrow("body"));String reference=c.getString(c.getColumnIndexOrThrow("reference"));String url=c.getString(c.getColumnIndexOrThrow("url"));String reason=c.getString(c.getColumnIndexOrThrow("reason"));
            sid="WEB"+System.currentTimeMillis();String keywords=((title==null?"":title)+" "+(body==null?"":body)+" "+(reason==null?"":reason)).trim();
            SourceRecord s=new SourceRecord(sid,type,title,body,reference,"Kullanıcı onaylı web kaynağı",keywords,url,"Kullanıcı onayıyla eklendi. "+(reason==null?"":reason),"ACTIVE","WEB_APPROVED");long row=addSource(s);if(row<0)sid="";
        }
        c.close();ContentValues v=new ContentValues();v.put("status",approve?"APPROVED":"REJECTED");db.update("candidates",v,"_id=?",new String[]{String.valueOf(id)});return sid;
    }
    synchronized void setFavorite(String key,TodaySync.Item it,boolean on){SQLiteDatabase db=getWritableDatabase();if(!on){db.delete("favorites","fav_key=?",new String[]{key});return;}ContentValues v=new ContentValues();v.put("fav_key",key);v.put("type",it.type);v.put("title",it.title);v.put("body",it.body);v.put("source",it.source);v.put("arabic",it.arabic);v.put("reading",it.reading);v.put("created_at",System.currentTimeMillis());db.insertWithOnConflict("favorites",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    synchronized boolean isFavorite(String key){Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM favorites WHERE fav_key=? LIMIT 1",new String[]{key});boolean ok=c.moveToFirst();c.close();return ok;}
    static final class FavoriteRecord {String key;TodaySync.Item item;long createdAt;}
    synchronized List<FavoriteRecord> favorites(){List<FavoriteRecord> out=new ArrayList<FavoriteRecord>();Cursor c=getReadableDatabase().rawQuery("SELECT fav_key,type,title,body,source,arabic,reading,created_at FROM favorites ORDER BY created_at DESC",null);while(c.moveToNext()){FavoriteRecord r=new FavoriteRecord();r.key=c.getString(0);r.item=new TodaySync.Item(c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6));r.createdAt=c.getLong(7);out.add(r);}c.close();return out;}
    synchronized String cacheGet(String key){Cursor c=getReadableDatabase().rawQuery("SELECT text FROM ai_cache WHERE cache_key=?",new String[]{key});String v=c.moveToFirst()?c.getString(0):"";c.close();return v==null?"":v;}
    synchronized void cachePut(String key,String text){ContentValues v=new ContentValues();v.put("cache_key",key);v.put("text",text==null?"":text);v.put("updated_at",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("ai_cache",null,v,SQLiteDatabase.CONFLICT_REPLACE);}

    static final class ResearchCandidate {long id;String title,type,body,reference,url,reason,confidence;}
}
