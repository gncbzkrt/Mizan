package com.mizan.kisisel.widget;

final class DailyContent {
    static final class Item {
        final String type;
        final String title;
        final String arabic;
        final String reading;
        final String body;
        final String quote;
        final String detail;
        final String secondDetail;
        final String guidance;
        final String related;
        final String closing;
        final String source;

        Item(String type, String title, String arabic, String reading, String body, String source) {
            this.type = type;
            this.title = title;
            this.arabic = arabic;
            this.reading = reading;
            this.body = body;
            this.quote = quoteFor(type, title);
            this.detail = primaryDetailFor(type, title, body);
            this.secondDetail = secondDetailFor(type, title);
            this.guidance = guidanceFor(type, title);
            this.related = relatedFor(type, title);
            this.closing = closingFor(type, title);
            this.source = source;
        }
    }

    private static Item ayet(String title, String body, String source) {
        return new Item("Günün ayeti", title, "", "", body, source);
    }

    private static Item hadis(String title, String body, String source) {
        return new Item("Günün hadisi", title, "", "", body, source);
    }

    private static Item kissa(String title, String body, String source) {
        return new Item("Günün kıssası", title, "", "", body, source);
    }

    private static Item zikir(String title, String arabic, String reading, String body, String source) {
        return new Item("Günün zikri", title, arabic, reading, body, source);
    }

    static String detailTitleFor(String type) {
        if (type.contains("kıssa")) return "HİKÂYENİN AKIŞI";
        if (type.contains("ayet")) return "BAĞLAM VE TEFSİR YÖNÜ";
        if (type.contains("hadis")) return "AÇIKLAMA VE ÖLÇÜ";
        return "ANLAM · VAKİT · SAYI";
    }

    static String secondTitleFor(String type) {
        if (type.contains("kıssa")) return "DÖNÜM NOKTASI VE ANA DERS";
        if (type.contains("ayet")) return "AYETİN ANA ÖLÇÜSÜ";
        if (type.contains("hadis")) return "SINIR VE DENGE";
        return "DAYANAK VE BİLİNÇ";
    }

    static String guidanceTitleFor(String type) {
        if (isZikirType(type)) return "BİLİNÇLİ OKUMA";
        if (type.contains("hadis")) return "HAYATA TAŞI · TEFEKKÜR";
        return "MÎZAN’IN REHBERLİĞİ · TEFEKKÜR";
    }

    static String quoteTitleFor(String type, String title) {
        if (type.contains("ayet")) {
            return title.equals("Çıkış yolu ve tevekkül") ? "AYETLERİN ANA ANLAMI · DİYANET KONTROLÜ" : "AYETİN ANLAM ÖZETİ · DİYANET KONTROLÜ";
        }
        if (type.contains("hadis")) return "HADİSİN ANLAMI";
        if (type.contains("kıssa")) return "KUR’AN’DAKİ ANA SAHNE";
        return "";
    }

    static String relatedTitleFor(String type) {
        if (type.contains("ayet")) return "İLGİLİ KAYNAK · YANLIŞ ANLAMA";
        if (type.contains("hadis")) return "KUR’AN’LA BİRLİKTE OKU · SINIR";
        if (type.contains("kıssa")) return "KUR’AN’IN ÖNE ÇIKARDIĞI SINIR";
        return "KAYNAKTAKİ ÖLÇÜ · SINIR";
    }

    static String closingTitleFor(String type) {
        if (type.contains("kıssa")) return "BUGÜNE TAŞI · KISA DUA";
        if (isZikirType(type)) return "BUGÜN NASIL OKUNUR? · DUA";
        return "GÜNLÜK ÖRNEK · KISA DUA";
    }

    static boolean isZikirType(String type) {
        return type.contains("zikir") || type.contains("zikri");
    }

    private static String primaryDetailFor(String type, String title, String body) {
        String value = detailFor(type, title, body);
        String marker = type.contains("ayet") ? "\n\nMîzan:" :
            type.contains("hadis") ? "\n\nUygulama:" :
            type.contains("kıssa") ? "\n\nDers:" : "";
        int markerIndex = marker.isEmpty() ? -1 : value.indexOf(marker);
        return markerIndex >= 0 ? value.substring(0, markerIndex) : value;
    }

    private static String quoteFor(String type, String title) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "İman edenlere güçlükler karşısında sabır ve namazla Allah’tan yardım istemeleri emredilir; Allah’ın sabredenlerle beraber olduğu bildirilir.";
            case "Kalbin asıl huzuru":
                return "İman edenlerin gönülleri Allah’ı anmakla huzura kavuşur; gerçek gönül huzurunun Allah’ı hatırda tutmakla bulunduğu bildirilir.";
            case "Rahmetten ümit kesme":
                return "Günah yüzünden kendilerine zarar veren kulların Allah’ın rahmetinden umut kesmemeleri istenir; O’nun çok bağışlayıcı ve merhametli olduğu bildirilir.";
            case "Güçlükle beraber kolaylık":
                return "Güçlüğün yanında bir kolaylığın da bulunduğu art arda iki kez vurgulanır.";
            case "Üstünlük ölçüsü takvadır":
                return "İnsanların aynı kökten yaratıldığı, farklı topluluklara tanışmaları için ayrıldığı; Allah katındaki değerin soyla değil, O’na karşı sorumluluk bilinciyle ölçüldüğü bildirilir.";
            case "Gevşemeyin, üzülmeyin":
                return "Müminlere gevşememeleri, üzüntüye teslim olmamaları ve imanlarını koruduklarında manevî üstünlüğe sahip oldukları bildirilir.";
            case "Çıkış yolu ve tevekkül":
                return "Kim Allah’a karşı gelmekten sakınırsa Allah ona bir çıkış yolu açar; onu beklemediği yerden rızıklandırır. Kim Allah’a tevekkül ederse O kendisine yeter. Allah her şeye bir ölçü koymuştur.";

            case "Niyet davranışın yönüdür":
                return "Ameller ancak niyetlere göredir. Herkes için yalnız niyet ettiği şey vardır.";
            case "Kardeşin için de iste":
                return "Sizden biri kendisi için sevdiğini kardeşi için de sevmedikçe iman etmiş olmaz.";
            case "Ya hayır söyle ya sus":
                return "Allah’a ve âhiret gününe iman eden kimse ya hayır söylesin ya da sussun.";
            case "Öfke anındaki gerçek güç":
                return "Güçlü kimse güreşte başkalarını yenen değil, öfke anında kendisine hâkim olandır.";
            case "Temizlik ve iman":
                return "Temizlik imanın yarısıdır.";
            case "Merhamet etmeyene merhamet edilmez":
                return "Merhamet etmeyene merhamet edilmez.";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Sizin en hayırlınız Kur’an’ı öğrenen ve öğretendir.";

            case "Mûsâ ve Bilge Kul":
                return "Mûsâ, Allah’ın özel bilgi verdiği kula kendisine öğretilen doğru yol bilgisinden öğrenmek için tâbi olmak istediğini söyler; yolculuk sabır şartıyla başlar.";
            case "Yûsuf’un sabır yolculuğu":
                return "Yûsuf, kardeşlerine ‘Bugün size kınama yoktur. Allah sizi bağışlasın; O merhametlilerin en merhametlisidir’ der.";
            case "Ashâb-ı Kehf":
                return "Biz sana onların başından geçenleri gerçeğe uygun olarak anlatıyoruz. Hakikaten onlar rablerine inanmış gençlerdi; biz de onların doğru yolda yürüyüşlerine katkıda bulunduk.";
            case "İbrâhim ve putlar":
                return "İbrâhim kavminin putlarını, belki ona başvururlar diye büyükleri hariç parçaladı; ardından onların konuşamayan ve kendini koruyamayan varlıklar olduğunu gösterdi.";
            case "Yûnus’un duası":
                return "Senden başka ilâh yoktur. Seni eksikliklerden uzak tutarım. Ben gerçekten nefsine zulmedenlerden oldum.";
            case "Tâlût ve Câlût":
                return "Nice az topluluk, Allah’ın izniyle çok topluluğa galip gelmiştir. Allah sabredenlerle beraberdir.";
            case "Süleyman ve karınca":
                return "Rabbim! Bana ve anne babama lutfettiğin nimete şükretmeye, razı olacağın işi yapmaya beni yönelt; rahmetinle beni iyi kullarının arasına kat.";
            default:
                return isZikirType(type) ? "" : "Kaynağın ana mesajı, bağlam ve uygulama bölümleriyle birlikte okunmalıdır.";
        }
    }

    private static String detailFor(String type, String title, String body) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "Bakara sûresindeki hitap, mümine zorluk karşısında iki dayanak gösterir: doğru tavırda sebat etmek ve namazla Allah’a yönelmek. Sabır edilgenlik değil, sorumluluğu bırakmadan dayanma gücüdür.\n\nMîzan: Bugün değiştirebileceğin tek şeyi belirle; sonucu aceleyle zorlamak yerine doğru adımı sürdür.";
            case "Kalbin asıl huzuru":
                return "Ra‘d 27–29 bağlamında iman, Allah’a yöneliş ve salih amel birlikte anılır. Zikir yalnız söz tekrarı değil; Allah’ı, vahyini ve sorumluluğu hatırda tutmaktır. Ayet hiç kaygı yaşanmayacağını değil, kalbin nihai dayanağını bildirir.\n\nMîzan: Tedbirini al, kontrol edemediğin sonucu Allah’a bırak.";
            case "Rahmetten ümit kesme":
                return "Zümer 39/53, günahı küçümsemeden Allah’ın rahmetinden ümit kesmemeyi öğretir. Ümit, hatada ısrar etmek değil; pişmanlık, dönüş ve düzeltme iradesidir.\n\nMîzan: Bugün telafi edebileceğin bir kusur için somut adım at.";
            case "Güçlükle beraber kolaylık":
                return "İnşirâh sûresi, güçlüğün varlığını inkâr etmez; onunla beraber açılan kolaylığı iki kez vurgular. Aynı zorluğun içinde yardım, öğrenme ve çıkış kapıları bulunabilir.\n\nMîzan: Sorunun tamamına değil, bugün açabileceğin küçük kapıya odaklan.";
            case "Üstünlük ölçüsü takvadır":
                return "Hucurât 49/13, insan farklılıklarını üstünlük yarışına değil tanışmaya bağlar. Soy, servet ve makam Allah katında değer ölçüsü değildir; ölçü takva yani sorumluluk bilincidir.\n\nMîzan: Konumu ne olursa olsun bugün bir insanı dikkatle dinle.";
            case "Gevşemeyin, üzülmeyin":
                return "Âl-i İmrân bağlamında bu hitap, Uhud sonrası incinen topluluğa moral ve sorumluluk verir. Üzüntüyü yasaklamaktan çok, yenilginin insanı teslim almamasını öğretir.\n\nMîzan: Yaşadığın kayıptan çıkaracağın tek dersi yaz ve yeniden başla.";
            case "Çıkış yolu ve tevekkül":
                return "Talâk 65/2–3, takva sahibine çıkış yolu ve ummadığı yerden rızık vaadini bildirir. Tevekkül sebepleri bırakmak değil; sorumluluğu yerine getirip sonucu Allah’a havale etmektir.\n\nMîzan: Önce tedbir, ardından güven.";

            case "Niyet davranışın yönüdür":
                return "Hadis, aynı görünen davranışların niyetle farklı değer kazanabileceğini öğretir. Güzel niyet yanlış yöntemi helâl yapmaz; doğru işi Allah rızası ve dürüst maksatla yapmak gerekir.\n\nUygulama: Başlayacağın işte ‘Bunu niçin yapıyorum?’ diye sor.";
            case "Kardeşin için de iste":
                return "İman olgunluğu bencilliğin sınırını aşar. Kişi kendisi için istediği hayrı kardeşi için de ister; fakat bu, kendi hakkını yok saymak değil adalet ve empati kurmaktır.\n\nUygulama: Bugün birinin başarısını içtenlikle destekle.";
            case "Ya hayır söyle ya sus":
                return "Hadis, dili iman ve ahiret sorumluluğuyla ilişkilendirir. Doğru olan her söz her yerde söylenmez; sözün yararı, zamanı ve üslubu da hesaba katılır.\n\nUygulama: Söylemeden önce doğru mu, gerekli mi, incitici mi diye düşün.";
            case "Öfke anındaki gerçek güç":
                return "Gerçek güç karşısındakini bastırmak değil, öfke yükseldiğinde iradeyi koruyabilmektir. Bu, haksızlığa sessiz kalmak değil; hakkı kontrolsüz zarar vermeden savunmaktır.\n\nUygulama: İlk tepkiyi vermeden önce kısa bir durak koy.";
            case "Temizlik ve iman":
                return "Sahih Müslim’de temizlik imanın yarısı olarak anılır. Ölçü yalnız beden temizliği değil; ibadete hazırlık, çevre düzeni ve başkasına zarar vermeyen yaşayıştır.\n\nUygulama: Bugün ortak kullandığın bir alanı temiz bırak.";
            case "Merhamet etmeyene merhamet edilmez":
                return "Merhamet yalnız acımak değil; gücü yettiğince korumak, kolaylaştırmak ve incitmemektir. Hadis, insanlara karşı katılığı manevî bir eksiklik olarak gösterir.\n\nUygulama: Zorlanan birine küçük fakat gerçek bir kolaylık sağla.";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Kur’an’ı öğrenmek yalnız okumayı değil, anlamı ve doğru uygulamayı da içerir. Öğretmek ise gösteriş değil, faydayı güvenilir biçimde aktarma sorumluluğudur.\n\nUygulama: Bugün bir ayetin anlamını güvenilir kaynaktan öğren.";

            case "Mûsâ ve Bilge Kul":
                return "Mûsâ peygamber Allah’ın özel bilgi verdiği kul ile yolculuğa çıkar. Kul gemiyi kusurlu hâle getirir, bir çocuğun ölümüyle sonuçlanan olay yaşanır ve ücret istemeden bir duvarı onarır. Mûsâ her olayda itiraz eder. Yolculuk sonunda geminin zorba hükümdardan korunması, çocuğun ailesi için ağır bir imtihan oluşu ve duvarın altındaki yetim hazinesinin korunması açıklanır.\n\nDers: Görünene bakarak acele hüküm verme; insan bilgisinin sınırını kabul et.";
            case "Yûsuf’un sabır yolculuğu":
                return "Yûsuf kardeşlerinin kıskançlığıyla kuyuya atılır, köle olarak satılır ve iftirayla hapse girer. Rüyaları yorumlamasıyla masumiyeti anlaşılır; ülkenin hazinelerinde sorumluluk üstlenir. Kıtlık yıllarında kardeşleri karşısına geldiğinde intikam yerine bağışlamayı seçer ve ailesi yeniden birleşir.\n\nDers: İffet, sabır ve bağışlama uzun imtihanlarda insanı ayakta tutar.";
            case "Ashâb-ı Kehf":
                return "İnançlarını korumak isteyen gençler baskıcı çevreden uzaklaşıp mağaraya sığınır ve Allah’tan rahmet ile doğru yol ister. Uzun süre uyutulup uyandırılmaları, ölümden sonra dirilişe bir işaret olur. Şehre gönderdikleri arkadaşları toplumun değiştiğini fark eder.\n\nDers: Zor zamanda doğru çevreyi, sığınağı ve inançta kararlılığı seç.";
            case "İbrâhim ve putlar":
                return "İbrâhim peygamber kavminin taptığı putların fayda ve zarar veremediğini sorgular. Putları kırıp büyüğünü bırakır; halk dönünce düşünmeleri için sözü büyük puta yöneltir. Gerçeği fark ettikleri hâlde gelenek baskısıyla İbrâhim’i ateşe atmaya karar verirler; Allah ateşe serin ve güvenli olmasını emreder.\n\nDers: Kör taklit yerine delil ve hakikat cesareti gerekir.";
            case "Yûnus’un duası":
                return "Yûnus peygamber kavminden ayrıldıktan sonra gemide yaşanan olayın ardından balık tarafından yutulur. Karanlıklar içinde Allah’ı tenzih eder, O’ndan başka ilâh olmadığını söyler ve kendi hatasını kabul eder. Allah duasına karşılık verir ve onu sıkıntıdan kurtarır.\n\nDers: Mazeret üretmek yerine hatayı kabul etmek, dua ve dönüş kapısını açar.";
            case "Tâlût ve Câlût":
                return "İsrâiloğulları peygamberlerinden savaş için hükümdar ister; Allah bilgi ve beden gücü verilen Tâlût’u seçer. Soy ve servet gerekçesiyle itiraz edenler olur. Ordu yola çıkınca nehirle sınanır; çoğunluk kana kana içer ve elenir. Az sayıdaki kararlı topluluk Câlût’un büyük ordusu karşısında sabır ve sebat duası eder. Savaşta genç Dâvûd Câlût’u öldürür; Allah ona daha sonra hükümdarlık ve hikmet verir.\n\nDers: Sayı kadar irade, disiplin, liyakat ve sebat önemlidir.";
            case "Süleyman ve karınca":
                return "Süleyman peygamber ordusuyla karıncaların bulunduğu vadiye gelir. Bir karınca diğerlerini, fark etmeden ezilmemeleri için yuvalarına çağırır. Süleyman bu uyarıyı anlayıp tebessüm eder ve kendisine verilen nimet için şükür duası eder.\n\nDers: Gerçek güç, en küçük canlının sesini duymaya ve şükretmeye engel değildir.";

            case "Sabah ve akşam tesbihi":
                return "Anlam: Allah’ı eksiklikten uzak bilir, O’na hamd ederim.\nVakit ve sayı: Sabah 100, akşam 100.\nDayanak: Sahih Müslim 2692.\nSınır: Sayı rivayetteki ölçüdür; zikir farzların veya kul hakkını gidermenin yerine geçmez.";
            case "Günlük tehlil":
                return "Anlam: Allah’tan başka ilâh yoktur; O tektir, ortağı yoktur. Mülk ve hamd O’nundur.\nVakit ve sayı: Gün içinde 100.\nDayanak: Buhârî 3293 ve Müslim 2691.\nSınır: Mekanik sonuç vaadi değil, tevhid bilincini canlı tutan zikirdir.";
            case "Mizanda ağır iki cümle":
                return "Anlam: Allah’ı hamdiyle ve yüceliğiyle noksanlıktan tenzih ederim.\nVakit ve sayı: Gün içinde okunabilir; kaynakta sabit günlük sayı yoktur.\nDayanak: Buhârî 6406 ve Müslim 2694.\nUygulama: Acele etmeden anlamını düşünerek oku.";
            case "Namaz sonrası istiğfar":
                return "Anlam: Namazdaki kusur için bağışlanma ister, esenliğin Allah’tan olduğunu kabul ederiz.\nVakit ve sayı: Farz namazdan sonra istiğfar 3, selâm duası 1.\nDayanak: Sahih Müslim 591.\nUygulama: Arapça aslı doğru telaffuzla öğrenilmeli.";
            case "Yatmadan önce Fâtıma tesbihi":
                return "Anlam: Allah’ı tenzih, nimet için hamd ve O’nun büyüklüğünü ikrar.\nVakit ve sayı: Yatarken 33 tesbih, 33 tahmid, 34 tekbir.\nDayanak: Buhârî 6318 ve Müslim 2727.\nUygulama: Yorgunluk içinde kalbi Allah’a yöneltir.";
            case "Havkale":
                return "Anlam: Güç ve kuvvet ancak Allah’ın yardımıyladır.\nVakit ve sayı: Gün içinde; kaynakta sabit sayı yoktur.\nDayanak: Sahih Buhârî 6384.\nSınır: Sorumluluktan kaçış veya tedbiri bırakma sözü değildir.";
            case "Yûnus peygamberin duası":
                return "Anlam: Senden başka ilâh yoktur; Seni tenzih ederim, ben yanlış yapanlardan oldum.\nVakit ve sayı: Darlık ve tövbe anında; ayette sabit sayı yoktur.\nDayanak: Enbiyâ 21/87.\nUygulama: Tevhid, tenzih ve hatayı kabulü birleştirir.";
            case "İlmin artması duası":
                return "Anlam: Rabbim, ilmimi artır.\nVakit ve sayı: Öğrenmeden önce veya gün içinde; sabit sayı yoktur.\nDayanak: Tâhâ 20/114.\nSınır: Dua öğrenme emeğinin yerine geçmez; gayreti doğru niyetle destekler.";
            case "Dünya ve âhiret iyiliği":
                return "Anlam: Rabbimiz, dünyada ve âhirette iyilik ver; bizi ateş azabından koru.\nVakit ve sayı: Gün içinde; ayette sabit sayı yoktur.\nDayanak: Bakara 2/201.\nUygulama: Dünya ile âhireti koparmayan dengeli iyilik talebidir.";
            default:
                return body + "\n\nKaynağı gösterilen bu kayıt kısa özet değil, düşünme ve uygulama ölçüsü olarak okunmalıdır.";
        }
    }

    private static String secondDetailFor(String type, String title) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "Sabır, doğru davranışta süreklilik; namaz ise yönü ve niyeti yeniden kurmaktır. Ayet, iç dayanıklılıkla fiilî sorumluluğu birbirinden ayırmaz.";
            case "Kalbin asıl huzuru":
                return "Zikir yalnız dilin tekrarı değil, Allah’ı, vahyi ve kulluk sorumluluğunu hatırda tutmaktır. Huzur duyguların silinmesi değil, insanın doğru dayanakla dağılmadan yol almasıdır.";
            case "Rahmetten ümit kesme":
                return "Rahmet ümidi; pişmanlık, yanlışı bırakma ve mümkünse bozulan hakkı onarma iradesiyle tamamlanır. Ayet günahı hafife almayı değil, dönüş kapısını kapatmamayı öğretir.";
            case "Güçlükle beraber kolaylık":
                return "Kolaylığın güçlüğün yanında bulunduğu iki kez vurgulanır. Bu, her sıkıntının hemen istenen biçimde biteceği değil; yardım, emek ve yeni imkânların aranacağı anlamına gelir.";
            case "Üstünlük ölçüsü takvadır":
                return "Farklılıklar tanışma ve iş birliği vesilesidir. Takva kişinin kendi üstünlüğünü ilan edeceği bir rozet değil, Allah’a karşı sorumluluğunu davranışlarında taşımasıdır.";
            case "Gevşemeyin, üzülmeyin":
                return "Uhud bağlamı moral verirken hataların sebeplerini de düşündürür. İman yenilgiyi inkâr etmek değil; ders çıkarıp sabır, itaat ve sorumlulukla yeniden ayağa kalkmaktır.";
            case "Çıkış yolu ve tevekkül":
                return "Ayet, Talâk sûresindeki hukuk ve sınırları gözetme bağlamında gelir. Çıkış ve rızık vaadi sebepleri bırakmaya değil, baskı altında da doğru davranıştan vazgeçmemeye dayanır.";

            case "Niyet davranışın yönüdür":
                return "Niyet amelin yönünü belirler; fakat yanlış yöntemi doğruya çevirmez ve başkasının hakkını ortadan kaldırmaz. Doğru iş, doğru maksat ve doğru usul birlikte aranır.";
            case "Kardeşin için de iste":
                return "Hadis kıskançlık ve bencilliği aşan bir iman olgunluğu kurar. Kardeşin için hayır istemek, kendi hakkını yok saymak değil; adalet içinde onun iyiliğine de gönülden razı olmaktır.";
            case "Ya hayır söyle ya sus":
                return "Hayır söz; doğru, yararlı, yerinde ve uygun üslupla söylenen sözdür. Susmak, gerekli hakikatten kaçmak değil; zarar veren, boş veya ölçüsüz sözü durdurabilmektir.";
            case "Öfke anındaki gerçek güç":
                return "Öfkeye hâkim olmak haksızlığı görmezden gelmek veya duyguyu içine gömmek değildir. Sükûnet kazandıktan sonra meseleyi adaletle ele almak, tepkiyi iradenin yönetmesidir.";
            case "Temizlik ve iman":
                return "Hadiste temizlik ibadet bilinciyle ilişkilendirilir. Beden, elbise ve ibadete hazırlıkta başlayan bu ölçü, gündelik hayatta çevreyi kirletmeme ve başkasına eziyet vermeme sorumluluğu doğurur.";
            case "Merhamet etmeyene merhamet edilmez":
                return "Merhamet zayıflık veya sınırsız taviz değildir. Adaleti korurken zulmetmemek; aileye, güçsüze, canlılara ve sorumluluğumuz altındakilere şefkatle davranmaktır.";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Öğrenme; doğru okuyuş, anlam, düşünme ve uygulamayı birlikte geliştirir. Öğretmek ise yalnız bildiğini, güvenilir kaynağa dayanarak ve muhatabın seviyesini gözeterek aktarmaktır.";

            case "Mûsâ ve Bilge Kul":
                return "Yolculuğun sonunda üç olayın görünmeyen yönü açıklanır. Bu özel bilgi, insanların ‘gizli hikmet’ iddiasıyla açık ölçüleri çiğnemesine izin vermez; normal hüküm vahiy ve görünen delile dayanır.";
            case "Yûsuf’un sabır yolculuğu":
                return "Yûsuf hapisten çıkmadan önce iftiranın aydınlatılmasını ister, ardından kıtlık için yıllara yayılan bir üretim ve saklama planı kurar. Kıssa sabrın pasif bekleyiş değil, iffetli ve tedbirli duruş olduğunu gösterir.";
            case "Ashâb-ı Kehf":
                return "Gençlerin uyanışı dirilişin mümkün olduğuna işaret olur. Kur’an onların sayısı gibi faydasız tartışmalara kapılmamayı, kesin bilgisi Allah’a ait ayrıntılar yerine kıssanın iman mesajına yönelmeyi öğretir.";
            case "İbrâhim ve putlar":
                return "İbrâhim’in soruları putların acizliğini ortaya çıkarır; kavmi gerçeği fark ettiği hâlde gelenek ve otorite baskısına döner. Ateşin zarar vermemesi, yardımın Allah’ın hükmünde olduğunu gösterir.";
            case "Yûnus’un duası":
                return "Dua tevhid, Allah’ı eksiklikten tenzih ve kişinin kendi kusurunu kabulünü birleştirir. Enbiyâ 21/88, Allah’ın onu kurtardığını ve iman edenleri de böyle kurtardığını bildirir.";
            case "Tâlût ve Câlût":
                return "Seçimde soy ve servet yerine bilgi ile yeterlilik öne çıkar; nehir sınavı ordunun disiplinini açığa çıkarır. Kararlı azınlığın duası, tedbir ile Allah’tan yardım istemeyi birleştirir.";
            case "Süleyman ve karınca":
                return "Kıssanın dönüm noktası, büyük bir hükümdarın küçük bir canlının uyarısını fark etmesidir. Süleyman gücünü övünmeye değil şükre bağlar; nimetin sorumluluk doğurduğunu gösterir.";

            case "Sabah ve akşam tesbihi":
                return "Sahih Müslim 2692’de sabah ve akşam yüz defa zikredilir. Rivayetteki sayı korunur; fakat zikir farz ibadetlerin, tövbenin veya kul hakkını gidermenin yerine geçirilmez.";
            case "Günlük tehlil":
                return "Buhârî 3293 ve Müslim 2691’de tam tehlil cümlesinin gün içinde yüz defa söylenmesi aktarılır. Ölçü, tevhidi bilinçle canlı tutmaktır; zikir mekanik bir dünya sonucu vaadi değildir.";
            case "Mizanda ağır iki cümle":
                return "Buhârî 6406 ve Müslim 2694 bu iki cümlenin dile hafif, mizanda ağır ve Rahmân’a sevimli olduğunu bildirir. Rivayette bu zikir için sabit günlük tekrar sayısı verilmez.";
            case "Namaz sonrası istiğfar":
                return "Sahih Müslim 591’de farz namazın ardından üç defa istiğfar ve sonra selâm duası aktarılır. Sayı kaynağın ölçüsüdür; amaç namazdaki eksikliği fark ederek Allah’a yönelmektir.";
            case "Yatmadan önce Fâtıma tesbihi":
                return "Buhârî 6318 ve Müslim 2727’de yatarken 33 tesbih, 33 tahmid ve 34 tekbir öğretilir. Zikir yorgunluk anında nimeti, kulluğu ve gerçek güç kaynağını hatırlatır.";
            case "Havkale":
                return "Sahih Buhârî 6384’te havkale cennet hazinelerinden bir hazine olarak anılır. Kaynakta sabit günlük sayı yoktur; ifade insan iradesini iptal etmez, gücü Allah’tan bağımsız görmeyi reddeder.";
            case "Yûnus peygamberin duası":
                return "Enbiyâ 21/87–88’de dua Yûnus peygamberin sıkıntı içindeki yönelişidir. Ayette sabit tekrar sayısı yoktur; tevhid, tenzih ve kusuru kabul bir arada tutulur.";
            case "İlmin artması duası":
                return "Tâhâ 20/114’te Hz. Peygamber’e ‘Rabbim, ilmimi artır’ demesi öğretilir. Ayette sabit sayı veya özel gün verilmez; dua öğrenme, araştırma ve doğru kaynağa başvurma çabasını destekler.";
            case "Dünya ve âhiret iyiliği":
                return "Bakara 2/201 dünya ile âhiret iyiliğini aynı duada toplar. Ayette sabit sayı veya özel gün yoktur; istenen iyilik yalnız maddî rahatlık değil, bütünüyle hayırlı ve dengeli bir hayattır.";
            default:
                return type.contains("kıssa") ? "Kıssanın olay akışı, dönüm noktası ve Kur’an’ın öne çıkardığı ana ders birlikte okunmalıdır." :
                    "Kaynağın verdiği ölçü, bağlamından koparılmadan ve diğer dinî sorumlulukların yerine geçirilmeden anlaşılmalıdır.";
        }
    }

    private static String guidanceFor(String type, String title) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "Meseleyi üçe ayır: yapacağın iş, sabredeceğin kısım, Allah’a bırakacağın sonuç. Bugün atacağın ilk doğru adım hangisi?";
            case "Kalbin asıl huzuru":
                return "Tedbirini yaz; sonra kontrol edemediğin kısmı dua ve zikirle Allah’a bırak. Şu an zihnini taşıyamayacağı bir yükle mi meşgul ediyorsun?";
            case "Rahmetten ümit kesme":
                return "Bir kusur seç: bırak, telafi et ve gerekiyorsa hakkı sahibine döndür. Ümidin bugün hangi gerçek dönüş hareketine dönüşecek?";
            case "Güçlükle beraber kolaylık":
                return "Zorluğun içindeki üç imkânı ara: yardım, zaman, beceri veya başka yol. Bugün bunlardan hangisini kullanabilirsin?";
            case "Üstünlük ölçüsü takvadır":
                return "Konumuna bakarak farkında olmadan küçümsediğin biri var mı? Bugün onu gerçekten dinleyerek hangi önyargını kırabilirsin?";
            case "Gevşemeyin, üzülmeyin":
                return "Kaybın duygusunu inkâr etme; ardından tek ders ve tek yeni adım yaz. Yeniden ayağa kalkmak bugün hangi küçük davranışla başlayacak?";
            case "Çıkış yolu ve tevekkül":
                return "Önce yerine getirmen gereken sorumluluğu tamamla, sonra sonucu zorla kontrol etmeyi bırak. Tedbirinin eksik kalan tarafı nedir?";

            case "Niyet davranışın yönüdür":
                return "Bugünkü önemli işinden önce ‘Neden, kimin hakkını gözeterek ve hangi doğru yolla yapıyorum?’ diye sor. Niyetinde insan övgüsünün payı var mı?";
            case "Kardeşin için de iste":
                return "Birinin başarısını küçültmeden takdir et ve ihtiyaç duyduğu gerçek bir desteği ver. Başkasının hayrı sende huzursuzluk doğuruyor mu?";
            case "Ya hayır söyle ya sus":
                return "Sözden önce üç süzgeç kullan: doğru mu, gerekli mi, üslubu güzel mi? Bugün susman veya daha iyi söylemen gereken cümle hangisi?";
            case "Öfke anındaki gerçek güç":
                return "Öfke yükseldiğinde cevabı ertele, bedenini sakinleştir, sonra hakkı ölçülü biçimde dile getir. İlk tepkin çözüm mü, zarar mı üretecek?";
            case "Temizlik ve iman":
                return "Bugün bedenin, ibadet alanın veya ortak kullandığın yerlerden birini özenle temizle. Arkanda kolaylık mı, yük mü bırakıyorsun?";
            case "Merhamet etmeyene merhamet edilmez":
                return "Gücünün yettiği bir kişiye ya da canlıya gerçek bir kolaylık sağla. Haklı olsan bile üslubunda merhameti kaybettiğin yer neresi?";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Bir ayeti Arapçası, meali ve güvenilir tefsir notuyla öğren; sonra yalnız emin olduğun kısmı paylaş. Bilgin davranışına ne kattı?";

            case "Mûsâ ve Bilge Kul":
                return "Hakkında eksik bilgiye sahip olduğun bir meselede hükmünü yavaşlat. Bilmediğini kabul etmek mi, hemen açıklama üretmek mi sana daha zor geliyor?";
            case "Yûsuf’un sabır yolculuğu":
                return "Uzun süren imtihanında koruman gereken ilkeyi ve alacağın tedbiri ayır. Sabır adı altında ertelediğin somut sorumluluk var mı?";
            case "Ashâb-ı Kehf":
                return "İnancını ve ahlâkını zayıflatan çevreyi fark et; sana güç verecek doğru arkadaşlığı seç. Bugün sığınman gereken güvenli alışkanlık nedir?";
            case "İbrâhim ve putlar":
                return "Sırf herkes öyle yapıyor diye sürdürdüğün bir alışkanlığı delille sorgula. Gerçeği gördüğünde gelenek baskısına rağmen tavrını değiştirebilir misin?";
            case "Yûnus’un duası":
                return "Mazeret kurmadan payına düşen hatayı adlandır; ardından dua edip düzeltme adımını belirle. Kabul etmekten kaçtığın sorumluluk hangisi?";
            case "Tâlût ve Câlût":
                return "Büyük görünen hedefini disiplin sınavlarına böl. Bugün seni sonuca götürecek sayı üstünlüğü değil, hangi küçük fakat kararlı davranış?";
            case "Süleyman ve karınca":
                return "Kararından etkilenecek en güçsüz kişiyi veya canlıyı düşün. Sahip olduğun güç, sesini daha çok mu duyuruyor yoksa başkasını daha iyi mi duymanı sağlıyor?";

            case "Sabah ve akşam tesbihi":
                return "Yüz tekrarı acele yarışına çevirmeden, hamd ettiğin bir nimeti düşünerek oku. Dilin söylediğini kalbin hangi nimetle doğrulayacak?";
            case "Günlük tehlil":
                return "Tam tehlil cümlesini yüz defa, mülkün ve hamdin Allah’a ait olduğunu düşünerek oku. Bugün mutlaklaştırdığın güç veya kaygı nedir?";
            case "Mizanda ağır iki cümle":
                return "Sabit sayı eklemeden, anlamını koruyarak ve acele etmeden oku. Allah’ı tenzih ederken hangi nimeti için hamd ediyorsun?";
            case "Namaz sonrası istiğfar":
                return "Farz namazdan sonra üç istiğfarı ve selâm duasını bilinçle tamamla. Namazındaki hangi dağınıklık için bağışlanma ve düzeltme istiyorsun?";
            case "Yatmadan önce Fâtıma tesbihi":
                return "Uyumadan önce 33 tesbih, 33 tahmid ve 34 tekbiri anlamını düşünerek oku. Günün yorgunluğunu hangi şükürle teslim edeceksin?";
            case "Havkale":
                return "Gücünün sınırlı kaldığı yerde havkaleyi söyle; ardından yapabileceğin tedbiri yine yerine getir. Yardım istemekle sorumluluktan kaçmayı ayırabiliyor musun?";
            case "Yûnus peygamberin duası":
                return "Sıkıntında tevhid, tenzih ve hatayı kabulü birlikte tutarak oku; kaynağın vermediği bir sayı ekleme. Düzeltmen gereken payın nedir?";
            case "İlmin artması duası":
                return "Duayı okuduktan sonra bugün öğrenmek istediğin konuda güvenilir bir sayfa çalış. İlmin artması için hangi emeği koyacaksın?";
            case "Dünya ve âhiret iyiliği":
                return "Duayı okurken dünya ve âhiret dengesini bozan bir isteğini gözden geçir. Talep ettiğin iyilik seni daha sorumlu ve faydalı kılıyor mu?";
            default:
                return "Kaynağı oku, ana ölçüyü kendi durumuna uygula ve bugün değiştireceğin tek davranışı belirle.";
        }
    }

    private static String relatedFor(String type, String title) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "İnşirâh 94/5–6 güçlükle beraber kolaylığı hatırlatır. Sabır; zulme razı olmak, tedbiri bırakmak veya hiç üzülmemek değildir; doğru çizgide dayanarak gerekeni yapmaktır.";
            case "Kalbin asıl huzuru":
                return "Yûnus’un duası (Enbiyâ 21/87) zikirle dürüst öz eleştiriyi birleştirir. Huzur aramak, problemi inkâr etmek veya sorumluluktan kaçmak anlamına gelmez.";
            case "Rahmetten ümit kesme":
                return "Enbiyâ 21/87–88, hatayı kabul eden yönelişin bir örneğidir. Rahmet ümidi, kul hakkını kendiliğinden düşürmez ve bile bile aynı yanlışta ısrar izni vermez.";
            case "Güçlükle beraber kolaylık":
                return "Bakara 2/153 sabır ve namazla yardım dilemeyi öğretir. Kolaylık vaadi, emeksiz sonuç veya her isteğin hemen gerçekleşeceği şeklinde yorumlanmamalıdır.";
            case "Üstünlük ölçüsü takvadır":
                return "‘Kardeşin için de iste’ hadisi (Buhârî 13; Müslim 45) bu ölçüyü ilişkilere taşır. Takva başkalarının kalbini yargılama veya kendini üstün ilan etme aracı değildir.";
            case "Gevşemeyin, üzülmeyin":
                return "Tâlût kıssasındaki sabır ve sebat duası (Bakara 2/250) aynı diriliş ölçüsünü gösterir. Ayet üzüntüyü bastırmayı veya müminin dünyada daima galip olacağını söylemez.";
            case "Çıkış yolu ve tevekkül":
                return "Bakara 2/153, güveni sabır ve namazla destekler. Tevekkül planı, emeği, istişareyi ve hukuka riayeti bırakıp sonucu beklemek değildir.";

            case "Niyet davranışın yönüdür":
                return "Talâk 65/2–3 niyetin yanında takva, sınır ve sorumluluğu da öne çıkarır. İyi niyet haramı helâl yapmaz; zarar verilen kişinin hakkını da ortadan kaldırmaz.";
            case "Kardeşin için de iste":
                return "Hucurât 49/13 insan değerini soy ve makamdan ayırır. Hadis, kişinin kendini değersizleştirmesini veya haksızlığa boyun eğmesini değil, bencilliği aşmasını ister.";
            case "Ya hayır söyle ya sus":
                return "Hucurât 49/13 insan onurunu koruyan ilişki ölçüsü verir. Susma emri, doğru şahitliği gizlemek veya haksızlık karşısında sorumluluktan kaçmak için kullanılamaz.";
            case "Öfke anındaki gerçek güç":
                return "Tâlût kıssasında disiplin, baskı anında iradeyi korumaktır. Öfkeyi yönetmek haksızlığı onaylamak değil, hakkı zarar üretmeden ve adaletle savunmaktır.";
            case "Temizlik ve iman":
                return "Bakara 2/153 namazı manevî dayanıklılıkla ilişkilendirir; temizlik de ibadete hazırlığın parçasıdır. Dış görünüşe bakarak insanların imanını ölçmek hadisin amacı değildir.";
            case "Merhamet etmeyene merhamet edilmez":
                return "Hucurât 49/13 her insanın onurunu hatırlatır. Merhamet, zararlı davranışa sınırsız izin vermek veya adaletli sınır koymaktan vazgeçmek değildir.";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Tâhâ 20/114 ilmin artması için dua etmeyi öğretir. Birkaç bilgi öğrenmekle uzmanlık iddiasında bulunmak veya doğrulamadan din adına konuşmak bu ölçüye aykırıdır.";

            case "Mûsâ ve Bilge Kul":
                return "Kur’an gemi, çocuk ve duvar olaylarının açıklamasını metinde verir; sonradan eklenen efsanelere ihtiyaç yoktur. Kıssa, ‘gizli bilgi’ iddiasıyla açık dinî ve ahlâkî ölçüleri çiğnemeye dayanak yapılamaz.";
            case "Yûsuf’un sabır yolculuğu":
                return "Yûsuf sûresi kıssayı kuyu, iffet sınavı, hapis, planlama ve bağışlama çizgisinde anlatır. Sabır, yanlışın sürmesine sessiz kalmak değil; temiz kalırken çıkış için çalışmaktır.";
            case "Ashâb-ı Kehf":
                return "Kehf 18/22 ve 18/25–26, sayı ve süre tartışmalarında kesin bilginin Allah’a ait olduğunu hatırlatır. Kur’an’ın vermediği isim ve ayrıntıları dinin kesin bilgisi gibi sunmamak gerekir.";
            case "İbrâhim ve putlar":
                return "Enbiyâ 21/51–70 tartışmanın merkezine putların acizliğini ve aklî çelişkiyi koyar. Kıssa, insanlara hakaret etmeyi değil, kör taklidi delille sorgulamayı öğretir.";
            case "Yûnus’un duası":
                return "Enbiyâ 21/87–88 duanın sözünü ve kurtuluş mesajını verir; sabit tekrar sayısı bildirmez. Kıssa, görevi terk etmeyi meşrulaştırmaz; hatayı kabul edip yeniden yönelmeyi öğretir.";
            case "Tâlût ve Câlût":
                return "Bakara 2/246–251 liderlik, nehir sınavı, dua ve Dâvûd’un zaferini anlatır. Kur’an’ın vermediği ordu sayıları veya savaş ayrıntıları kesin bilgi gibi eklenmemelidir.";
            case "Süleyman ve karınca":
                return "Neml 27/15–19 ilim, düzenli ordu, karıncanın uyarısı ve şükür duasını birlikte verir. Kıssa gücü yüceltmek için değil, gücün merhamet ve şükürle taşınmasını öğretmek için okunmalıdır.";

            case "Sabah ve akşam tesbihi":
                return "Sahih Müslim 2692’de sabah ve akşam yüz tekrar sabittir. Bu zikir farz ibadetlerin, tövbenin, borcun veya kul hakkını gidermenin yerine geçmez; garantili dünyevî sonuç vaadi değildir.";
            case "Günlük tehlil":
                return "Buhârî 3293 ve Müslim 2691’de tam cümle ve yüz tekrar birlikte aktarılır. Metni eksiltip aynı rivayet sevabını kesinleştirmek veya zikri mekanik kazanç formülü yapmak doğru değildir.";
            case "Mizanda ağır iki cümle":
                return "Buhârî 6406 ve Müslim 2694 fazileti bildirir; sabit günlük sayı vermez. Kaynakta olmayan sayı, gün veya sonuç zikir adına dinî zorunluluk gibi eklenmemelidir.";
            case "Namaz sonrası istiğfar":
                return "Sahih Müslim 591’de farz namazdan sonra istiğfar üç, selâm duası bir defadır. Bu uygulama namazın yerine değil, namazdan sonraki eksiklik bilincine aittir.";
            case "Yatmadan önce Fâtıma tesbihi":
                return "Buhârî 6318 ve Müslim 2727 ölçüyü 33 tesbih, 33 tahmid ve 34 tekbir olarak verir. Sayılar korunur; fakat zikir her türlü yorgunluğu kesin gideren bir tedavi vaadi değildir.";
            case "Havkale":
                return "Sahih Buhârî 6384 havkaleyi cennet hazinelerinden bir hazine olarak bildirir; sabit günlük sayı vermez. Söz, tedbiri bırakmak veya kendi görevini Allah’a havale etmek anlamına gelmez.";
            case "Yûnus peygamberin duası":
                return "Enbiyâ 21/87–88 duanın aslını verir; ayette sabit sayı ve özel gün yoktur. Kaynakta olmayan sayı veya kesin sonuç iddiası eklenmeden okunmalıdır.";
            case "İlmin artması duası":
                return "Tâhâ 20/114 duanın metnini verir; sabit sayı ve özel vakit belirlemez. Dua, okuma, araştırma, ehline sorma ve öğrendiğini uygulama emeğinin yerine geçmez.";
            case "Dünya ve âhiret iyiliği":
                return "Bakara 2/201 dua metnini verir; sabit sayı veya özel gün bildirmez. ‘Dünya iyiliği’ yalnız servete indirgenmemeli; helâl, sağlık, huzur, fayda ve sorumluluk dengesinde anlaşılmalıdır.";
            default:
                return isZikirType(type) ? "Kaynakta sabit sayı yoksa sayı eklenmez ve zikir garantili sonuç formülü gibi sunulmaz." :
                    "Metin, kaynağın verdiği sınırlar içinde ve diğer sorumluluklarla birlikte okunmalıdır.";
        }
    }

    private static String closingFor(String type, String title) {
        switch (title) {
            case "Sabır ve namazla yardım":
                return "Örnek: Ertelediğin tek işi bitir, ardından iki rekât veya farz namaz sonrası dua et. Dua: Allah’ım, doğru adımda sabır ve yardım ver.";
            case "Kalbin asıl huzuru":
                return "Örnek: Kaygını yaz, çözebileceğin parçayı bugün yap. Dua: Allah’ım, kalbimi zikrinle sakinleştir ve sorumluluğumu güzelce taşımayı nasip et.";
            case "Rahmetten ümit kesme":
                return "Örnek: Tek bir yanlışı bırakıp telafi planını bugün başlat. Dua: Allah’ım, rahmetinden ümit kesmeden samimi dönüş ve düzeltme gücü ver.";
            case "Güçlükle beraber kolaylık":
                return "Örnek: Sorun için yardım isteyebileceğin bir kişiyi ara. Dua: Allah’ım, güçlük içindeki kolaylık kapılarını görmeyi ve çalışmayı nasip et.";
            case "Üstünlük ölçüsü takvadır":
                return "Örnek: Görevi veya yaşı ne olursa olsun birini sözünü kesmeden dinle. Dua: Allah’ım, kalbimi kibirden koru ve insanlara adaletle davranmayı nasip et.";
            case "Gevşemeyin, üzülmeyin":
                return "Örnek: Kaybından öğrendiğin dersi yazıp yarın için tek hazırlık yap. Dua: Allah’ım, ümitsizliğe düşmeden hatamı görüp yeniden doğrulmayı nasip et.";
            case "Çıkış yolu ve tevekkül":
                return "Örnek: Kararından önce bilgiyi topla ve ehline danış. Dua: Allah’ım, tedbirimi doğru almayı ve sonucu Sana güvenle bırakmayı nasip et.";

            case "Niyet davranışın yönüdür":
                return "Örnek: İşe başlamadan niyetini tek cümleyle yaz ve yöntemin helâl olduğunu kontrol et. Dua: Allah’ım, niyetimi temiz, işimi doğru ve faydalı kıl.";
            case "Kardeşin için de iste":
                return "Örnek: Birinin başarısını açıkça takdir et ve küçük bir destek ver. Dua: Allah’ım, kalbimi hasetten arındır; kardeşimin hayrına sevinmeyi nasip et.";
            case "Ya hayır söyle ya sus":
                return "Örnek: Göndereceğin sert mesajı on dakika bekletip yeniden oku. Dua: Allah’ım, dilimi doğru, faydalı ve incitmeyen sözle koru.";
            case "Öfke anındaki gerçek güç":
                return "Örnek: Tartışmada sesini yükseltmeden önce ortamdan kısa süre ayrıl. Dua: Allah’ım, öfkemi adaletle yönetmeyi ve hakkı güzel söylemeyi nasip et.";
            case "Temizlik ve iman":
                return "Örnek: Ortak kullandığın bir alanı senden sonrakine daha temiz bırak. Dua: Allah’ım, bedenimi, çevremi ve kalbimi temiz tutmayı nasip et.";
            case "Merhamet etmeyene merhamet edilmez":
                return "Örnek: Zorlanan birinin yükünü bugün somut biçimde hafiflet. Dua: Allah’ım, gücümü incitmek için değil, korumak ve kolaylaştırmak için kullanmayı nasip et.";
            case "Kur’an’ı öğrenmek ve öğretmek":
                return "Örnek: Bir ayeti meal ve tefsiriyle çalışıp güvenilir künyesini not et. Dua: Rabbim ilmimi artır, öğrendiğimle amel etmeyi ve doğru aktarmayı nasip et.";

            case "Mûsâ ve Bilge Kul":
                return "Bugüne taşı: Eksik bildiğin konuda hükmü ertele ve bilen birine sor. Dua: Allah’ım, bilmediğimi kabul edecek tevazu ve doğru bilgiyi arayacak sabır ver.";
            case "Yûsuf’un sabır yolculuğu":
                return "Bugüne taşı: Zor dönemin için bir haftalık somut tedbir planı yap. Dua: Allah’ım, imtihanda iffeti, sabrı, tedbiri ve bağışlamayı korumayı nasip et.";
            case "Ashâb-ı Kehf":
                return "Bugüne taşı: Seni zayıflatan bir ortamı azalt, iyi bir arkadaşla bağını güçlendir. Dua: Rabbimiz, katından rahmet ver ve işimizde doğruyu kolaylaştır.";
            case "İbrâhim ve putlar":
                return "Bugüne taşı: Delilsiz sürdürdüğün bir alışkanlığın kaynağını araştır. Dua: Allah’ım, hakikati görmeyi ve gelenek baskısına rağmen doğruya uymayı nasip et.";
            case "Yûnus’un duası":
                return "Bugüne taşı: Hatanın sana düşen payını söyleyip telafiye başla. Dua: Senden başka ilâh yoktur; Seni tenzih ederim, ben yanlış yapanlardan oldum.";
            case "Tâlût ve Câlût":
                return "Bugüne taşı: Büyük hedef için bugün tek disiplin kuralı belirle ve bozma. Dua: Rabbimiz, üzerimize sabır yağdır, ayaklarımızı sağlam tut.";
            case "Süleyman ve karınca":
                return "Bugüne taşı: Kararından etkilenen en güçsüz kişiyi ayrıca dinle. Dua: Allah’ım, nimetlerine şükretmeyi ve gücümü iyilikte kullanmayı nasip et.";

            case "Sabah ve akşam tesbihi":
                return "Bugün: Sabah ve akşam yüz defa, anlamını düşünerek oku. Dua: Allah’ım, Seni hamdinle anmayı ve nimetlerine şükretmeyi nasip et.";
            case "Günlük tehlil":
                return "Bugün: Tam cümleyi yüz defa acele etmeden oku. Dua: Allah’ım, tevhidi kalbimde sağlamlaştır; mülkün ve hamdin Sana ait olduğunu unutturma.";
            case "Mizanda ağır iki cümle":
                return "Bugün: Kaynağın vermediği sayı eklemeden, hamd ettiğin nimeti düşünerek oku. Dua: Allah’ım, dilimi tesbih ve hamd ile diri tut.";
            case "Namaz sonrası istiğfar":
                return "Bugün: Her farzdan sonra üç istiğfar ve selâm duasını bilinçle tamamla. Dua: Allah’ım, ibadetimdeki kusuru bağışla ve beni esenliğe ulaştır.";
            case "Yatmadan önce Fâtıma tesbihi":
                return "Bugün: Yatarken 33 tesbih, 33 tahmid, 34 tekbir oku. Dua: Allah’ım, günün yorgunluğunu şükürle Sana teslim etmeyi nasip et.";
            case "Havkale":
                return "Bugün: Gücünün yetmediği anda söyle, ardından yapabileceğin tedbiri uygula. Dua: Allah’ım, yardımına güvenip sorumluluğumu güzelce yerine getirmeyi nasip et.";
            case "Yûnus peygamberin duası":
                return "Bugün: Sabit sayı koymadan, hatanı düşünerek ve ümitle oku. Dua: Allah’ım, kusurumu kabul edip Sana samimiyetle dönmeyi nasip et.";
            case "İlmin artması duası":
                return "Bugün: Duadan sonra güvenilir bir kaynaktan en az bir sayfa çalış. Dua: Rabbim ilmimi artır; doğru anlamayı ve faydalı kullanmayı nasip et.";
            case "Dünya ve âhiret iyiliği":
                return "Bugün: İsteklerini dünya ve âhiret dengesiyle gözden geçir. Dua: Rabbimiz, bize dünyada ve âhirette iyilik ver; bizi ateş azabından koru.";
            default:
                return "Bugün kaynağın ana ölçüsüne uygun tek davranış belirle. Allah’ım, doğruyu anlamayı ve güzelce uygulamayı nasip et.";
        }
    }

    static final Item[] ITEMS = new Item[] {
        ayet("Sabır ve namazla yardım", "Sabır, pasif bekleyiş değil; doğru tavrı koruyarak Allah’tan yardım istemektir.", "Kur’an · Bakara 2/153 · Diyanet kontrolü"),
        hadis("Niyet davranışın yönüdür", "Amellerin değeri niyetlere göredir. Doğru iş, gösterişten arındırılmış sağlam bir maksat ister.", "Sahih Buhârî 1"),
        kissa("Mûsâ ve Bilge Kul", "İlk bakışta anlaşılmayan olaylar, insan bilgisinin sınırlı olduğunu ve hükümden önce sabrı öğretir.", "Kehf 18/60–82"),
        zikir("Sabah ve akşam tesbihi", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "Sübhânallâhi ve bi-hamdihî.", "Allah’ı noksanlıktan tenzih eder, O’na hamd ederim. Ölçü: sabah 100, akşam 100.", "Sahih Müslim 2692"),

        ayet("Kalbin asıl huzuru", "Kalbin huzuru, her sıkıntının yok olması değil; dayanacağı doğru yönü bulmasıdır.", "Kur’an · Ra‘d 13/28 · Diyanet kontrolü"),
        hadis("Kardeşin için de iste", "İman olgunluğu, insanın kendisi için sevdiğini kardeşi için de sevmesiyle ilişkilidir.", "Buhârî 13 · Müslim 45"),
        kissa("Yûsuf’un sabır yolculuğu", "Kuyu, kölelik ve hapisle sınanan Yûsuf’un kıssası; iffet, sabır ve bağışlamanın uzun vadeli gücünü gösterir.", "Yûsuf 12/4–101"),
        zikir("Günlük tehlil", "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", "Lâ ilâhe illallâhu vahdehû lâ şerîke leh; lehü’l-mülkü ve lehü’l-hamdü ve hüve alâ külli şey’in kadîr.", "Kulluğun ve mutlak hükümranlığın Allah’a ait olduğunu hatırlatır. Ölçü: günde 100.", "Buhârî 3293 · Müslim 2691"),

        ayet("Rahmetten ümit kesme", "Kusuru küçümsemeden, Allah’ın rahmetinden ümit kesmemek; tövbe ve dönüş kapısını açık tutmaktır.", "Kur’an · Zümer 39/53 · Diyanet kontrolü"),
        hadis("Ya hayır söyle ya sus", "Sözün doğru olması tek başına yetmez; yararlı, ölçülü ve yerinde olması da gerekir.", "Buhârî 6018 · Müslim 47"),
        kissa("Ashâb-ı Kehf", "İnançlarını korumak isteyen gençlerin kararlılığı, zor zamanda doğru çevreyi ve güvenli sığınağı seçmeyi öğretir.", "Kehf 18/9–26"),
        zikir("Mizanda ağır iki cümle", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "Sübhânallâhi ve bi-hamdihî; sübhânallâhi’l-azîm.", "Dile hafif, mizanda ağır ve Rahmân’a sevimli iki cümle. Kaynakta sabit günlük sayı yoktur.", "Buhârî 6406 · Müslim 2694"),

        ayet("Güçlükle beraber kolaylık", "Ayet zorluğu inkâr etmez; güçlüğün içinde ve yanında açılan imkânı görmeye çağırır.", "Kur’an · İnşirâh 94/5–6 · Diyanet kontrolü"),
        hadis("Öfke anındaki gerçek güç", "Asıl güç başkasını yenmek değil, öfke yükseldiğinde insanın kendisine hâkim olabilmesidir.", "Buhârî 6114 · Müslim 2609"),
        kissa("İbrâhim ve putlar", "Körü körüne taklit yerine delil, düşünme ve hakikati arama cesareti öne çıkar.", "Enbiyâ 21/51–70"),
        zikir("Namaz sonrası istiğfar", "أَسْتَغْفِرُ اللَّهَ، اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ", "Estağfirullâh. Allâhümme ente’s-selâm ve minke’s-selâm.", "Farz namazdan sonra istiğfar 3 defa; ardından selâm duası 1 defa okunur.", "Sahih Müslim 591"),

        ayet("Üstünlük ölçüsü takvadır", "Soy, servet ve makam üstünlük sebebi değildir; farklılık tanışma vesilesi, değer ölçüsü sorumluluk bilincidir.", "Kur’an · Hucurât 49/13 · Diyanet kontrolü"),
        hadis("Temizlik ve iman", "Temizlik beden, ibadet ve çevre sorumluluğunu birlikte hatırlatan temel bir ölçüdür.", "Sahih Müslim 223"),
        kissa("Yûnus’un duası", "Yûnus peygamber sıkıntıda Allah’ı tenzih eder, hatasını kabul eder ve ümitle yönelir.", "Enbiyâ 21/87–88"),
        zikir("Yatmadan önce Fâtıma tesbihi", "سُبْحَانَ اللَّهِ، الْحَمْدُ لِلَّهِ، اللَّهُ أَكْبَرُ", "Sübhânallâh; elhamdülillâh; Allâhu ekber.", "Yatarken 33 tesbih, 33 tahmid ve 34 tekbir.", "Buhârî 6318 · Müslim 2727"),

        ayet("Gevşemeyin, üzülmeyin", "İman, zorluğu yok saymadan insanı yeniden ayağa kaldıran moral ve sorumluluk bilinci kazandırır.", "Kur’an · Âl-i İmrân 3/139 · Diyanet kontrolü"),
        hadis("Merhamet etmeyene merhamet edilmez", "Merhamet yalnız duygulanmak değil; gücü yettiğince koruyucu ve incitmeyen davranmaktır.", "Buhârî 6013 · Müslim 2319"),
        kissa("Tâlût ve Câlût", "Nehir imtihanı sayısal güçten önce irade ve disiplini sınar; kararlı azlığın gücünü gösterir.", "Bakara 2/246–251"),
        zikir("Havkale", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "Lâ havle ve lâ kuvvete illâ billâh.", "Güç ve kuvvet ancak Allah’ın yardımıyladır. Tedbiri bırakmak değil, gücü mutlaklaştırmamaktır.", "Sahih Buhârî 6384"),

        ayet("Çıkış yolu ve tevekkül", "Tevekkül tedbiri bırakmak değil; sorumluluğu yerine getirip sonucu Allah’a havale etmektir.", "Kur’an · Talâk 65/2–3 · Diyanet kontrolü"),
        hadis("Kur’an’ı öğrenmek ve öğretmek", "Hayırlı insanlardan olmak, ilmi yalnız biriktirmeyi değil; öğrenmeyi ve faydayla aktarmayı gerektirir.", "Sahih Buhârî 5027"),
        kissa("Süleyman ve karınca", "Büyük güç, en küçük canlının sesine kulak vermeye ve nimetin sahibine şükretmeye engel değildir.", "Neml 27/15–19"),
        zikir("Yûnus peygamberin duası", "لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ", "Lâ ilâhe illâ ente sübhâneke innî küntü mine’z-zâlimîn.", "Tevhid, tenzih ve hatayı kabul etmeyi tek duada buluşturur. Ayette sabit tekrar sayısı yoktur.", "Kur’an · Enbiyâ 21/87"),
        zikir("İlmin artması duası", "رَبِّ زِدْنِي عِلْمًا", "Rabbi zidnî ilmâ.", "Rabbim, ilmimi artır. Öğrenme gayretini dua ile birleştiren kısa Kur’an duasıdır.", "Kur’an · Tâhâ 20/114"),
        zikir("Dünya ve âhiret iyiliği", "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً", "Rabbenâ âtinâ fi’d-dünyâ haseneten ve fi’l-âhireti haseneten.", "Dünya ile âhireti birbirinden koparmayan dengeli bir iyilik talebidir.", "Kur’an · Bakara 2/201")
    };

    private DailyContent() { }
}
