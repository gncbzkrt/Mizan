# MÎZAN v4.1.0 — Kütüphane · Kütüb-i Sitte · Geniş Kaynak · Tam Günlük Sistem

Bu paket **Mizan-v4.0.3-HADIS-METNI-FIX** çalışan hattı ve **v4.0.4 GÜNLÜK ROTASYON FIX** üzerine hazırlanmıştır. Package name ve imza anahtarı değiştirilmemiştir. `versionCode=51`, `versionName=4.1.0`.

## Bu toplu sürümde

- v4.0.4 günlük tekrar engelleme korunur: Ayet / Hadis / Kıssa / Zikir geçmişi ayrı tutulur.
- Günün Ayeti artık yalnız 40 çekirdek kayda bağlı değildir. 40 özel tematik ayet korunur; çevrimiçi Kur’an metin istemcisi kullanılabildiğinde günlük seçim **6236 ayetin tamamından** yapılır. Önceki/sonraki ayet bağlamı aynı sûre içinde değerlendirilir.
- Kütüphane tarih kartları gerçek içerik arşividir. Günün AYET / HADİS / KISSA / ZİKİR / MÎZAN AI satırları yeniden açılabilir.
- Kütüphane araması günlük geçmişi, yerel/WEB_APPROVED kaynakları, doğrudan sûre/ayet başvurusunu, Kütüb-i Sitte arşivini ve dua arşivini birlikte tarar.
- Favoriler kalıcı SQLite tablosundadır. Günlük içerikler, Kütüb-i Sitte hadisleri ve dua/zikir arşivi favoriye alınabilir.
- Kütüb-i Sitte yerel veri katmanı build sırasında hazırlanır: Buhârî, Müslim, Ebû Dâvûd, Tirmizî, Nesâî, İbn Mâce. Modern İngilizce/Türkçe tercümeler APK'ya kopyalanmaz. Arapça asıl + künye + derece/metadata tutulur.
- Hisnü'l-Müslim arşivinden Arapça + Latin okunuş + kaynak alanları hazırlanır. Kaynakta olmayan sabit sayı/vakit/fazilet üretilmez.
- Hadislerde Türkçe erişim gerekiyorsa uygulama bunu **“AI destekli Türkçe anlam · kaynak tercümesi değildir”** etiketiyle ayırır. Kaynakta olmayan bir Türkçe metin “hadis metni” diye sunulmaz.
- Kıssa çekirdek havuzu 42 → **62** oldu. Yeni kayıtlar Kur’an olay zincirlerine dayanır; İsrâiliyat/tartışmalı ayrıntılar kesin bilgi olarak yazılmaz.
- Zikir/dua çekirdek havuzu 40 kayıt olarak korunur; ayrıca build ile yaklaşık **268 Hisnü'l-Müslim** kaydı yerel arşive eklenir. Kur’an temelli günlük zikirlerde Arapça ve Latin okunuş runtime'da Kur’an metin katmanından tamamlanır.
- `[WEB...]`, `[A...]`, `[H...]`, `[Z...]`, `[K...]` gibi iç kimlikler kullanıcı metninde insan okunur kaynaklara dönüştürülür. Teknik/model parantezleri temizlenir; kaynak ayrı satırda gösterilir.
- WEB aday → kullanıcı onayı → `WEB_APPROVED / ACTIVE` prensibi korunur.
- Ayarlar > **DRIVE / DOSYA YEDEĞİ**: Android dosya seçicisiyle Google Drive seçilebilir. API anahtarı, onaylı web kaynakları, favoriler, günlük geçmiş, AI cache, Kur’an cache ve ayarlar JSON yedeğe alınır. Geri yükleme **mevcut veriyi silmez**, birleştirir.

## Veri güvenliği / migration

Mevcut veritabanı adı `mizan_personal.db` korunur. Eski tablolar silinmez. `sources`, `daily`, `candidates`, `chat`, `favorites`, `ai_cache` korunur. Çekirdek seed senkronizasyonu yalnız CORE kayıtlarını günceller; kullanıcı/onaylı web kayıtlarını temizlemez. Uygulama verisini temizleme gerektiren hiçbir kurulum adımı yoktur.

## Telefonda GitHub Actions ile APK

Daha önce kullandığın MÎZAN GitHub reposunda genel ZIP-build workflow'u varsa yalnız bu final ZIP'i repo köküne yükleyip workflow'u çalıştırman yeterlidir. Paket içindeki `GITHUB_ACTIONS_BUILD_MIZAN.yml` aynı yöntem için günceldir; `.github/workflows/build-apk.yml` kopyası da kaynak içinde bulunur.

Workflow sırası:
1. Java 17 + Android SDK 35 kurulur.
2. ZIP açılır.
3. `prepare_kutub_sitte.py` açık veri setini indirir ve yalnız gerekli Arapça/metadata alanlarıyla yerel `assets/kutub_sitte.db` üretir.
4. `build.sh` APK'yı aynı package/signing key ile imzalar.
5. Artifact adı `Mizan-v4.1.0-FINAL-APK` olur.

> GitHub Actions'ın build sırasında internete erişmesi gerekir; Kütüb-i Sitte kaynak verisi bu aşamada indirilir.

## Windows

İstenirse `build.bat` → `build-windows.ps1` hattı kullanılabilir. JDK 17 ve Android SDK 35 gerekir.

## İmza / güncelleme

- Package: `com.mizan.kisisel.widget`
- Version code: `51`
- Version name: `4.1.0`
- Keystore: `signing/mizan-widget-release.jks`

Bu değerler çalışan v4.0.3/v4.0.4 hattıyla uyumlu tutulmuştur; APK mevcut MÎZAN'ın üstüne **UPDATE** olarak kurulmak üzere hazırlanmıştır.

## Kaynak/lisans

Ayrıntı: `THIRD_PARTY_DATA.md`. Kütüb-i Sitte yapılandırılmış veri kaynağının lisans açıklaması korunur; sunnah.com'dan gelen modern İngilizce tercüme alanları final veritabanına dahil edilmez.
