#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
sdk_root="${MIZAN_ANDROID_SDK:-${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/workspace/android-sdk}}}"
jdk_root="${MIZAN_JDK:-${JAVA_HOME:-/workspace/jdk17}}"
export JAVA_HOME="$jdk_root"
export PATH="$jdk_root/bin:$PATH"
build_tools="$sdk_root/build-tools/35.0.0"
platform_jar="$sdk_root/platforms/android-35/android.jar"
build_dir="$project_dir/build"
output_dir="$project_dir/output"
keystore="$project_dir/signing/mizan-widget-release.jks"
store_pass="MizanWidget2026"
key_alias="mizan-widget"

for required in "$build_tools/aapt2" "$build_tools/d8" "$build_tools/zipalign" "$build_tools/apksigner" "$platform_jar" "$jdk_root/bin/javac"; do
  if [ ! -e "$required" ]; then
    echo "Eksik Android aracı: $required" >&2
    exit 1
  fi
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "Eksik araç: python3 (Kütüb-i Sitte verisini hazırlamak için gerekli)." >&2
  exit 1
fi

echo "[MIZAN] Tam Kütüb-i Sitte + Hisnü'l-Müslim yerel paketi hazırlanıyor…"
python3 "$project_dir/prepare_kutub_sitte.py"

rm -rf "$build_dir"
mkdir -p "$build_dir/gen" "$build_dir/classes" "$build_dir/dex" "$output_dir" "$project_dir/signing"
rm -f "$output_dir"/*.apk

"$build_tools/aapt2" compile --dir "$project_dir/res" -o "$build_dir/resources.zip"
"$build_tools/aapt2" link \
  -I "$platform_jar" \
  --manifest "$project_dir/AndroidManifest.xml" \
  --java "$build_dir/gen" \
  --min-sdk-version 23 \
  --target-sdk-version 35 \
  --version-code 51 \
  --version-name 4.1.0 \
  -A "$project_dir/assets" \
  -o "$build_dir/base-unsigned.apk" \
  "$build_dir/resources.zip"

mapfile -t java_files < <(find "$project_dir/src" "$build_dir/gen" -name '*.java' -type f | sort)
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$platform_jar" -d "$build_dir/classes" "${java_files[@]}"
jar --create --file "$build_dir/classes.jar" -C "$build_dir/classes" .
"$build_tools/d8" --lib "$platform_jar" --min-api 23 --output "$build_dir/dex" "$build_dir/classes.jar"

cp "$build_dir/base-unsigned.apk" "$build_dir/with-dex.apk"
(cd "$build_dir/dex" && zip -q -u "$build_dir/with-dex.apk" classes.dex)
"$build_tools/zipalign" -f -p 4 "$build_dir/with-dex.apk" "$build_dir/aligned.apk"

if [ ! -f "$keystore" ]; then
  keytool -genkeypair -noprompt \
    -keystore "$keystore" \
    -storepass "$store_pass" \
    -keypass "$store_pass" \
    -alias "$key_alias" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=Mizan Kisisel, OU=Kisisel, O=Mizan, L=Manisa, C=TR"
fi

apk="$output_dir/Mizan-v4.1.0-TAM-GUNLUK-KUTUPHANE-KUTUB-I-SITTE.apk"
"$build_tools/apksigner" sign \
  --ks "$keystore" \
  --ks-key-alias "$key_alias" \
  --ks-pass "pass:$store_pass" \
  --key-pass "pass:$store_pass" \
  --out "$apk" \
  "$build_dir/aligned.apk"

"$build_tools/apksigner" verify --verbose --print-certs "$apk"
echo "APK_READY=$apk"
