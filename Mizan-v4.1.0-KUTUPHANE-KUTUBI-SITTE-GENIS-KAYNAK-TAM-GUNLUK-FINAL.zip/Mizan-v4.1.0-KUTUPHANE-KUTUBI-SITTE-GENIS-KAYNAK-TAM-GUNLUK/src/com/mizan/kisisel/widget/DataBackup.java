package com.mizan.kisisel.widget;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Map;

final class DataBackup {
    private static final String[] TABLES={"sources","daily","candidates","chat","favorites","ai_cache"};
    private static final String[] PREFS={"mizan_ai","mizan_quran_text_cache","mizan_quran_study","mizan_prayer_times","mizan_widget"};

    static void write(Context c, Uri uri)throws Exception{
        LocalStore store=LocalStore.get(c);store.seedIfNeeded(c);SQLiteDatabase db=store.getReadableDatabase();
        JSONObject root=new JSONObject();root.put("format","MIZAN_BACKUP_V1");root.put("createdAt",System.currentTimeMillis());
        JSONObject tables=new JSONObject();for(String t:TABLES)tables.put(t,exportTable(db,t));root.put("tables",tables);
        JSONObject prefs=new JSONObject();for(String name:PREFS)prefs.put(name,exportPrefs(c.getSharedPreferences(name,Context.MODE_PRIVATE)));root.put("prefs",prefs);
        OutputStream out=c.getContentResolver().openOutputStream(uri,"w");if(out==null)throw new Exception("Yedek dosyası açılamadı.");out.write(root.toString().getBytes("UTF-8"));out.flush();out.close();
    }

    static void read(Context c, Uri uri)throws Exception{
        InputStream in=c.getContentResolver().openInputStream(uri);if(in==null)throw new Exception("Yedek dosyası açılamadı.");
        BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();
        JSONObject root=new JSONObject(b.toString());if(!"MIZAN_BACKUP_V1".equals(root.optString("format")))throw new Exception("Bu dosya geçerli bir Mîzan yedeği değil.");
        LocalStore store=LocalStore.get(c);SQLiteDatabase db=store.getWritableDatabase();JSONObject tables=root.optJSONObject("tables");
        db.beginTransaction();try{if(tables!=null)for(String t:TABLES)importTable(db,t,tables.optJSONArray(t));db.setTransactionSuccessful();}finally{db.endTransaction();}
        JSONObject prefs=root.optJSONObject("prefs");if(prefs!=null)for(String name:PREFS)importPrefs(c.getSharedPreferences(name,Context.MODE_PRIVATE),prefs.optJSONObject(name));
        store.seedIfNeeded(c); // Yeni sürümün çekirdek kayıtlarını eksikse ekler, kullanıcı kayıtlarını silmez.
    }

    private static JSONArray exportTable(SQLiteDatabase db,String table){
        JSONArray a=new JSONArray();Cursor c=null;try{c=db.rawQuery("SELECT * FROM "+table,null);String[] cols=c.getColumnNames();while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<cols.length;i++){if(c.isNull(i))o.put(cols[i],JSONObject.NULL);else{int type=c.getType(i);if(type==Cursor.FIELD_TYPE_INTEGER)o.put(cols[i],c.getLong(i));else if(type==Cursor.FIELD_TYPE_FLOAT)o.put(cols[i],c.getDouble(i));else o.put(cols[i],c.getString(i));}}a.put(o);}}catch(Exception ignored){}finally{if(c!=null)c.close();}return a;
    }

    private static void importTable(SQLiteDatabase db,String table,JSONArray rows)throws Exception{
        if(rows==null)return;for(int i=0;i<rows.length();i++){JSONObject o=rows.optJSONObject(i);if(o==null)continue;ContentValues v=new ContentValues();JSONArray names=o.names();if(names==null)continue;for(int j=0;j<names.length();j++){String k=names.optString(j);Object x=o.opt(k);if(x==null||x==JSONObject.NULL)v.putNull(k);else if(x instanceof Integer||x instanceof Long)v.put(k,((Number)x).longValue());else if(x instanceof Number)v.put(k,((Number)x).doubleValue());else v.put(k,String.valueOf(x));}db.insertWithOnConflict(table,null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    }

    private static JSONObject exportPrefs(SharedPreferences p)throws Exception{
        JSONObject o=new JSONObject();for(Map.Entry<String,?> e:p.getAll().entrySet()){Object v=e.getValue();JSONObject x=new JSONObject();if(v instanceof Boolean){x.put("t","b");x.put("v",v);}else if(v instanceof Integer){x.put("t","i");x.put("v",v);}else if(v instanceof Long){x.put("t","l");x.put("v",v);}else if(v instanceof Float){x.put("t","f");x.put("v",String.valueOf(v));}else{x.put("t","s");x.put("v",String.valueOf(v));}o.put(e.getKey(),x);}return o;
    }

    private static void importPrefs(SharedPreferences p,JSONObject o)throws Exception{
        if(o==null)return;SharedPreferences.Editor e=p.edit();JSONArray names=o.names();if(names==null)return;for(int i=0;i<names.length();i++){String k=names.optString(i);JSONObject x=o.optJSONObject(k);if(x==null)continue;String t=x.optString("t","s");if("b".equals(t))e.putBoolean(k,x.optBoolean("v"));else if("i".equals(t))e.putInt(k,x.optInt("v"));else if("l".equals(t))e.putLong(k,x.optLong("v"));else if("f".equals(t)){try{e.putFloat(k,Float.parseFloat(x.optString("v","0")));}catch(Exception ignored){}}else e.putString(k,x.optString("v",""));}e.apply();
    }
    private DataBackup(){}
}
