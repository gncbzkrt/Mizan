package com.mizan.fehm;

import com.mizan.kisisel.widget.R;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

public class QuranPlaybackService extends Service {
    static final String ACTION_START="com.mizan.fehm.PLAY_START";
    static final String ACTION_STOP="com.mizan.fehm.PLAY_STOP";
    static final String ACTION_SPEED="com.mizan.fehm.PLAY_SPEED";
    static final String ACTION_STATE="com.mizan.fehm.PLAY_STATE";
    static final String EXTRA_SURAH="surah", EXTRA_AYAH="ayah", EXTRA_RECITER="reciter", EXTRA_CONT="continuous", EXTRA_GAPLESS="gapless", EXTRA_SPEED="speed";

    /*
     * MÎZAN Kur'an dinleme:
     * - p: o anda çalan ayet
     * - nextPlayer: yalnızca hazırlanmış ve p'ye zincirlenmiş sonraki ayet
     *
     * ÖNEMLİ: Prepared durumundaki bir MediaPlayer'a non-zero setPlaybackParams()
     * çağrısı Android'de oynatmayı başlatır. Bu yüzden sonraki ayetin hız parametresi
     * prepare() ÖNCESİNDE atanır; hazırlanmış nextPlayer'a sonradan hız uygulanmaz.
     */
    private MediaPlayer p, nextPlayer;
    private AudioManager audioManager;
    private int surah=1,ayah=1,currentAyah=1,nextAyah=-1;
    private String reciter=Reciters.MAHER_64;
    private boolean continuous=true, gapless=false;
    private float speed=1.0f;
    private static final int NID=7012;
    private int playToken=0;
    private int nextPrepToken=0;

    @Override public void onCreate(){super.onCreate();createChannel();audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);}

    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i==null){
            android.content.SharedPreferences sp=getSharedPreferences("fehm_playback",MODE_PRIVATE);
            if(!sp.getBoolean("active",false)){stopSelf();return START_NOT_STICKY;}
            surah=sp.getInt("surah",1);ayah=sp.getInt("ayah",1);reciter=sp.getString("reciter",Reciters.MAHER_64);
            continuous=sp.getBoolean("continuous",false);gapless=sp.getBoolean("gapless",false);
            speed=gapless?clampSpeed(getSharedPreferences("mizan_quran_reader",MODE_PRIVATE).getFloat("speed",1.0f)):1.0f;
            playCurrent();return START_STICKY;
        }
        String a=i.getAction();
        if(ACTION_STOP.equals(a)){broadcast("stopped");stopAll();return START_NOT_STICKY;}
        if(ACTION_SPEED.equals(a)){
            if(gapless){
                speed=clampSpeed(i.getFloatExtra(EXTRA_SPEED,speed));
                applySpeedToPlayingPlayer();
                /* Hazır bekleyen player'a setPlaybackParams uygulamak onu başlatabileceği için yeniden hazırla. */
                rebuildPreparedNext(playToken);
                broadcast("speed");
            }
            return START_STICKY;
        }
        surah=i.getIntExtra(EXTRA_SURAH,1);ayah=i.getIntExtra(EXTRA_AYAH,1);reciter=i.getStringExtra(EXTRA_RECITER);if(reciter==null)reciter=Reciters.MAHER_64;
        continuous=i.getBooleanExtra(EXTRA_CONT,false);gapless=i.getBooleanExtra(EXTRA_GAPLESS,false);
        speed=gapless?clampSpeed(getSharedPreferences("mizan_quran_reader",MODE_PRIVATE).getFloat("speed",1.0f)):1.0f;
        playCurrent();return START_STICKY;
    }

    private void playCurrent(){if(gapless&&continuous)playGaplessStart();else playStandardCurrent();}

    /* FEHM eğitim modu: davranış bilerek değiştirilmedi. Ayet bittiğinde durur. */
    private void playStandardCurrent(){
        releaseAll();requestAudioFocus();ayah=QuranMeta.clampAyah(surah,ayah);currentAyah=ayah;final int token=++playToken;final int ss=surah,aa=ayah;final String rr=reciter;
        saveState(true);startForeground(NID,notification());broadcast("loading");
        new Thread(new Runnable(){public void run(){
            String src;
            try{QuranAudioCache.download(QuranPlaybackService.this,rr,ss,aa);src=QuranAudioCache.file(QuranPlaybackService.this,rr,ss,aa).getAbsolutePath();}
            catch(Exception e){src=Reciters.url(rr,ss,aa);}
            final String chosen=src;new Handler(getMainLooper()).post(new Runnable(){public void run(){if(token!=playToken)return;startStandardMedia(chosen,false,token);}});
        }}).start();
    }

    private void startStandardMedia(String src,final boolean fallbackUsed,final int token){
        try{
            releaseAll();p=new MediaPlayer();configure(p);p.setDataSource(src);
            p.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer m){if(token!=playToken)return;m.start();broadcast("playing");}});
            p.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){public void onCompletion(MediaPlayer m){if(token!=playToken)return;if(continuous&&ayah<QuranMeta.ayahCount(surah)){ayah++;playCurrent();}else{broadcast("complete");stopAll();}}});
            p.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer m,int what,int extra){if(token!=playToken)return true;if(!fallbackUsed){releaseAll();startStandardMedia(Reciters.fallbackUrl(reciter,surah,ayah),true,token);}else{broadcast("error");stopAll();}return true;}});
            p.prepareAsync();
        }catch(Exception e){if(!fallbackUsed)startStandardMedia(Reciters.fallbackUrl(reciter,surah,ayah),true,token);else{broadcast("error");stopAll();}}
    }

    /* MÎZAN Kur'an dinleme modu: yalnız bir sonraki ayet hazırlanır ve zincirlenir. */
    private void playGaplessStart(){
        releaseAll();requestAudioFocus();ayah=QuranMeta.clampAyah(surah,ayah);currentAyah=ayah;final int token=++playToken;final int ss=surah,aa=ayah;final String rr=reciter;
        saveState(true);startForeground(NID,notification());broadcast("loading");
        new Thread(new Runnable(){public void run(){
            MediaPlayer cur=null,nxt=null;int na=-1;
            try{
                cur=preparePlayer(rr,ss,aa);
                if(aa<QuranMeta.ayahCount(ss)){na=aa+1;nxt=preparePlayer(rr,ss,na);}
                final MediaPlayer fcur=cur,fnxt=nxt;final int fna=na;
                new Handler(getMainLooper()).post(new Runnable(){public void run(){
                    if(token!=playToken){safeRelease(fcur);safeRelease(fnxt);return;}
                    p=fcur;currentAyah=aa;ayah=aa;nextPlayer=fnxt;nextAyah=fna;
                    attachGapless(p,aa,token);
                    if(nextPlayer!=null){attachGapless(nextPlayer,nextAyah,token);try{p.setNextMediaPlayer(nextPlayer);}catch(Exception ignored){}}
                    try{p.start();broadcast("playing");startForeground(NID,notification());}catch(Exception e){broadcast("error");stopAll();}
                }});
            }catch(Exception e){safeRelease(cur);safeRelease(nxt);new Handler(getMainLooper()).post(new Runnable(){public void run(){if(token==playToken){broadcast("error");stopAll();}}});}
        }}).start();
    }

    private MediaPlayer preparePlayer(String rr,int ss,int aa)throws Exception{
        String src;
        try{QuranAudioCache.download(this,rr,ss,aa);src=QuranAudioCache.file(this,rr,ss,aa).getAbsolutePath();}
        catch(Exception e){src=Reciters.url(rr,ss,aa);}
        MediaPlayer m=new MediaPlayer();
        try{configure(m);m.setDataSource(src);applySpeedBeforePrepare(m);m.prepare();return m;}
        catch(Exception first){safeRelease(m);MediaPlayer f=new MediaPlayer();configure(f);f.setDataSource(Reciters.fallbackUrl(rr,ss,aa));applySpeedBeforePrepare(f);f.prepare();return f;}
    }

    private void attachGapless(final MediaPlayer player,final int verse,final int token){
        if(player==null)return;
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){public void onCompletion(MediaPlayer m){if(token!=playToken)return;handleGaplessCompletion(m,verse,token);}});
        player.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer m,int what,int extra){if(token!=playToken)return true;broadcast("error");stopAll();return true;}});
    }

    private void handleGaplessCompletion(MediaPlayer completed,int verse,int token){
        if(token!=playToken)return;
        if(completed!=p){safeRelease(completed);return;}
        if(nextPlayer!=null){
            MediaPlayer old=p;
            p=nextPlayer;currentAyah=nextAyah;ayah=currentAyah;nextPlayer=null;nextAyah=-1;
            /* setNextMediaPlayer başarısız olmuşsa aynı player'ı elle başlat; başlamış player'a tekrar start zarar vermez. */
            try{if(!p.isPlaying())p.start();}catch(Exception e){broadcast("error");stopAll();return;}
            saveState(true);broadcast("playing");startForeground(NID,notification());
            detachAndReleaseOld(old);
            prepareNextForCurrent(token);
            return;
        }
        if(continuous&&verse<QuranMeta.ayahCount(surah)){
            ayah=verse+1;playGaplessStart();
        }else{broadcast("complete");stopAll();}
    }

    private void prepareNextForCurrent(final int token){
        if(token!=playToken||!gapless||!continuous||p==null)return;
        final int target=currentAyah+1;
        if(target>QuranMeta.ayahCount(surah)||nextPlayer!=null)return;
        final MediaPlayer anchor=p;final int ss=surah;final String rr=reciter;final int prepToken=++nextPrepToken;
        new Thread(new Runnable(){public void run(){
            MediaPlayer prepared=null;
            try{prepared=preparePlayer(rr,ss,target);final MediaPlayer fp=prepared;new Handler(getMainLooper()).post(new Runnable(){public void run(){
                if(token!=playToken||prepToken!=nextPrepToken||!gapless||p!=anchor||nextPlayer!=null){safeRelease(fp);return;}
                nextPlayer=fp;nextAyah=target;attachGapless(fp,target,token);try{anchor.setNextMediaPlayer(fp);}catch(Exception ignored){}
            }});}catch(Exception e){safeRelease(prepared);}
        }}).start();
    }

    private void rebuildPreparedNext(final int token){
        if(token!=playToken||!gapless||!continuous)return;
        nextPrepToken++;
        if(p!=null){try{p.setNextMediaPlayer(null);}catch(Exception ignored){}}
        safeRelease(nextPlayer);nextPlayer=null;nextAyah=-1;
        prepareNextForCurrent(token);
    }

    private void configure(MediaPlayer m){m.setAudioStreamType(AudioManager.STREAM_MUSIC);m.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);}
    private float clampSpeed(float v){return Math.max(0.7f,Math.min(1.4f,v));}

    /* Prepared player'a non-zero setPlaybackParams çağrısı oynatmayı başlatır. Hızı prepare öncesi uygula. */
    private void applySpeedBeforePrepare(MediaPlayer m){
        if(m==null||!gapless||Build.VERSION.SDK_INT<23)return;
        try{PlaybackParams pp=new PlaybackParams();pp.setSpeed(speed);m.setPlaybackParams(pp);}catch(Exception ignored){}
    }
    private void applySpeedToPlayingPlayer(){
        if(p==null||!gapless||Build.VERSION.SDK_INT<23)return;
        try{PlaybackParams pp=p.getPlaybackParams();pp.setSpeed(speed);p.setPlaybackParams(pp);}catch(Exception ignored){}
    }
    private void requestAudioFocus(){try{if(audioManager!=null)audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);}catch(Exception ignored){}}

    private Notification notification(){
        Intent open=gapless?new Intent(this,com.mizan.kisisel.widget.MainActivity.class):new Intent(this,MainActivity.class);
        if(gapless)open.putExtra("open_quran_listen",true);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,QuranPlaybackService.class);stop.setAction(ACTION_STOP);PendingIntent sp=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"fehm_quran_audio"):new Notification.Builder(this);
        String title=gapless?"MÎZAN · Kur’an · ":"MÎZAN · FEHM · ";
        String note=gapless?"kesintisiz sûre dinleme":"öğrenme dinlemesi";
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title+QuranMeta.label(surah,ayah)).setContentText(Reciters.name(reciter)+" · "+note+" · ekran kapalıyken devam eder").setContentIntent(pi).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Durdur",sp);return b.build();
    }

    private void saveState(boolean active){getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",active).putInt("surah",surah).putInt("ayah",ayah).putString("reciter",reciter).putBoolean("continuous",continuous).putBoolean("gapless",gapless).apply();}
    private void broadcast(String state){Intent b=new Intent(ACTION_STATE);b.setPackage(getPackageName());b.putExtra("state",state);b.putExtra("surah",surah);b.putExtra("ayah",ayah);b.putExtra("reciter",reciter);b.putExtra("gapless",gapless);b.putExtra("speed",speed);sendBroadcast(b);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel c=new NotificationChannel("fehm_quran_audio","MÎZAN · Kur’an Dinleme",NotificationManager.IMPORTANCE_LOW);c.setDescription("Kur’an dinleme ve ekran kapalı oynatma");n.createNotificationChannel(c);}}
    private void stopAll(){playToken++;releaseAll();saveState(false);try{if(audioManager!=null)audioManager.abandonAudioFocus(null);}catch(Exception ignored){}try{stopForeground(true);}catch(Exception ignored){}stopSelf();}
    private void releaseAll(){nextPrepToken++;safeRelease(p);safeRelease(nextPlayer);p=null;nextPlayer=null;nextAyah=-1;}
    private void detachAndReleaseOld(MediaPlayer old){if(old==null)return;try{old.setNextMediaPlayer(null);}catch(Exception ignored){}try{old.reset();}catch(Exception ignored){}try{old.release();}catch(Exception ignored){}}
    private void safeRelease(MediaPlayer m){if(m==null)return;try{m.setNextMediaPlayer(null);}catch(Exception ignored){}try{m.stop();}catch(Exception ignored){}try{m.reset();}catch(Exception ignored){}try{m.release();}catch(Exception ignored){}}
    @Override public void onDestroy(){releaseAll();getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",false).apply();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
