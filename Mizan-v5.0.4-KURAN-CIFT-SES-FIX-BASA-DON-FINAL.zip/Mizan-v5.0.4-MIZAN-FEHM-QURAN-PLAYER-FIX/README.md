# MÎZAN v5.0.4 — MÎZAN + FEHM Birleşik

**Oku · Dinle · Anla · Yaşa**

## v5.0.4 · Sabit Kur’an oynatıcısı + çift ses düzeltmesi
- Uygulama ana kabuğu MÎZAN’dır; alt menü **Bugün · Sohbet · Kur’an · Kütüphane · Ayarlar** olarak her iki tarafta da korunur.
- Kur’an alanının üstünde **KUR’AN | FEHM** geçişi bulunur.
- FEHM kendi eğitim alt sekmelerini üst bölümde kullanır; geri tuşu FEHM kökünde MÎZAN → Kur’an’a döner.
- **FEHM ses standardı değişmedi:** eğitimde ayet tek tek dinlenir ve ayet sonunda durur.
- **Yalnız MÎZAN → Kur’an dinleme modu kesintisizdir.** Bir sonraki ayet önceden hazırlanıp MediaPlayer zincirine bağlanır; okuyucunun doğal vakfı korunurken dosyalar arası yapay bekleme azaltılır.
- Kesintisiz dinleme ekranında sûrenin **Latin harfli okunuşu + seçili meal** birlikte görünür; ayarlara göre Arapça da gösterilir. Okunan ayet vurgulanır ve ekran onu takip eder.
- Dinleme kontrolleri artık ayetlerle birlikte kaymaz; **alt navigasyonun hemen üstünde sabit** kalır.
- Sabit çubuk: **önceki ayet · durdur/devam · sonraki ayet · hız azalt · 1.0× · hız artır · okuyucu seç · BAŞA**. BAŞA yalnız sayfayı en üste götürür, oynatmayı değiştirmez.
- Hız ayarı yalnız normal Kur’an kesintisiz dinleme moduna uygulanır; **FEHM eğitim dinlemesinin hızı ve ayet sonunda durma standardı değiştirilmez.**
- Çift okuyucu sesi düzeltildi: önceden hazırlanan ayete hız artık `prepare()` öncesinde verilir; böylece sonraki ayet hazırlanırken yanlışlıkla başlamaz.
- Oynatma zinciri aktif ayet + tek hazır sonraki ayet olacak şekilde sadeleştirildi; ayette takılmaya yol açan yarış durumu kaldırıldı.


Bu paket, çalışan MÎZAN v4.1.0 hattının üzerine FEHM v1.2.1 öğrenme ve ses motorunun tek Android uygulaması içinde birleştirilmiş sürümüdür.

## Güncelleme güvenliği
- Package name değişmedi: `com.mizan.kisisel.widget`
- Mevcut MÎZAN imza anahtarı aynen korunur.
- `versionCode=64`, `versionName=5.0.4`
- Mevcut MÎZAN uygulamasının üzerine UPDATE olarak kurulur.
- Uygulama verisini temizlemek gerekmez.
- v4.0.4 günlük rotasyon düzeltmeleri ve v4.1.0 Kütüphane/Kütüb-i Sitte katmanı korunur.
- MÎZAN widget receiver ve widget kaynakları korunmuştur.

## Yeni birleşik Kur’an alanı
Kur’an sayfası sade, ayet-merkezli bir okuma akışına geçirilmiştir.

- `☰` düğmesi ile soldan açılan **geçici menü**; sabit değildir.
- Menü tekrar `☰`, geri tuşu veya menü dışına dokunma ile kapanır.
- Aynı ayette yatay kaydırma: **OKUMA ↔ MEAL**.
- Ayet gösterimi üç seçeneklidir:
  - Sadece Arapça
  - Sadece Latin harfli okunuş
  - Arapça + Latin harfli okunuş
- Meal seçimi:
  - Diyanet İşleri
  - Diyanet Vakfı
  - Elmalılı Hamdi Yazır
- Yazı boyutu ayarı.
- İşaretli yere git / ayeti işaretle.
- Sûre ve cüz seçimi.
- Yerel Kur’an paketinde arama.
- Ayet notları.
- Favoriler.
- Mushaf / nüzul sırası korunur.
- Ayetten `MÎZAN’A SOR`, kelime inceleme ve `FEHM İLE ÖĞREN`.

Görsel/kullanım fikri Pratik Meal'deki sade kaydırma ve çekmece menü yaklaşımından esinlenmiştir; kod ve MÎZAN arayüzü bu proje içinde özgün olarak uygulanmıştır.

## FEHM birleşimi
FEHM artık ayrı launcher değildir. MÎZAN içinden açılan öğrenme modülüdür.

- Dinle ve öğren
- Kur’an Laboratuvarı
- Kelime/kök ve morfoloji
- Mini gramer
- Tekrar planı ve karıştırılan kelimeler
- Test/ilerleme kayıtları
- Yerel Kur’an paketi
- Çevrimdışı ses cache'i
- FEHM Drive yedeği/geri yükleme

MÎZAN'ın Gemini anahtarı FEHM tarafından da kullanılabilir. FEHM ayarlarından yapılan anahtar değişikliği MÎZAN ayarına da yansıtılır.

## Sesli Kur’an
- Mahir Al-Muaiqly 64 kbps / 128 kbps ve desteklenen diğer FEHM okuyucuları.
- MÎZAN → Kur’an: kesintisiz sûre oynatma, önceden hazırlanan sonraki ayet ve aktif ayet takibi.
- FEHM: eğitim amaçlı tek ayet oynatma; ayet sonunda durur.
- Ekran kapalıyken foreground service ile devam.
- Kur’an dinlemede ileri ses hazırlama/önbellekleme.
- Kur’an dinleme ekranında alt navigasyon üzerinde sabit tam kontrol çubuğu; diğer MÎZAN sayfalarında kalıcı mini oynatıcı.
- Okuyucu Kur’an Ayarları'ndan veya sabit oynatıcıdaki **OKUYUCU** düğmesinden değiştirilebilir.
- Kur’an dinleme hızı **0.7×–1.4×** aralığında ayarlanabilir; hız göstergesine dokunmak **1.0×** değerine döndürür.

## Zikir düzeltmesi
Zikir kartlarında Arapça ve Latin okunuşa ek olarak **Türkçe anlam** ayrı başlıkla görünür. Eski günlük cache kayıtları da veri temizliği gerektirmeden gösterim sırasında uyarlanır.

## Yedekleme / migration
MÎZAN yedeği `MIZAN_BACKUP_V2` biçimine yükseltilmiştir ve eski `MIZAN_BACKUP_V1` dosyalarını da okuyabilir.

MÎZAN yedeğine eklenenler:
- Kur’an okuma ayarları
- Kur’an notları ve işaret bilgisi
- FEHM öğrenme durumu

Geri yükleme mevcut tabloları topluca silmez; verileri birleştirir. FEHM'in kendi eski `FEHM_BACKUP_V1` yedeği, MÎZAN içindeki **Ayarlar → FEHM / Yedek → Yedekten Geri Yükle** yoluyla içe alınabilir ve mevcut ilerlemeyle birleştirilir.

## Widget
Mevcut MÎZAN widget'ı korunmuştur:
- Günün içerikleri
- Namaz vakitleri
- aktif vakit görünümü
- mevcut widget ileri/yenile akışı

## GitHub Actions ile telefondan APK
1. Bu ZIP'i açıp içindeki klasör/dosyaları GitHub reposuna yükle. ZIP'i repo kökünde bırakmayı tercih ediyorsan mevcut workflow ZIP'i de bulabilir.
2. `.github/workflows/build-apk.yml` repo içinde bulunmalıdır.
3. GitHub → **Actions** → **Mizan APK Olustur**.
4. **Run workflow**.
5. İşlem yeşil tamamlanınca Artifacts bölümünden `Mizan-v5.0.4-MIZAN-FEHM-QURAN-FIXED-PLAYER-APK` indir.
6. ZIP içindeki APK'yı mevcut MÎZAN'ın üzerine kur. Eski MÎZAN'ı kaldırma.

Build sırasında Kütüb-i Sitte/dua veri hazırlayıcısı çalışır. Android SDK 35 ve Java 17 workflow tarafından kurulur.

## Veri atıfları
- `THIRD_PARTY_DATA.md`: MÎZAN Kütüb-i Sitte / dua veri katmanı.
- `FEHM_ATTRIBUTIONS.txt`: FEHM Kur’an/morfoloji/ses veri kaynakları.
