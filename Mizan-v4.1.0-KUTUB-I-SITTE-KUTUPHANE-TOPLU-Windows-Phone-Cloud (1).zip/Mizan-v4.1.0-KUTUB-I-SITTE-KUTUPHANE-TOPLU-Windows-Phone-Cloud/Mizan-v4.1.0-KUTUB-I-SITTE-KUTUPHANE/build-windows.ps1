$ErrorActionPreference = 'Stop'

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SdkRoot = if ($env:MIZAN_ANDROID_SDK) { $env:MIZAN_ANDROID_SDK } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$JdkRoot = if ($env:MIZAN_JDK) { $env:MIZAN_JDK } else { 'C:\Program Files\Android\Android Studio\jbr' }
$BuildTools = Join-Path $SdkRoot 'build-tools\35.0.0'
$PlatformJar = Join-Path $SdkRoot 'platforms\android-35\android.jar'
$BuildDir = Join-Path $ProjectDir 'build'
$OutputDir = Join-Path $ProjectDir 'output'
$Keystore = Join-Path $ProjectDir 'signing\mizan-widget-release.jks'
$StorePass = 'MizanWidget2026'
$KeyAlias = 'mizan-widget'

$Aapt2 = Join-Path $BuildTools 'aapt2.exe'
$D8 = Join-Path $BuildTools 'd8.bat'
$Zipalign = Join-Path $BuildTools 'zipalign.exe'
$Apksigner = Join-Path $BuildTools 'apksigner.bat'
$Javac = Join-Path $JdkRoot 'bin\javac.exe'
$Jar = Join-Path $JdkRoot 'bin\jar.exe'
$Keytool = Join-Path $JdkRoot 'bin\keytool.exe'

# Android build-tools batch wrappers (d8/apksigner) JAVA_HOME ve PATH kullanir.
$env:JAVA_HOME = $JdkRoot
$env:PATH = (Join-Path $JdkRoot 'bin') + ';' + $env:PATH

function Need($Path, $Label) {
    if (-not (Test-Path $Path)) {
        Write-Host "`nEKSIK: $Label" -ForegroundColor Red
        Write-Host $Path -ForegroundColor Yellow
        throw "Gerekli arac bulunamadi: $Label"
    }
}

Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ' MIZAN v4.1.0 - KUTUB-I SITTE + KUTUPHANE WINDOWS APK DERLEYICI' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host "Android SDK : $SdkRoot"
Write-Host "JDK         : $JdkRoot"
Write-Host ''

Need $Aapt2 'Android Build Tools 35.0.0 / aapt2'
Need $D8 'Android Build Tools 35.0.0 / d8'
Need $Zipalign 'Android Build Tools 35.0.0 / zipalign'
Need $Apksigner 'Android Build Tools 35.0.0 / apksigner'
Need $PlatformJar 'Android SDK Platform 35'
Need $Javac 'JDK / javac'
Need $Jar 'JDK / jar'
Need $Keytool 'JDK / keytool'


# Kütüb-i Sitte + Hisnü'l-Müslim yerel verisini build öncesi hazırla.
$Prep = Join-Path $ProjectDir 'prepare_kutub_sitte.py'
$Python = Get-Command python -ErrorAction SilentlyContinue
if ($Python) {
  & $Python.Source $Prep
} else {
  $Py = Get-Command py -ErrorAction SilentlyContinue
  if (-not $Py) { throw 'Python 3 bulunamadı. Kütüb-i Sitte yerel paketini hazırlamak için Python 3 gerekli.' }
  & $Py.Source -3 $Prep
}
if ($LASTEXITCODE -ne 0) { throw 'Kütüb-i Sitte verisi hazırlanamadı.' }

if (Test-Path $BuildDir) { Remove-Item $BuildDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path (Join-Path $BuildDir 'gen'), (Join-Path $BuildDir 'classes'), (Join-Path $BuildDir 'dex'), $OutputDir, (Join-Path $ProjectDir 'signing') | Out-Null
Get-ChildItem $OutputDir -Filter '*.apk' -ErrorAction SilentlyContinue | Remove-Item -Force

Write-Host '[1/7] Kaynaklar derleniyor...' -ForegroundColor Green
& $Aapt2 compile --dir (Join-Path $ProjectDir 'res') -o (Join-Path $BuildDir 'resources.zip')
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile basarisiz.' }

Write-Host '[2/7] Android paket yapisi olusturuluyor...' -ForegroundColor Green
& $Aapt2 link -I $PlatformJar --manifest (Join-Path $ProjectDir 'AndroidManifest.xml') --java (Join-Path $BuildDir 'gen') --min-sdk-version 23 --target-sdk-version 35 --version-code 50 --version-name 4.1.0 -A (Join-Path $ProjectDir 'assets') -o (Join-Path $BuildDir 'base-unsigned.apk') (Join-Path $BuildDir 'resources.zip')
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link basarisiz.' }

Write-Host '[3/7] Java kodu derleniyor...' -ForegroundColor Green
$JavaFiles = @()
$JavaFiles += Get-ChildItem (Join-Path $ProjectDir 'src') -Recurse -Filter '*.java' | Select-Object -ExpandProperty FullName
$JavaFiles += Get-ChildItem (Join-Path $BuildDir 'gen') -Recurse -Filter '*.java' | Select-Object -ExpandProperty FullName
$ArgFile = Join-Path $BuildDir 'javac-files.txt'
$JavaFiles | ForEach-Object { '"' + ($_.Replace('\','/')) + '"' } | Set-Content -Encoding ASCII $ArgFile
& $Javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $PlatformJar -d (Join-Path $BuildDir 'classes') "@$ArgFile"
if ($LASTEXITCODE -ne 0) { throw 'javac basarisiz.' }

Write-Host '[4/7] DEX uretiliyor...' -ForegroundColor Green
$ClassesJar = Join-Path $BuildDir 'classes.jar'
Push-Location (Join-Path $BuildDir 'classes')
try { & $Jar cf $ClassesJar '.' } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'classes.jar olusturulamadi.' }
& $D8 --lib $PlatformJar --min-api 23 --output (Join-Path $BuildDir 'dex') $ClassesJar
if ($LASTEXITCODE -ne 0) { throw 'd8 basarisiz.' }

Write-Host '[5/7] APK birlestiriliyor ve hizalaniyor...' -ForegroundColor Green
$WithDex = Join-Path $BuildDir 'with-dex.apk'
Copy-Item (Join-Path $BuildDir 'base-unsigned.apk') $WithDex -Force
& $Jar uf $WithDex -C (Join-Path $BuildDir 'dex') 'classes.dex'
if ($LASTEXITCODE -ne 0) { throw 'classes.dex APK icine eklenemedi.' }
$Aligned = Join-Path $BuildDir 'aligned.apk'
& $Zipalign -f -p 4 $WithDex $Aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign basarisiz.' }

Write-Host '[6/7] APK imzalaniyor...' -ForegroundColor Green
if (-not (Test-Path $Keystore)) {
    & $Keytool -genkeypair -noprompt -keystore $Keystore -storepass $StorePass -keypass $StorePass -alias $KeyAlias -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Mizan Kisisel, OU=Kisisel, O=Mizan, L=Manisa, C=TR'
    if ($LASTEXITCODE -ne 0) { throw 'Imza anahtari olusturulamadi.' }
}
$Apk = Join-Path $OutputDir 'Mizan-v4.1.0-KUTUB-I-SITTE-KUTUPHANE.apk'
& $Apksigner sign --ks $Keystore --ks-key-alias $KeyAlias --ks-pass "pass:$StorePass" --key-pass "pass:$StorePass" --out $Apk $Aligned
if ($LASTEXITCODE -ne 0) { throw 'APK imzalama basarisiz.' }

Write-Host '[7/7] Imza dogrulaniyor...' -ForegroundColor Green
& $Apksigner verify --verbose --print-certs $Apk
if ($LASTEXITCODE -ne 0) { throw 'APK imza dogrulamasi basarisiz.' }

Write-Host ''
Write-Host '==============================================' -ForegroundColor Green
Write-Host ' APK HAZIR!' -ForegroundColor Green
Write-Host " $Apk" -ForegroundColor White
Write-Host '==============================================' -ForegroundColor Green
Start-Process explorer.exe "/select,`"$Apk`""
