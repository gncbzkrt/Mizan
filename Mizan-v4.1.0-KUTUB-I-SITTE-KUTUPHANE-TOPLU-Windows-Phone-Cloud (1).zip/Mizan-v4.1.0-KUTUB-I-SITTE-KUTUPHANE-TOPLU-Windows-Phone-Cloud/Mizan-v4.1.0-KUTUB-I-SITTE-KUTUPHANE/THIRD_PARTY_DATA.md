# Üçüncü taraf veri ve kaynak notu

## Kütüb-i Sitte / Hisnü’l-Müslim
Build sırasında kullanılan `Jaguar16/open-hadith-data` veri setinin yapılandırılmış verisi CC0 1.0 olarak yayımlanmıştır. Mîzan yalnız Arapça metin + kaynak/metadata ve Hisnü’l-Müslim için Latin okunuş alanını paketler; veri setindeki İngilizce çeviriler kopyalanmaz.

Kaynak veri otomatik çıkarılmış bir geliştirici veri setidir. Uygulama içinde Arapça asıl ve kaynak bilgisi görünür tutulur; dinî uygulama ve ilmî atıf için tahkikli basılı kaynak ve ehil uzman doğrulaması önerilir.

## Kıssa
Yeni kıssa çekirdeğinin birincil kaynağı ilgili Kur’an pasajlarıdır. Diyanet Kur’an Yolu ve TDV İslâm Ansiklopedisi, bağlamı kontrol etmek için ikincil doğrulama kaynaklarıdır. Kur’an’da bulunmayan folklorik ayrıntılar kıssa metnine eklenmez.

## Zikir / dua
Günlük çekirdeğe eklenen yeni dualar Kur’an ayetleridir. Hadis kaynaklı daha geniş dua/zikir arşivi Hisnü’l-Müslim üzerinden yerel olarak sunulur. Kaynakta bulunmayan tekrar sayısı, özel gün, garanti, tılsım veya sonuç vaadi eklenmez.
