# MÎZAN v4.1.0 — Kütüb-i Sitte + Kütüphane

Bu paket v4.0.4 günlük rotasyon düzeltmesini de içerir; ara sürümü ayrıca kurmak gerekmez. Aynı paket kimliği ve aynı imza anahtarı korunmuştur.

## Bu sürümde

- Günlük rotasyon: Ayet / Hadis / Kıssa / Zikir yakın geçmişte tekrar etmeyecek şekilde döndürülür.
- Günlük kaynak havuzu güncellemede eski kullanıcı verisini silmeden senkronlanır.
- Kıssa çekirdeği 20 → 42: yeni kayıtlar doğrudan Kur’an pasajlarına dayanır; Kur’an Yolu / TDV yalnız bağlam kontrolüdür, folklor eklenmez.
- Zikir/dua çekirdeği 20 → 40: yeni kayıtlar Kur’an’daki dualardan eklenmiştir. Kaynakta olmayan sabit tekrar sayısı/garanti eklenmez.
- Hisnü’l-Müslim: 268 dua/zikir Arapça + Latin okunuş + kaynak olarak yerel arşivde bulunur.
- Kütüb-i Sitte: Sahih Buhârî, Sahih Müslim, Sünen Nesâî, Sünen Ebû Dâvûd, Câmi‘ Tirmizî ve Sünen İbn Mâce — toplam 29.660 Arapça hadis ve kaynak/grade metadata.
- Kütüphane artık yalnız başlık listesi değildir: geçmiş gün / içerik açma, 365 günlük arama ve Favoriler vardır.
- Kütüb-i Sitte ve Zikir/Dua arşivleri Kütüphane içinden aranabilir.
- Teknik kaynak kimlikleri (`[WEB…]`, `[Z012]`, `A001 · …`) kullanıcıya gösterilmez; anlamlı insan kaynaklarına çevrilir.
- Kur’an sekmesi 6236 ayetin tamamına erişmeye devam eder. Günlük ayet kartındaki 40 kayıt, yalnız günlük seçilmiş tematik çekirdektir; Kur’an erişim sınırı değildir.

## Kütüb-i Sitte verisi nasıl ekleniyor?

Kaynak ZIP küçük tutulur. GitHub Actions `build.sh` çalışırken açık veri setinin SQLite sürümünü indirir ve yalnız altı ana kitabın Arapça metnini, kaynak/narrator/grade metadata alanlarını ve Hisnü’l-Müslim’in Arapça + Latin alanlarını `assets/kutub_sitte.db` içine hazırlar. İngilizce çeviriler APK’ya kopyalanmaz.

Türkçe hadis/dua anlamı, kullanıcı istediğinde Arapça asıldan Gemini ile üretilir ve cihazda önbelleğe alınır. Bu metin resmî/edisyon çevirisi değildir; uygulama Arapça aslı ve kaynak bilgisini birlikte gösterir. Dinî hüküm ve akademik kullanım için tahkikli baskı/uzman kontrolü esastır.

## GitHub / telefon kurulumu

1. Repoda eski `Mizan*.zip` dosyasını kaldır.
2. Bu ZIP’i yükle.
3. Mevcut `build-apk.yml` workflow’unu çalıştır.
4. Build sırasında Kütüb-i Sitte verisinin indirilmesi nedeniyle önceki sürümlere göre biraz daha uzun sürebilir.
5. Artifact içindeki `Mizan-v4.1.0-KUTUB-I-SITTE-KUTUPHANE.apk` dosyasını mevcut Mîzan’ın üzerine kur.

**Uygulama verisini temizleme.** Onaylanmış web kaynakları, API anahtarı ve geçmiş günlük arşivi mevcut uygulama veritabanında korunur.
