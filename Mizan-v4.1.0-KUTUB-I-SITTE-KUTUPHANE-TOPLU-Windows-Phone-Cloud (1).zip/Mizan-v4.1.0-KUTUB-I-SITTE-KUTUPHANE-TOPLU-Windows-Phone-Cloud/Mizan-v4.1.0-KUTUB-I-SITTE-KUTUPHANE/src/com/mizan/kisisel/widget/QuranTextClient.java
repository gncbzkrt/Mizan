package com.mizan.kisisel.widget;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class QuranTextClient {
    static final class Detail {
        String arabic="", reading="", diyanet="", elmalili="", vakif="";
        boolean ok(){return !arabic.isEmpty()&&!diyanet.isEmpty();}
    }
    private static final String PREF="mizan_quran_text_cache";
    private static final Pattern REF=Pattern.compile("(\\d{1,3})\\s*/\\s*(\\d{1,3})(?:\\s*-\\s*(\\d{1,3}))?");
    static Detail forAyah(Context c,int surah,int ayah){
        surah=QuranStudy.clampSurah(surah);ayah=QuranStudy.clampAyah(surah,ayah);String key=surah+"_"+ayah+"_"+ayah;SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);String cached=p.getString(key,"");if(!cached.isEmpty()){try{return fromJson(new JSONObject(cached));}catch(Exception ignored){}}
        Detail d=new Detail();try{JSONObject one=fetch(surah,ayah);d.arabic=one.optString("arabic");d.reading=one.optString("reading");d.diyanet=one.optString("diyanet");d.elmalili=one.optString("elmalili");d.vakif=one.optString("vakif");if(d.ok())p.edit().putString(key,toJson(d).toString()).apply();}catch(Exception ignored){}return d;
    }
    static Detail forSource(Context c, SourceRecord source){
        if(source==null)return new Detail();Matcher m=REF.matcher(source.title==null?"":source.title);boolean found=m.find();if(!found){m=REF.matcher(source.reference==null?"":source.reference);found=m.find();}if(!found)return new Detail();
        int surah=Integer.parseInt(m.group(1)),start=Integer.parseInt(m.group(2)),end=m.group(3)==null?start:Integer.parseInt(m.group(3));if(end<start||end-start>5)end=start;
        String key=surah+"_"+start+"_"+end;SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);String cached=p.getString(key,"");if(!cached.isEmpty()){try{return fromJson(new JSONObject(cached));}catch(Exception ignored){}}
        Detail d=new Detail();StringBuilder ar=new StringBuilder(),rd=new StringBuilder(),di=new StringBuilder(),el=new StringBuilder(),va=new StringBuilder();
        try{for(int ay=start;ay<=end;ay++){JSONObject one=fetch(surah,ay);append(ar,one.optString("arabic"));append(rd,one.optString("reading"));append(di,one.optString("diyanet"));append(el,one.optString("elmalili"));append(va,one.optString("vakif"));}d.arabic=ar.toString();d.reading=rd.toString();d.diyanet=di.toString();d.elmalili=el.toString();d.vakif=va.toString();if(d.ok())p.edit().putString(key,toJson(d).toString()).apply();}catch(Exception ignored){}
        return d;
    }
    private static JSONObject fetch(int surah,int ayah)throws Exception{
        String u="https://api.alquran.cloud/v1/ayah/"+surah+":"+ayah+"/editions/quran-uthmani,tr.transliteration,tr.diyanet,tr.yazir,tr.vakfi";HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(10000);h.setReadTimeout(25000);h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","Mizan-Personal/4.0.2");int code=h.getResponseCode();if(code<200||code>=300)throw new Exception("Quran HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();h.disconnect();JSONObject root=new JSONObject(b.toString());JSONArray a=root.optJSONArray("data");if(a==null)throw new Exception("Quran data yok");JSONObject out=new JSONObject();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;JSONObject ed=x.optJSONObject("edition");String id=ed==null?"":ed.optString("identifier");String text=x.optString("text","").trim();if("quran-uthmani".equals(id))out.put("arabic",text);else if("tr.transliteration".equals(id))out.put("reading",text);else if("tr.diyanet".equals(id))out.put("diyanet",text);else if("tr.yazir".equals(id))out.put("elmalili",text);else if("tr.vakfi".equals(id))out.put("vakif",text);}return out;
    }
    private static void append(StringBuilder b,String x){if(x==null||x.trim().isEmpty())return;if(b.length()>0)b.append("\n");b.append(x.trim());}
    private static JSONObject toJson(Detail d)throws Exception{return new JSONObject().put("arabic",d.arabic).put("reading",d.reading).put("diyanet",d.diyanet).put("elmalili",d.elmalili).put("vakif",d.vakif);}
    private static Detail fromJson(JSONObject o){Detail d=new Detail();d.arabic=o.optString("arabic");d.reading=o.optString("reading");d.diyanet=o.optString("diyanet");d.elmalili=o.optString("elmalili");d.vakif=o.optString("vakif");return d;}
    private QuranTextClient(){}
}
