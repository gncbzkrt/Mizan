package com.mizan.kisisel.widget;

import android.content.Context;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class CitationFormatter {
    private static final Pattern TECH=Pattern.compile("\\[([A-ZÇĞİÖŞÜ]{1,12}[0-9]{1,20})\\]");
    static String humanize(Context c,String text){
        if(text==null||text.isEmpty())return text==null?"":text;
        Matcher m=TECH.matcher(text);StringBuffer out=new StringBuffer();LocalStore db=LocalStore.get(c);
        while(m.find()){
            String id=m.group(1);String label=db.citationLabel(id);m.appendReplacement(out,Matcher.quoteReplacement("("+label+")"));
        }
        m.appendTail(out);return out.toString();
    }
    static String humanSource(Context c,String source){
        if(source==null||source.trim().isEmpty())return "";
        String raw=source.trim();
        // Günlük kayıtların kaynak alanında eski sürümlerden "A001 · Kur’an 65/2-3" gibi çıplak
        // teknik kimlikler bulunabilir. Kullanıcıya kimliği değil gerçek kaynağı göster.
        int dotRaw=raw.indexOf(" · ");
        if(dotRaw>0){
            String maybeId=raw.substring(0,dotRaw).trim();
            if(maybeId.matches("[A-ZÇĞİÖŞÜ]{1,12}[0-9]{1,20}")){
                String label=LocalStore.get(c).citationLabel(maybeId);String tail=raw.substring(dotRaw+3).trim();
                if(label==null||label.trim().isEmpty()||"yerel kaynak".equals(label))return tail;
                if(tail.isEmpty()||label.equalsIgnoreCase(tail)||label.contains(tail)||tail.contains(label))return label;
                return label;
            }
        }
        String s=humanize(c,raw);
        // Parantez içinde teknik kimlik yerine insan referansı gösterildikten sonra tekrar eden kaynağı sadeleştir.
        if(s.startsWith("(")){int close=s.indexOf(')');int dot=s.indexOf(" · ");if(close>0&&dot>close){String a=s.substring(1,close).trim();String b=s.substring(dot+3).trim();if(!b.isEmpty()&&(a.equalsIgnoreCase(b)||a.contains(b)||b.contains(a)))return a;}}
        return s;
    }
    private CitationFormatter(){}
}
