package com.mizan.kisisel.widget;

import android.content.Context;
import android.content.SharedPreferences;

final class QuranStudy {
    static final String[] NAMES={
        "Fâtiha","Bakara","Âl-i İmrân","Nisâ","Mâide","En'âm","A'râf","Enfâl","Tevbe","Yûnus","Hûd","Yûsuf","Ra'd","İbrâhim","Hicr","Nahl","İsrâ","Kehf","Meryem","Tâhâ","Enbiyâ","Hac","Mü'minûn","Nûr","Furkân","Şuarâ","Neml","Kasas","Ankebût","Rûm","Lokmân","Secde","Ahzâb","Sebe'","Fâtır","Yâsîn","Sâffât","Sâd","Zümer","Mü'min","Fussilet","Şûrâ","Zuhruf","Duhân","Câsiye","Ahkâf","Muhammed","Fetih","Hucurât","Kâf","Zâriyât","Tûr","Necm","Kamer","Rahmân","Vâkıa","Hadîd","Mücâdele","Haşr","Mümtehine","Saf","Cum'a","Münâfikûn","Tegâbün","Talâk","Tahrîm","Mülk","Kalem","Hâkka","Meâric","Nûh","Cin","Müzzemmil","Müddessir","Kıyâmet","İnsan","Mürselât","Nebe'","Nâziât","Abese","Tekvîr","İnfitâr","Mutaffifîn","İnşikâk","Bürûc","Târık","A'lâ","Gâşiye","Fecr","Beled","Şems","Leyl","Duhâ","İnşirâh","Tîn","Alak","Kadr","Beyyine","Zilzâl","Âdiyât","Kâria","Tekâsür","Asr","Hümeze","Fîl","Kureyş","Mâûn","Kevser","Kâfirûn","Nasr","Tebbet","İhlâs","Felak","Nâs"
    };
    static final int[] AYAH_COUNTS={7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6};
    static final int[] NUZUL_ORDER={96,68,73,74,1,111,81,87,92,89,93,94,103,100,108,102,107,109,105,113,114,112,53,80,97,91,85,95,106,101,75,104,77,50,90,86,54,38,7,72,36,25,35,19,20,56,26,27,28,17,10,11,12,15,6,37,31,34,39,40,41,42,43,44,45,46,51,88,18,16,71,14,21,23,32,52,67,69,70,78,79,82,84,30,29,83,2,8,3,33,60,4,99,57,47,13,55,76,65,98,59,24,22,63,58,49,66,64,61,62,48,5,9,110};
    private static final String PREF="mizan_quran_study";
    static int lastSurah(Context c){return clampSurah(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getInt("surah",1));}
    static int lastAyah(Context c){int s=lastSurah(c);return clampAyah(s,c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getInt("ayah",1));}
    static void savePosition(Context c,int surah,int ayah){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putInt("surah",clampSurah(surah)).putInt("ayah",clampAyah(surah,ayah)).apply();}
    static int clampSurah(int s){return Math.max(1,Math.min(114,s));}
    static int clampAyah(int surah,int a){int s=clampSurah(surah);return Math.max(1,Math.min(AYAH_COUNTS[s-1],a));}
    static String label(int surah,int ayah){int s=clampSurah(surah);return s+". "+NAMES[s-1]+" · "+clampAyah(s,ayah)+"/"+AYAH_COUNTS[s-1];}
    static String orderMode(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("order","mushaf");}
    static boolean isNuzul(Context c){return "nuzul".equals(orderMode(c));}
    static void setOrderMode(Context c,String mode){c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("order","nuzul".equals(mode)?"nuzul":"mushaf").apply();}
    static String orderLabel(Context c){return isNuzul(c)?"Nüzul sırası":"Mushaf sırası";}
    static int nuzulIndex(int surah){int s=clampSurah(surah);for(int i=0;i<NUZUL_ORDER.length;i++)if(NUZUL_ORDER[i]==s)return i;return 0;}

    static int surahForNuzulPosition(int pos){if(pos<1)pos=1;if(pos>NUZUL_ORDER.length)pos=NUZUL_ORDER.length;return NUZUL_ORDER[pos-1];}
    static int nuzulPositionForSurah(int surah){return nuzulIndex(surah)+1;}
    static String orderInfo(Context c,int surah){int s=clampSurah(surah);if(isNuzul(c))return "Nüzul "+(nuzulIndex(s)+1)+". sıra · Mushaf "+s+". sure";return "Mushaf "+s+". sure";}
    static int[] previous(Context c,int s,int a){s=clampSurah(s);a=clampAyah(s,a);if(a>1)return new int[]{s,a-1};if(!isNuzul(c)){if(s>1)return new int[]{s-1,AYAH_COUNTS[s-2]};return new int[]{1,1};}int idx=nuzulIndex(s);if(idx>0){int ps=NUZUL_ORDER[idx-1];return new int[]{ps,AYAH_COUNTS[ps-1]};}return new int[]{NUZUL_ORDER[0],1};}
    static int[] next(Context c,int s,int a){s=clampSurah(s);a=clampAyah(s,a);if(a<AYAH_COUNTS[s-1])return new int[]{s,a+1};if(!isNuzul(c)){if(s<114)return new int[]{s+1,1};return new int[]{114,AYAH_COUNTS[113]};}int idx=nuzulIndex(s);if(idx<NUZUL_ORDER.length-1)return new int[]{NUZUL_ORDER[idx+1],1};int last=NUZUL_ORDER[NUZUL_ORDER.length-1];return new int[]{last,AYAH_COUNTS[last-1]};}
    private QuranStudy(){}
}
