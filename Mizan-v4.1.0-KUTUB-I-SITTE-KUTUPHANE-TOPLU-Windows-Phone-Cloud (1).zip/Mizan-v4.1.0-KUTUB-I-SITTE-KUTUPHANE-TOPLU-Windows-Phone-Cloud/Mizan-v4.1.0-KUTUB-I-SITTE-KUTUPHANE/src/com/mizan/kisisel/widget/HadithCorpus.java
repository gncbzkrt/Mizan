package com.mizan.kisisel.widget;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class HadithCorpus {
    static final String ALL="all";
    static final int EXPECTED_SIX=29660, EXPECTED_DUAS=268;
    static final class Hadith {
        String collectionId="",number="",reference="",arabic="",matn="",narrator="",grade="",url="";
        String book(){return bookName(collectionId);}
        String title(){String n=number==null||number.isEmpty()?"":(" "+number);return book()+n;}
    }
    static final class Dua {
        String number="",reference="",arabic="",reading="",hisnReference="",url="";
        String title(){return "Hisnü’l-Müslim"+(number==null||number.isEmpty()?"":(" · "+number));}
    }
    private static File file(Context c){return new File(c.getFilesDir(),"mizan_kutub_sitte_v1.db");}
    private static synchronized File ensure(Context c)throws Exception{
        File f=file(c);if(f.exists()&&f.length()>1024*1024)return f;
        InputStream in=c.getAssets().open("kutub_sitte.db");File tmp=new File(c.getFilesDir(),"mizan_kutub_sitte_v1.tmp");FileOutputStream out=new FileOutputStream(tmp);byte[] b=new byte[65536];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();out.close();in.close();if(f.exists())f.delete();if(!tmp.renameTo(f))throw new Exception("Kütüb-i Sitte verisi cihaza hazırlanamadı.");return f;
    }
    static boolean ready(Context c){try{SQLiteDatabase db=open(c);Cursor x=db.rawQuery("SELECT COUNT(*) FROM hadiths",null);boolean ok=x.moveToFirst()&&x.getInt(0)>29000;x.close();db.close();return ok;}catch(Exception e){return false;}}
    static int hadithCount(Context c){return count(c,"hadiths");}
    static int duaCount(Context c){return count(c,"duas");}
    private static int count(Context c,String table){try{SQLiteDatabase db=open(c);Cursor x=db.rawQuery("SELECT COUNT(*) FROM "+table,null);int n=x.moveToFirst()?x.getInt(0):0;x.close();db.close();return n;}catch(Exception e){return 0;}}
    private static SQLiteDatabase open(Context c)throws Exception{return SQLiteDatabase.openDatabase(ensure(c).getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);}

    static List<Hadith> search(Context c,String collection,String q,int limit){List<Hadith> out=new ArrayList<Hadith>();SQLiteDatabase db=null;try{
        db=open(c);String s=q==null?"":q.trim();String where="";List<String> args=new ArrayList<String>();
        if(collection!=null&&!ALL.equals(collection)){where="collection_id=?";args.add(collection);}
        if(!s.isEmpty()){
            String cond;if(s.matches("[0-9]+")){cond="(hadith_number=? OR reference LIKE ?)";args.add(s);args.add("%"+s+"%");}
            else{cond="(text_ar LIKE ? OR matn_ar LIKE ? OR reference LIKE ?)";args.add("%"+s+"%");args.add("%"+s+"%");args.add("%"+s+"%");}
            where=where.isEmpty()?cond:(where+" AND "+cond);
        }
        String sql="SELECT collection_id,hadith_number,reference,text_ar,matn_ar,narrator,COALESCE(NULLIF(grade_ar,''),source_grade),url_source FROM hadiths"+(where.isEmpty()?"":" WHERE "+where)+" ORDER BY _id LIMIT "+Math.max(1,Math.min(50,limit));
        Cursor x=db.rawQuery(sql,args.toArray(new String[args.size()]));while(x.moveToNext()){Hadith h=new Hadith();h.collectionId=x.getString(0);h.number=nz(x.getString(1));h.reference=nz(x.getString(2));h.arabic=nz(x.getString(3));h.matn=nz(x.getString(4));h.narrator=nz(x.getString(5));h.grade=nz(x.getString(6));h.url=nz(x.getString(7));out.add(h);}x.close();
    }catch(Exception ignored){}finally{if(db!=null)db.close();}return out;}

    static List<Dua> searchDuas(Context c,String q,int limit){List<Dua> out=new ArrayList<Dua>();SQLiteDatabase db=null;try{
        db=open(c);String s=q==null?"":q.trim();String sql="SELECT dua_number,reference,text_ar,transliteration,hisn_reference,url_source FROM duas";String[] args=null;if(!s.isEmpty()){if(s.matches("[0-9]+")){sql+=" WHERE dua_number=? OR reference LIKE ? OR hisn_reference LIKE ?";args=new String[]{s,"%"+s+"%","%"+s+"%"};}else{sql+=" WHERE text_ar LIKE ? OR transliteration LIKE ? OR reference LIKE ?";args=new String[]{"%"+s+"%","%"+s+"%","%"+s+"%"};}}sql+=" ORDER BY _id LIMIT "+Math.max(1,Math.min(50,limit));Cursor x=db.rawQuery(sql,args);while(x.moveToNext()){Dua d=new Dua();d.number=nz(x.getString(0));d.reference=nz(x.getString(1));d.arabic=nz(x.getString(2));d.reading=nz(x.getString(3));d.hisnReference=nz(x.getString(4));d.url=nz(x.getString(5));out.add(d);}x.close();
    }catch(Exception ignored){}finally{if(db!=null)db.close();}return out;}

    static String cachedTurkishMeaning(Context c,Hadith h){return LocalStore.get(c).cacheGet("hadith_tr:"+h.collectionId+":"+h.number);}
    static String cachedTurkishMeaning(Context c,Dua d){return LocalStore.get(c).cacheGet("dua_tr:"+d.number);}
    static String turkishMeaning(Context c,Hadith h)throws Exception{
        String key="hadith_tr:"+h.collectionId+":"+h.number;LocalStore ls=LocalStore.get(c);String cached=ls.cacheGet(key);if(!cached.isEmpty())return cached;if(!GeminiClient.configured(c))throw new Exception("Türkçe anlam için Gemini API anahtarı gerekli.");String ar=h.matn==null||h.matn.trim().isEmpty()?h.arabic:h.matn;
        String prompt="Aşağıdaki hadis Arapça aslından Türkçeye erişim amacıyla gösterilecek. Metne sadık, doğal ve ihtiyatlı bir Türkçe anlam ver. Yeni hüküm, ravi, olay veya açıklama ekleme. Arapçada kapalı/çok anlamlı bir ifade varsa kısa parantezle 'yaklaşık anlam' diye belirt. Çeviri sonrasında tek satır 'Kaynak: "+h.book()+" "+h.number+"' yaz. Teknik kod kullanma.\n\nARAPÇA:\n"+ar+"\n\nKAYNAK BİLGİSİ: "+h.reference+"\nDERECE: "+h.grade;String out=CitationFormatter.humanize(c,GeminiClient.generate(c,prompt,false)).trim();if(out.length()<20)throw new Exception("Türkçe anlam üretilemedi.");ls.cachePut(key,out);return out;
    }
    static String turkishMeaning(Context c,Dua d)throws Exception{
        String key="dua_tr:"+d.number;LocalStore ls=LocalStore.get(c);String cached=ls.cacheGet(key);if(!cached.isEmpty())return cached;if(!GeminiClient.configured(c))throw new Exception("Türkçe anlam için Gemini API anahtarı gerekli.");String prompt="Aşağıdaki dua/zikir metnini Arapça aslına sadık biçimde Türkçeye aktar. Önce kısa anlamı ver; ardından varsa kullanım bağlamını yalnız kaynak bilgisinden çıkarılabildiği ölçüde belirt. Kaynakta olmayan sayı, vakit, fazilet veya garanti ekleme. Teknik kod kullanma.\n\nARAPÇA:\n"+d.arabic+"\nLATİN OKUNUŞ:\n"+d.reading+"\nKAYNAK: "+d.reference+" "+d.hisnReference;String out=GeminiClient.generate(c,prompt,false).trim();if(out.length()<10)throw new Exception("Türkçe anlam üretilemedi.");ls.cachePut(key,out);return out;
    }
    static String[] collectionIds(){return new String[]{ALL,"bukhari","muslim","nasai","abudawud","tirmidhi","ibnmajah"};}
    static String[] collectionNames(){return new String[]{"Tümü","Sahih Buhârî","Sahih Müslim","Sünen Nesâî","Sünen Ebû Dâvûd","Câmi‘ Tirmizî","Sünen İbn Mâce"};}
    static String bookName(String id){if("bukhari".equals(id))return "Sahih Buhârî";if("muslim".equals(id))return "Sahih Müslim";if("nasai".equals(id))return "Sünen Nesâî";if("abudawud".equals(id))return "Sünen Ebû Dâvûd";if("tirmidhi".equals(id))return "Câmi‘ Tirmizî";if("ibnmajah".equals(id))return "Sünen İbn Mâce";return "Kütüb-i Sitte";}
    private static String nz(String s){return s==null?"":s;}
    private HadithCorpus(){}
}
