package com.mizan.kisisel.widget;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

final class DailyEngine {
    private static final String[] THEMES={"sabır ve dayanıklılık","şükür ve nimet bilinci","merhamet ve insan ilişkileri","niyet ve samimiyet","öfke ve dil ahlakı","tevekkül ve tedbir","ilim ve hikmet","affetmek ve kalbi temizlemek","aile ve yakınlara iyilik","ümit ve tövbe","adalet ve kul hakkı","cesaret ve doğruyu savunmak"};

    static TodaySync.PackageData localPreview(Context c){
        LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);String key=TodaySync.todayKey();String theme=theme();
        SourceRecord ayet=pick(db,"AYET",theme,key,0),hadis=pick(db,"HADIS",theme,key,1),kissa=pick(db,"KISSA",theme,key,2),zikir=pick(db,"ZIKIR",theme,key,3);
        if(ayet==null||hadis==null||kissa==null||zikir==null)return TodaySync.empty("Yerel kaynak havuzu eksik.");
        try{
            JSONArray items=new JSONArray();
            items.put(item("AYET",ayet.title,"Türkçe anlam özeti\n"+ayet.body+"\n\nKaynak\n"+ayet.reference,ayet.id+" · "+ayet.reference,"",""));
            items.put(item("HADİS",hadis.title,hadisBase(hadis),hadis.id+" · "+hadis.reference,"",""));
            items.put(item("KISSA",kissa.title,kissaBase(kissa),kissa.id+" · "+kissa.reference,"",""));
            items.put(item("ZİKİR",zikir.title,zikirBase(zikir),zikir.id+" · "+zikir.reference,zikir.arabic,zikir.reading));
            items.put(item("MÎZAN AI","AI tefekkürü hazırlanacak","Gemini bağlantısı olduğunda bu dört kaynak ortak tema içinde birlikte yorumlanacak.","Yerel kaynaklar hazır","",""));
            JSONObject root=new JSONObject().put("ok",true).put("formatVersion",8).put("dateKey",key).put("dateLabel",TodaySync.todayLabel()).put("theme",theme).put("items",items);
            return TodaySync.parse(root.toString());
        }catch(Exception e){return TodaySync.empty("Yerel önizleme hazırlanamadı.");}
    }

    static TodaySync.PackageData ensureToday(Context c,boolean force){
        LocalStore db=LocalStore.get(c);db.seedIfNeeded(c);String key=TodaySync.todayKey();
        if(!force){String existing=db.dailyJson(key);if(!existing.isEmpty()){try{JSONObject ex=new JSONObject(existing);int fv=ex.optInt("formatVersion",0);boolean waiting=existing.contains("AI tefekkürü bekleniyor");if(fv>=8&&(!GeminiClient.configured(c)||!waiting))return TodaySync.parse(existing);}catch(Exception ignored){}}}
        String theme=theme();SourceRecord ayet=pick(db,"AYET",theme,key,0),hadis=pick(db,"HADIS",theme,key,1),kissa=pick(db,"KISSA",theme,key,2),zikir=pick(db,"ZIKIR",theme,key,3);
        if(ayet==null||hadis==null||kissa==null||zikir==null)return TodaySync.empty("Yerel kaynak havuzu günlük paket için eksik.");

        QuranTextClient.Detail q=QuranTextClient.forSource(c,ayet);
        QuranTextClient.Detail zq=new QuranTextClient.Detail();
        if((zikir.arabic==null||zikir.arabic.trim().isEmpty())&&(zikir.reference!=null&&zikir.reference.contains("Kur’an"))) zq=QuranTextClient.forSource(c,zikir);
        final String zArabic=(zikir.arabic==null||zikir.arabic.trim().isEmpty())?zq.arabic:zikir.arabic;
        final String zReading=(zikir.reading==null||zikir.reading.trim().isEmpty())?zq.reading:zikir.reading;
        try{
            String prompt="Mîzan için günlük DERİNLEŞTİRME metinlerini üret. Tema: "+theme+".\n\n"+
                "Aşağıdaki dört yerel kaynak SABİTTİR. Başka ayet, hadis, kıssa, zikir, ravi, numara, hüküm veya rivayet ekleme. Kaynak metnini yeniden yazmaya çalışma; yalnız açıklama ve tefekkür üret.\n"+
                "ayetDeep: bağlam, temel kavram, bugüne bakan yön, yanlış anlaşılma sınırı; 500-850 karakter.\n"+
                "hadisMeaning: SADECE verilen hadis kaydı ve referansına dayanarak hadisin Türkçe anlamını doğrudan, 1-3 cümlede sadık biçimde aktar. Özet yorum yapma. Referanstan emin değilsen HADIS.body metnini aynen kullan. Ravi, yeni hüküm veya yeni rivayet ekleme.\n"+
                "hadisDeep: ahlâkî ölçü, ilişkilerde karşılığı, 2 somut örnek, aşırı yorum sınırı; 650-950 karakter.\n"+
                "kissaDeep: verilen olay akışını genişletmeden insan davranışı, kırılma noktası, bugüne bakan ders ve sınır; 750-1050 karakter.\n"+
                "zikirDeep: anlam ve niyet, kaynakta verilen zaman/sayı ölçüsü, bilinçli uygulama, tılsım/garanti gibi yanlış yorumlara sınır; 450-750 karakter.\n"+
                "mizan: dört kaynağı aynı tema altında 6-8 kısa paragrafta birbirine bağla. Başlıklar: Bugünün ortak mesajı; Kaynakların birbirini tamamladığı yer; Bugün için 3 somut uygulama; Muhasebe sorusu; Kısa dua. Fetva verme.\n"+
                "YALNIZ JSON: {\"ayetDeep\":\"\",\"hadisMeaning\":\"\",\"hadisDeep\":\"\",\"kissaDeep\":\"\",\"zikirDeep\":\"\",\"mizan\":\"\"}\n\n"+
                "AYET:\n"+ayet.compact()+"\n\nHADIS:\n"+hadis.compact()+"\n\nKISSA:\n"+kissa.compact()+"\n\nZIKIR:\n"+zikir.compact();
            String raw=GeminiClient.generate(c,prompt,false);JSONObject ai=new JSONObject(GeminiClient.cleanJson(raw));
            String ayetBody=ayetBase(ayet,q)+section("Derinleştirilmiş okuma",ai.optString("ayetDeep"));
            String hadisMeaning=ai.optString("hadisMeaning","").trim();
            if(hadisMeaning.length()<20)hadisMeaning=hadis.body;
            String hadisBody=hadisBase(hadis,hadisMeaning)+section("AI şerhi · Derinleştirilmiş okuma",ai.optString("hadisDeep"));
            String kissaBody=kissaBase(kissa)+section("Derinleştirilmiş okuma",ai.optString("kissaDeep"));
            String zikirBody=zikirBase(zikir)+section("Derinleştirilmiş okuma",ai.optString("zikirDeep"));
            String mizan=ai.optString("mizan","").trim();if(mizan.length()<250)throw new IllegalStateException("AI Mîzan tefekkürü eksik.");
            JSONArray items=new JSONArray();
            items.put(item("AYET",ayet.title,ayetBody,ayet.id+" · "+ayet.reference,q.arabic,q.reading));
            items.put(item("HADİS",hadis.title,hadisBody,hadis.id+" · "+hadis.reference,"",""));
            items.put(item("KISSA",kissa.title,kissaBody,kissa.id+" · "+kissa.reference,"",""));
            items.put(item("ZİKİR",zikir.title,zikirBody,zikir.id+" · "+zikir.reference,zArabic,zReading));
            items.put(item("MÎZAN AI","Bugünün ortak mesajı",mizan+"\n\nBu metin kaynaklardan üretilmiş kişisel tefekkür desteğidir; fetva değildir.","["+ayet.id+"] · ["+hadis.id+"] · ["+kissa.id+"] · ["+zikir.id+"]","",""));
            JSONObject root=new JSONObject().put("ok",true).put("formatVersion",8).put("dateKey",key).put("dateLabel",TodaySync.todayLabel()).put("theme",theme).put("items",items);
            String json=root.toString();db.saveDaily(key,TodaySync.todayLabel(),json,theme);return TodaySync.parse(json);
        }catch(Exception e){
            try{
                JSONArray items=new JSONArray();
                items.put(item("AYET",ayet.title,ayetBase(ayet,q),ayet.id+" · "+ayet.reference,q.arabic,q.reading));
                items.put(item("HADİS",hadis.title,hadisBase(hadis),hadis.id+" · "+hadis.reference,"",""));
                items.put(item("KISSA",kissa.title,kissaBase(kissa),kissa.id+" · "+kissa.reference,"",""));
                items.put(item("ZİKİR",zikir.title,zikirBase(zikir),zikir.id+" · "+zikir.reference,zArabic,zReading));
                items.put(item("MÎZAN AI","AI tefekkürü bekleniyor","Dört kaynak korunuyor. Gemini erişimi yeniden sağlandığında ortak Mîzan tefekkürü üretilecek.\n\nHata: "+(e.getMessage()==null?"AI erişimi yok":e.getMessage()),"Yerel kaynaklar korunuyor","",""));
                JSONObject root=new JSONObject().put("ok",true).put("formatVersion",8).put("dateKey",key).put("dateLabel",TodaySync.todayLabel()).put("theme",theme).put("items",items);String json=root.toString();db.saveDaily(key,TodaySync.todayLabel(),json,theme);return TodaySync.parse(json);
            }catch(Exception x){return TodaySync.empty("Günlük paket oluşturulamadı.");}
        }
    }

    private static String ayetBase(SourceRecord a,QuranTextClient.Detail q){
        StringBuilder b=new StringBuilder();
        if(q!=null&&q.ok()){
            add(b,"Diyanet meali",q.diyanet);add(b,"Elmalılı karşılaştırması",q.elmalili);add(b,"Diyanet Vakfı karşılaştırması",q.vakif);
        }else add(b,"Türkçe anlam özeti",a.body);
        add(b,"Kaynak ölçüsü",a.reference);
        return b.toString();
    }
    private static String hadisBase(SourceRecord h){return hadisBase(h,h.body);}
    private static String hadisBase(SourceRecord h,String meaning){StringBuilder b=new StringBuilder();add(b,"Hadisin Türkçe anlamı",meaning);if(h.keywords!=null&&!h.keywords.trim().isEmpty())add(b,"Konu",h.keywords.replace(" "," · "));add(b,"Kaynak / Künye",h.reference);if(h.grade!=null&&!h.grade.isEmpty())add(b,"Sıhhat derecesi",h.grade);if(h.note!=null&&!h.note.isEmpty()&&!"Kısa anlam aktarımı".equals(h.note))add(b,"Kaynak notu",h.note);return b.toString();}
    private static String kissaBase(SourceRecord k){StringBuilder b=new StringBuilder();add(b,"Olayın akışı",k.body);if(k.note!=null&&!k.note.isEmpty())add(b,"Ana ders",k.note);add(b,"Kur’an bağlamı",k.reference);return b.toString();}
    private static String zikirBase(SourceRecord z){String body=z.body==null?"":z.body;body=body.replaceFirst("(?s)^Arapça:.*?\\nOkunuş:.*?\\n"," ").trim();StringBuilder b=new StringBuilder();if(!body.isEmpty())b.append(body);if(z.note!=null&&!z.note.isEmpty()){if(b.length()>0)b.append("\n\n");b.append("Kaynak ölçüsü ve sınır\n").append(z.note);}return b.toString();}
    private static String section(String title,String text){String x=text==null?"":text.trim();return x.isEmpty()?"":"\n\n"+title+"\n"+x;}
    private static void add(StringBuilder b,String title,String text){if(text==null||text.trim().isEmpty())return;if(b.length()>0)b.append("\n\n");b.append(title).append("\n").append(text.trim());}
    private static JSONObject item(String type,String title,String body,String source,String arabic,String reading)throws Exception{return new JSONObject().put("type",type).put("title",title).put("body",body).put("source",source).put("arabic",arabic==null?"":arabic).put("reading",reading==null?"":reading);}
    private static SourceRecord pick(LocalStore db,String type,String theme,String key,int salt){
        List<SourceRecord> rows=db.allType(type);if(rows.isEmpty())return null;
        int historyWindow=Math.min(30,Math.max(3,rows.size()-1));
        Set<String> recent=db.recentSourceIds(type,key,historyWindow);
        List<SourceRecord> thematic=new ArrayList<SourceRecord>();
        List<SourceRecord> related=db.search(theme,80);
        for(SourceRecord r:related)if(type.equals(r.type)&&!recent.contains(r.id))thematic.add(r);
        List<SourceRecord> pool=thematic;
        if(pool.isEmpty()){pool=new ArrayList<SourceRecord>();for(SourceRecord r:rows)if(!recent.contains(r.id))pool.add(r);}
        if(pool.isEmpty())pool=rows;
        int h=(key+"|"+type+"|"+salt+"|"+theme).hashCode();if(h==Integer.MIN_VALUE)h=0;int idx=Math.abs(h)%pool.size();
        return pool.get(idx);
    }
    private static String theme(){int d=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);return THEMES[Math.abs(d)%THEMES.length];}
    private DailyEngine(){}
}
