@echo off
setlocal
cd /d "%~dp0"
title Mizan v5.0.2 Mizan + FEHM Birlesik APK Derleyici
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-windows.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo ==============================================
  echo DERLEME BASARISIZ.
  echo Yukaridaki kirmizi EKSIK veya hata satirinin
  echo ekran goruntusunu ChatGPT'ye gonder.
  echo ==============================================
) else (
  echo APK output klasorunde hazir.
)
echo.
pause
exit /b %ERR%
