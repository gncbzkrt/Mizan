package com.mizan.fehm;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;
import java.util.ArrayList;

public final class FehmBridge {
    public static final String ACTION_STATE=QuranPlaybackService.ACTION_STATE;
    public static final String DEFAULT_RECITER=Reciters.MAHER_64;

    public static final class Verse {
        public final int surah,ayah,global;
        public final String arabic,latin,diyanet,elmalili,vakif;
        Verse(QuranClient.Ayah x){surah=x.surah;ayah=x.ayah;global=x.global;arabic=x.arabic;latin=x.latin;diyanet=x.diyanet;elmalili=x.elmalili;vakif=x.vakif;}
        public boolean ok(){return arabic!=null&&!arabic.isEmpty()&&diyanet!=null&&!diyanet.isEmpty();}
    }

    public static Verse verse(Context c,int surah,int ayah)throws Exception{return new Verse(QuranClient.fetch(c,surah,ayah));}
    public static ArrayList<Verse> surah(Context c,int surah)throws Exception{ArrayList<QuranClient.Ayah> raw=QuranLocalStore.get(c).getSurah(surah);if(raw.size()<QuranMeta.ayahCount(surah)){raw=QuranClient.fetchSurahMulti(surah);QuranLocalStore.get(c).putVerses(raw);}ArrayList<Verse> out=new ArrayList<Verse>();for(QuranClient.Ayah x:raw)out.add(new Verse(x));return out;}
    public static int ayahCount(int surah){return QuranMeta.ayahCount(surah);}
    public static String surahName(int surah){return QuranMeta.name(surah);}
    public static boolean localQuranReady(Context c){return QuranDataManager.quranReady(c);}
    public static String localStatus(Context c){return QuranDataManager.status(c);}
    public static ArrayList<Verse> search(Context c,String q,int limit){ArrayList<Verse> out=new ArrayList<Verse>();for(QuranClient.Ayah x:QuranLocalStore.get(c).searchVerses(q,limit))out.add(new Verse(x));return out;}
    public static String[] reciterIds(){return Reciters.ids();}
    public static String[] reciterNames(){return Reciters.names();}
    public static String reciterName(String id){return Reciters.name(id);}
    public static String selectedReciter(Context c){return c.getSharedPreferences("mizan_quran_reader",Context.MODE_PRIVATE).getString("reciter",DEFAULT_RECITER);}
    public static void setSelectedReciter(Context c,String id){c.getSharedPreferences("mizan_quran_reader",Context.MODE_PRIVATE).edit().putString("reciter",id==null?DEFAULT_RECITER:id).apply();}
    public static void play(Context c,int surah,int ayah,boolean continuous){String rr=selectedReciter(c);Intent i=new Intent(c,QuranPlaybackService.class);i.setAction(QuranPlaybackService.ACTION_START);i.putExtra(QuranPlaybackService.EXTRA_SURAH,surah);i.putExtra(QuranPlaybackService.EXTRA_AYAH,ayah);i.putExtra(QuranPlaybackService.EXTRA_RECITER,rr);i.putExtra(QuranPlaybackService.EXTRA_CONT,continuous);i.putExtra(QuranPlaybackService.EXTRA_GAPLESS,false);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void playQuranContinuous(Context c,int surah,int ayah){String rr=selectedReciter(c);Intent i=new Intent(c,QuranPlaybackService.class);i.setAction(QuranPlaybackService.ACTION_START);i.putExtra(QuranPlaybackService.EXTRA_SURAH,surah);i.putExtra(QuranPlaybackService.EXTRA_AYAH,ayah);i.putExtra(QuranPlaybackService.EXTRA_RECITER,rr);i.putExtra(QuranPlaybackService.EXTRA_CONT,true);i.putExtra(QuranPlaybackService.EXTRA_GAPLESS,true);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
    public static void stop(Context c){Intent i=new Intent(c,QuranPlaybackService.class);i.setAction(QuranPlaybackService.ACTION_STOP);c.startService(i);}
    public static boolean isPlaying(Context c){return c.getSharedPreferences("fehm_playback",Context.MODE_PRIVATE).getBoolean("active",false);}
    public static int playingSurah(Context c){return c.getSharedPreferences("fehm_playback",Context.MODE_PRIVATE).getInt("surah",1);}
    public static int playingAyah(Context c){return c.getSharedPreferences("fehm_playback",Context.MODE_PRIVATE).getInt("ayah",1);}
    public static String playingReciter(Context c){return c.getSharedPreferences("fehm_playback",Context.MODE_PRIVATE).getString("reciter",DEFAULT_RECITER);}
    public static boolean isQuranContinuous(Context c){return c.getSharedPreferences("fehm_playback",Context.MODE_PRIVATE).getBoolean("gapless",false);}
    public static void open(Context c,int surah,int ayah,String mode){Intent i=new Intent(c,MainActivity.class);i.putExtra("surah",surah);i.putExtra("ayah",ayah);i.putExtra("mizan_mode",mode==null?"":mode);c.startActivity(i);}
    public static JSONObject exportLearningState(Context c)throws Exception{return FehmStore.get(c).exportState();}
    public static void importLearningState(Context c,JSONObject o)throws Exception{if(o!=null)FehmStore.get(c).importState(o);}
    public static String learningSummary(Context c){FehmStore s=FehmStore.get(c);return "Kelime "+s.learnedCount("word")+" · Dinleme %"+Math.min(100,s.getInt("listenScore",0))+" · Ayet çözümleme %"+Math.min(100,s.getInt("analysisScore",0));}
    private FehmBridge(){}
}
