#!/usr/bin/env python3
import os, sqlite3, urllib.request, tempfile, pathlib, sys, shutil

ROOT = pathlib.Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
OUT = ASSETS / 'kutub_sitte.db'
URL = os.environ.get('MIZAN_HADITH_DB_URL','https://github.com/Jaguar16/open-hadith-data/releases/download/v1.1.0/hadiths.db')
TARGETS = {
    'bukhari': ('bukhari','sahih al-bukhari','sahih al bukhari'),
    'muslim': ('sahih muslim','muslim'),
    'nasai': ('nasa','nasa\'i','nasai'),
    'abudawud': ('abu dawud','abi dawud','abudawud'),
    'tirmidhi': ('tirmidhi','at-tirmidhi'),
    'ibnmajah': ('ibn majah','ibn-majah','ibn maja'),
}

def validate(path):
    if not path.exists() or path.stat().st_size < 1024*1024:
        return False,0,0
    try:
        db=sqlite3.connect(str(path));
        h=db.execute('select count(*) from hadiths').fetchone()[0]
        d=db.execute('select count(*) from duas').fetchone()[0] if db.execute("select count(*) from sqlite_master where type='table' and name='duas'").fetchone()[0] else 0
        db.close()
        return h >= 29000, h, d
    except Exception:
        return False,0,0

def cols(db, table):
    return [r[1] for r in db.execute(f'pragma table_info({table})')]

def val(row, names, key, default=''):
    try:
        i=names.index(key); x=row[i]
        return default if x is None else x
    except Exception:
        return default

def main():
    ASSETS.mkdir(parents=True, exist_ok=True)
    ok,h,d=validate(OUT)
    if ok:
        print(f'[MIZAN] Kütüb-i Sitte hazır: {h} hadis, {d} dua')
        return
    work = ROOT / 'build' / 'content'
    work.mkdir(parents=True, exist_ok=True)
    source = work / 'hadiths-source.db'
    print('[MIZAN] Açık hadis veritabanı indiriliyor…')
    try:
        req=urllib.request.Request(URL,headers={'User-Agent':'Mizan-Build/5.0.2'})
        with urllib.request.urlopen(req, timeout=180) as r, open(source,'wb') as f:
            shutil.copyfileobj(r,f)
    except Exception as e:
        print('[MIZAN] HATA: Kütüb-i Sitte verisi indirilemedi:',e,file=sys.stderr)
        print('[MIZAN] Tekrar GitHub Action çalıştırabilirsin.',file=sys.stderr)
        sys.exit(2)

    src=sqlite3.connect(str(source)); src.row_factory=None
    ccols=cols(src,'collections')
    rows=src.execute('select * from collections').fetchall()
    # Güncel açık veri setinde koleksiyon kimlikleri zaten bukhari/muslim/nasai/abudawud/tirmidhi/ibnmajah.
    # Önce kimliği birebir eşleştir; yalnız eski şemalarda ad alanına geri düş. Böylece "Hisn al-Muslim"
    # yanlışlıkla Sahih Muslim olarak seçilemez.
    by_id={str(val(r,ccols,'id','')).lower():r for r in rows}
    chosen=[]
    for canon in TARGETS:
        r=by_id.get(canon)
        if r is None:
            for candidate in rows:
                name=(str(val(candidate,ccols,'name_en',''))+' '+str(val(candidate,ccols,'name_ar',''))).lower()
                if any(t in name for t in TARGETS[canon]):
                    # Dua koleksiyonu Hisn al-Muslim ana altı kitaptan biri değildir.
                    ctype=str(val(candidate,ccols,'type','')).lower()
                    if ctype=='dua':
                        continue
                    r=candidate;break
        if r is not None:
            rid=str(val(r,ccols,'id',''))
            chosen.append((rid,canon,str(val(r,ccols,'name_en','')),str(val(r,ccols,'name_ar',''))))
    if len(chosen)!=6:
        print('[MIZAN] HATA: 6 ana hadis kitabı bulunamadı. Bulunan:',chosen,file=sys.stderr);sys.exit(3)

    if OUT.exists(): OUT.unlink()
    out=sqlite3.connect(str(OUT))
    out.executescript('''
      PRAGMA journal_mode=OFF;
      PRAGMA synchronous=OFF;
      CREATE TABLE collections(id TEXT PRIMARY KEY, canonical_id TEXT, name_en TEXT, name_ar TEXT, total_hadiths INTEGER);
      CREATE TABLE hadiths(_id INTEGER PRIMARY KEY AUTOINCREMENT, collection_id TEXT, hadith_number TEXT, book_id TEXT, chapter_number TEXT, reference TEXT, text_ar TEXT, matn_ar TEXT, narrator TEXT, source_grade TEXT, grade_ar TEXT, url_source TEXT);
      CREATE INDEX idx_hadith_collection_number ON hadiths(collection_id,hadith_number);
      CREATE INDEX idx_hadith_reference ON hadiths(reference);
      CREATE TABLE duas(_id INTEGER PRIMARY KEY AUTOINCREMENT, dua_number TEXT, chapter_number TEXT, reference TEXT, text_ar TEXT, transliteration TEXT, hisn_reference TEXT, url_source TEXT);
      CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT);
      CREATE INDEX idx_dua_number ON duas(dua_number);
    ''')
    hcols=cols(src,'hadiths')
    total=0
    for rid,canon,name_en,name_ar in chosen:
        q='select * from hadiths where collection_id=?'
        n=0
        for row in src.execute(q,(rid,)):
            out.execute('insert into hadiths(collection_id,hadith_number,book_id,chapter_number,reference,text_ar,matn_ar,narrator,source_grade,grade_ar,url_source) values(?,?,?,?,?,?,?,?,?,?,?)',(
                canon,str(val(row,hcols,'hadith_number','')),str(val(row,hcols,'book_id','')),str(val(row,hcols,'chapter_number','')),str(val(row,hcols,'reference','')),str(val(row,hcols,'text_ar','')),str(val(row,hcols,'matn_ar','')),str(val(row,hcols,'narrator','')),str(val(row,hcols,'source_grade','')),str(val(row,hcols,'grade_ar','')),str(val(row,hcols,'url_source',''))))
            n+=1
        out.execute('insert into collections(id,canonical_id,name_en,name_ar,total_hadiths) values(?,?,?,?,?)',(canon,canon,name_en,name_ar,n))
        total+=n
        print(f'[MIZAN] {canon}: {n} hadis')
    # Hisn al-Muslim: yalnız Arapça + Latin okunuş + kaynak. İngilizce çeviri kopyalanmaz.
    if 'duas' in [r[0] for r in src.execute("select name from sqlite_master where type='table'")]:
        dcols=cols(src,'duas');dn=0
        for row in src.execute('select * from duas'):
            out.execute('insert into duas(dua_number,chapter_number,reference,text_ar,transliteration,hisn_reference,url_source) values(?,?,?,?,?,?,?)',(
                str(val(row,dcols,'dua_number','')),str(val(row,dcols,'chapter_number','')),str(val(row,dcols,'reference','')),str(val(row,dcols,'text_ar','')),str(val(row,dcols,'transliteration','')),str(val(row,dcols,'hisn_reference','')),str(val(row,dcols,'url_source',''))))
            dn+=1
    else: dn=0
    out.executemany('insert or replace into metadata(key,value) values(?,?)',[("source",URL),("data_license","CC0-1.0 structured data; English translations excluded"),("code_license","MIT"),("build_note","Mizan stores Arabic text and metadata; no sunnah.com English translation is bundled")]);out.commit(); out.execute('vacuum'); out.close(); src.close()
    ok,h,d=validate(OUT)
    if not ok:
        print(f'[MIZAN] HATA: oluşturulan veri eksik: {h} hadis',file=sys.stderr);sys.exit(4)
    if d < 250:
        print(f'[MIZAN] UYARI: Hisnü’l-Müslim beklenenden az kayıt içeriyor: {d}',file=sys.stderr)
    print(f'[MIZAN] Yerel Kütüb-i Sitte hazır: {h} hadis; Hisnü’l-Müslim: {d} kayıt; {OUT.stat().st_size/1024/1024:.1f} MB')

if __name__=='__main__': main()
